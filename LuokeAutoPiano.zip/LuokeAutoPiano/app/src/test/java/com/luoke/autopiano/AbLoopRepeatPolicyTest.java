package com.luoke.autopiano;

import org.junit.Test;
import static org.junit.Assert.*;

public class AbLoopRepeatPolicyTest {
    @Test public void repeatsOnlyWhenBothAbAndRepeatAreEnabled() {
        assertTrue(AbLoopRepeatPolicy.shouldRepeat(true, true));
    }
    @Test public void stopsAfterOnePassWhenRepeatIsOff() {
        assertFalse(AbLoopRepeatPolicy.shouldRepeat(true, false));
    }
    @Test public void neverRepeatsWhenAbIsOff() {
        assertFalse(AbLoopRepeatPolicy.shouldRepeat(false, true));
        assertFalse(AbLoopRepeatPolicy.shouldRepeat(false, false));
    }
}
