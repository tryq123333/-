package com.luoke.autopiano;

import org.junit.Test;
import static org.junit.Assert.*;

public class NoteRollGestureMathTest {
    @Test public void shortSwipeProducesOnlySmallPositionDelta() {
        long delta = NoteRollGestureMath.gentlePanDelta(40f, 400f, 12_000_000L);
        assertTrue(Math.abs(delta) <= 60_000L);
    }

    @Test public void evenFullWidthSwipeIsCapped() {
        long delta = NoteRollGestureMath.gentlePanDelta(1000f, 1000f, 16_000_000L);
        assertTrue(Math.abs(delta) <= 500_000L);
    }

    @Test public void absoluteSeekNeedsAnIntentionalHorizontalGesture() {
        assertFalse(NoteRollGestureMath.shouldUpdateAbsoluteSeek(3f, 0f, 8));
        assertFalse(NoteRollGestureMath.shouldUpdateAbsoluteSeek(20f, 30f, 8));
        assertTrue(NoteRollGestureMath.shouldUpdateAbsoluteSeek(20f, 2f, 8));
    }

    @Test public void entranceWaitsUntilBlockHasIconSpace() {
        assertFalse(NoteRollGestureMath.pastEntranceBuffer(392f, 400f, 1f));
        assertFalse(NoteRollGestureMath.pastEntranceBuffer(378f, 400f, 1f));
        assertTrue(NoteRollGestureMath.pastEntranceBuffer(376f, 400f, 1f));
        assertTrue(NoteRollGestureMath.pastEntranceBuffer(350f, 400f, 1f));
    }
}
