package com.luoke.autopiano;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThrows;

public class MidiParserTest {
    @Rule public TemporaryFolder temporaryFolder = new TemporaryFolder();

    @Test public void parsesNoteStartsUsingTempoAndPpq() throws Exception {
        File file = new File(temporaryFolder.getRoot(), "timing-test.mid");
        Files.write(file.toPath(), midiWithThreeNotes());

        MidiParser.MidiSong song = MidiParser.parse(file);
        assertEquals(3, song.notes.size());
        assertEquals(60, song.notes.get(0).pitch);
        assertEquals(64, song.notes.get(1).pitch);
        assertEquals(67, song.notes.get(2).pitch);
        assertEquals(0L, song.notes.get(0).startMicros);
        assertEquals(250_000L, song.notes.get(1).startMicros);
        assertEquals(500_000L, song.notes.get(2).startMicros);
        assertEquals(500_000L, song.durationMicros);
    }

    @Test public void rejectsNonMidiFile() throws Exception {
        File file = new File(temporaryFolder.getRoot(), "not-midi.bin");
        Files.write(file.toPath(), new byte[] {1, 2, 3, 4, 5, 6, 7, 8});
        assertThrows(IOException.class, () -> MidiParser.parse(file));
    }

    private static byte[] midiWithThreeNotes() throws IOException {
        ByteArrayOutputStream trackBytes = new ByteArrayOutputStream();
        DataOutputStream track = new DataOutputStream(trackBytes);
        // Set tempo to 500,000 microseconds per quarter note (120 BPM).
        track.write(new byte[] {0, (byte) 0xff, 0x51, 3, 7, (byte) 0xa1, 0x20});
        track.write(new byte[] {0, (byte) 0x90, 60, 100});
        writeVariableLength(track, 240);
        track.write(new byte[] {(byte) 0x90, 64, 100});
        writeVariableLength(track, 240);
        track.write(new byte[] {(byte) 0x90, 67, 100});
        track.write(new byte[] {0, (byte) 0xff, 0x2f, 0});
        track.flush();
        byte[] trackData = trackBytes.toByteArray();

        ByteArrayOutputStream midiBytes = new ByteArrayOutputStream();
        DataOutputStream midi = new DataOutputStream(midiBytes);
        midi.writeBytes("MThd");
        midi.writeInt(6);
        midi.writeShort(0); // format 0
        midi.writeShort(1); // one track
        midi.writeShort(480); // PPQ
        midi.writeBytes("MTrk");
        midi.writeInt(trackData.length);
        midi.write(trackData);
        midi.flush();
        return midiBytes.toByteArray();
    }

    private static void writeVariableLength(DataOutputStream out, long value) throws IOException {
        int buffer = (int) (value & 0x7f);
        while ((value >>= 7) > 0) buffer = (buffer << 8) | (int) ((value & 0x7f) | 0x80);
        while (true) {
            out.writeByte(buffer & 0xff);
            if ((buffer & 0x80) != 0) buffer >>= 8;
            else break;
        }
    }
}
