package com.luoke.autopiano;

import org.junit.Test;
import java.util.Arrays;
import java.util.LinkedHashSet;
import static org.junit.Assert.*;

public class PracticeNoteGateTest {
    @Test public void singleNoteWaitsForItsExactPitch() {
        PracticeNoteGate gate = new PracticeNoteGate();
        gate.begin(Arrays.asList(60));
        assertFalse(gate.isComplete());
        assertFalse(gate.accept(62));
        assertFalse(gate.isComplete());
        assertTrue(gate.accept(60));
        assertTrue(gate.isComplete());
    }

    @Test public void chordCanBeTappedOneKeyAtATimeInAnyOrder() {
        PracticeNoteGate gate = new PracticeNoteGate();
        gate.begin(Arrays.asList(60, 64, 67, 60));
        assertEquals(new LinkedHashSet<>(Arrays.asList(60, 64, 67)), gate.remaining());
        assertTrue(gate.accept(64));
        assertFalse(gate.isComplete());
        assertTrue(gate.accept(60));
        assertFalse(gate.accept(60));
        assertFalse(gate.isComplete());
        assertTrue(gate.accept(67));
        assertTrue(gate.isComplete());
    }

    @Test public void clearResetsPendingPitches() {
        PracticeNoteGate gate = new PracticeNoteGate();
        gate.begin(Arrays.asList(45, 52));
        gate.clear();
        assertTrue(gate.isComplete());
        assertTrue(gate.remaining().isEmpty());
        assertFalse(gate.accept(45));
    }
}
