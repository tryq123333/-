package com.luoke.autopiano;

import org.junit.Test;
import static org.junit.Assert.*;

public class AbLoopRangeMathTest {
    @Test public void clampsOnlyCentisecondDisplayRoundingAtSongEnd() {
        assertEquals(69_536L, AbLoopRangeMath.clampRoundedEndMs(69_540L, 69_536L));
        assertEquals(69_535L, AbLoopRangeMath.clampRoundedEndMs(69_540L, 69_535L));
    }

    @Test public void leavesAnEndInsideDurationUnchanged() {
        assertEquals(69_530L, AbLoopRangeMath.clampRoundedEndMs(69_530L, 69_536L));
        assertEquals(69_536L, AbLoopRangeMath.clampRoundedEndMs(69_536L, 69_536L));
    }

    @Test public void rejectsEndTimesMeaningfullyBeyondDuration() {
        assertEquals(-1L, AbLoopRangeMath.clampRoundedEndMs(69_542L, 69_536L));
        assertEquals(-1L, AbLoopRangeMath.clampRoundedEndMs(69_546L, 69_536L));
    }

    @Test public void rejectsInvalidDurationsAndNegativeEndTimes() {
        assertEquals(-1L, AbLoopRangeMath.clampRoundedEndMs(100L, 0L));
        assertEquals(-1L, AbLoopRangeMath.clampRoundedEndMs(-1L, 100L));
    }
}
