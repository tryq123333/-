package com.luoke.autopiano;

import org.junit.Test;

import java.util.HashSet;
import java.util.Set;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class InstrumentLayoutTest {
    @Test public void nineKeyLayoutHasNineUniquePitchBindings() {
        assertEquals(9, InstrumentLayout.PITCHES.length);
        Set<Integer> unique = new HashSet<>();
        for (int pitch : InstrumentLayout.PITCHES) unique.add(pitch);
        assertEquals(9, unique.size());
        assertEquals("A2", InstrumentLayout.NOTE_NAMES[0]);
        assertEquals("E4", InstrumentLayout.NOTE_NAMES[8]);
    }

    @Test public void piano88ModeCoversStandardRangeAndClassifiesBlackKeys() {
        assertEquals(21, InstrumentLayout.PIANO_LOWEST_MIDI);
        assertEquals(108, InstrumentLayout.PIANO_HIGHEST_MIDI);
        assertFalse(InstrumentLayout.isBlackMidiNote(21));  // A0
        assertTrue(InstrumentLayout.isBlackMidiNote(22));   // A#0
        assertTrue(InstrumentLayout.isBlackMidiNote(25));   // C#1
        assertFalse(InstrumentLayout.isBlackMidiNote(108)); // C8
    }
}
