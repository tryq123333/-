package com.luoke.autopiano;

import org.junit.Test;

import java.util.HashSet;
import java.util.Set;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class InstrumentLayoutTest { // PRACTICE_OCTAVE_DOT_KEYMAP_V13 // PRACTICE_VISUAL_MAPPING_WAIT_QUEUE_V12
    @Test public void nineKeyLayoutHasNineUniquePitchBindings() {
        assertEquals(9, InstrumentLayout.PITCHES.length);
        Set<Integer> unique = new HashSet<>();
        for (int pitch : InstrumentLayout.PITCHES) unique.add(pitch);
        assertEquals(9, unique.size());
        assertEquals("A2", InstrumentLayout.NOTE_NAMES[0]);
        assertEquals("E4", InstrumentLayout.NOTE_NAMES[8]);
    }

    @Test public void nineKeyPitchIconsMapToCorrectGameAtlasCells() {
        assertEquals(8, InstrumentLayout.gameKeyAtlasCellForPitch(45)); // A2: low 6, dot below
        assertEquals(3, InstrumentLayout.gameKeyAtlasCellForPitch(52)); // E3: mid 3, no dot
        assertEquals(4, InstrumentLayout.gameKeyAtlasCellForPitch(53)); // F3: mid 4, no dot
        assertEquals(5, InstrumentLayout.gameKeyAtlasCellForPitch(55)); // G3: mid 5, no dot
        assertEquals(6, InstrumentLayout.gameKeyAtlasCellForPitch(57)); // A3: mid 6, no dot
        assertEquals(7, InstrumentLayout.gameKeyAtlasCellForPitch(59)); // B3: mid 7, no dot
        assertEquals(0, InstrumentLayout.gameKeyAtlasCellForPitch(60)); // C4: high 1, dot above
        assertEquals(1, InstrumentLayout.gameKeyAtlasCellForPitch(62)); // D4: high 2, dot above
        assertEquals(2, InstrumentLayout.gameKeyAtlasCellForPitch(64)); // E4: high 3, dot above
        assertEquals(-1, InstrumentLayout.gameKeyAtlasCellForPitch(61));
    }

    @Test public void piano88ModeCoversStandardRangeAndClassifiesBlackKeys() {
        assertEquals(21, InstrumentLayout.PIANO_LOWEST_MIDI);
        assertEquals(108, InstrumentLayout.PIANO_HIGHEST_MIDI);
        assertFalse(InstrumentLayout.isBlackMidiNote(21));  // A0
        assertTrue(InstrumentLayout.isBlackMidiNote(22));   // A#0
        assertTrue(InstrumentLayout.isBlackMidiNote(25));   // C#1
        assertFalse(InstrumentLayout.isBlackMidiNote(108)); // C8
    }
}
