package com.luoke.autopiano;

import org.junit.Test;
import static org.junit.Assert.*;

public class SongRangeCheckPolicyTest {
    @Test public void enabledCheckBlocksWhenUnsupportedNotesExist() {
        assertTrue(SongRangeCheckPolicy.shouldBlockPlayback(true, true));
    }

    @Test public void enabledCheckAllowsFullySupportedSong() {
        assertFalse(SongRangeCheckPolicy.shouldBlockPlayback(true, false));
    }

    @Test public void disabledCheckDoesNotBlockForUnsupportedNotes() {
        assertFalse(SongRangeCheckPolicy.shouldBlockPlayback(false, true));
    }

    @Test public void disabledCheckStillAllowsSupportedSong() {
        assertFalse(SongRangeCheckPolicy.shouldBlockPlayback(false, false));
    }
}
