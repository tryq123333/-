package com.luoke.autopiano;

import org.junit.Test;
import static org.junit.Assert.*;

public class SongAbRangeKeysTest {
    @Test public void keysAreStableForTheSameSongPath() {
        String path = "/data/user/0/app/files/imported_songs/song-a.mid";
        assertEquals(SongAbRangeKeys.startKey(path), SongAbRangeKeys.startKey(path));
        assertEquals(SongAbRangeKeys.endKey(path), SongAbRangeKeys.endKey(path));
    }

    @Test public void differentSongsKeepIndependentRangeKeys() {
        String first = "/data/user/0/app/files/imported_songs/song-a.mid";
        String second = "/data/user/0/app/files/imported_songs/song-b.mid";
        assertNotEquals(SongAbRangeKeys.startKey(first), SongAbRangeKeys.startKey(second));
        assertNotEquals(SongAbRangeKeys.endKey(first), SongAbRangeKeys.endKey(second));
    }

    @Test public void startAndEndKeysDoNotOverlap() {
        String path = "/data/user/0/app/files/imported_songs/song-a.mid";
        assertNotEquals(SongAbRangeKeys.startKey(path), SongAbRangeKeys.endKey(path));
    }
}
