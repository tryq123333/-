package com.luoke.autopiano;

import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.Set;

/** Tracks the distinct pitches that need a learner tap before a note group can advance. */
final class PracticeNoteGate {
    private final LinkedHashSet<Integer> remaining = new LinkedHashSet<>();

    void begin(Collection<Integer> pitches) {
        remaining.clear();
        if (pitches != null) remaining.addAll(pitches);
    }

    boolean accept(int pitch) { return remaining.remove(pitch); }
    boolean isComplete() { return remaining.isEmpty(); }
    Set<Integer> remaining() {
        return Collections.unmodifiableSet(new LinkedHashSet<>(remaining));
    }
    void clear() { remaining.clear(); }
}
