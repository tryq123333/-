package com.luoke.autopiano;

/** Handles the A/B dialog's centisecond display rounding at the song end. */
final class AbLoopRangeMath {
    private static final long DISPLAY_ROUNDING_TOLERANCE_MS = 5L;

    private AbLoopRangeMath() { }

    /**
     * Returns the requested end time if valid, clamps only the tiny overrun that can
     * arise when a millisecond duration is rendered as a two-decimal seconds value,
     * and returns -1 for a genuine out-of-range value.
     */
    static long clampRoundedEndMs(long requestedEndMs, long durationMs) {
        if (durationMs <= 0L || requestedEndMs < 0L) return -1L;
        if (requestedEndMs <= durationMs) return requestedEndMs;
        long overrun = requestedEndMs - durationMs;
        return overrun <= DISPLAY_ROUNDING_TOLERANCE_MS ? durationMs : -1L;
    }
}
