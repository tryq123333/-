package com.luoke.autopiano;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Point;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/** Android touch-output, calibration overlay and playback controller. */
public class MusicAccessibilityService extends AccessibilityService {
    private static volatile MusicAccessibilityService instance;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final Object playbackLock = new Object();

    private WindowManager windowManager;
    private SharedPreferences prefs;
    private View controlOverlay;
    private View calibrationOverlay;
    private TextView pauseButton;
    private WindowManager.LayoutParams controlParams;

    private int calibrationStep = 0;
    private volatile boolean calibrating = false;
    private volatile boolean stopRequested = false;
    private volatile boolean paused = false;
    private Thread playbackThread;
    private long playbackStartMs;
    private long pausedDurationMs;
    private long pauseStartedMs;
    private static final int TAP_DURATION_MS = 38;
    private static final long CHORD_WINDOW_MICROS = 3_000L;

    public static MusicAccessibilityService getInstance() { return instance; }

    @Override public void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        prefs = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE);
        showControlPanel();
        collapseControlPanel();
        toast("洛克自动琴已连接。回到游戏后点悬浮音乐图标打开控制。");
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) { }
    @Override public void onInterrupt() { stopPlayback(); }

    @Override public void onDestroy() {
        stopPlayback();
        removeOverlay(calibrationOverlay);
        removeOverlay(controlOverlay);
        calibrationOverlay = null;
        controlOverlay = null;
        if (instance == this) instance = null;
        super.onDestroy();
    }

    /** Called from the main activity: the user must start the actual capture from the game overlay. */
    public void prepareCalibration() {
        mainHandler.post(() -> {
            if (calibrating) {
                toast("正在校准，请直接点击游戏中的音符位置。");
                return;
            }
            toast("请切回洛克王国：世界，点悬浮音乐图标展开控制，再点“校准”。这样不会被本应用界面挡住。");
        });
    }

    private void showControlPanel() {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            mainHandler.post(this::showControlPanel);
            return;
        }
        if (calibrating || windowManager == null) return;
        removeOverlay(controlOverlay);

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.HORIZONTAL);
        panel.setGravity(Gravity.CENTER_VERTICAL);
        panel.setPadding(dp(6), dp(5), dp(6), dp(5));
        panel.setBackground(rounded(0xe8262f3a, dp(12)));

        TextView dragTitle = new TextView(this);
        dragTitle.setText("♫ 自动琴");
        dragTitle.setTextColor(Color.WHITE);
        dragTitle.setTextSize(12);
        dragTitle.setPadding(dp(5), dp(7), dp(7), dp(7));
        dragTitle.setTypeface(null, android.graphics.Typeface.BOLD);
        panel.addView(dragTitle, new LinearLayout.LayoutParams(-2, -2));

        Button play = smallButton("开始");
        pauseButton = new TextView(this);
        pauseButton.setText(paused ? "继续" : "暂停");
        pauseButton.setTextColor(Color.WHITE);
        pauseButton.setTextSize(12);
        pauseButton.setGravity(Gravity.CENTER);
        pauseButton.setPadding(dp(10), dp(7), dp(10), dp(7));
        pauseButton.setBackground(rounded(0xff4b6279, dp(8)));
        Button stop = smallButton("停止");
        Button calibrate = smallButton("校准");
        Button hide = smallButton("收起");
        panel.addView(play, buttonParams());
        panel.addView(pauseButton, buttonParams());
        panel.addView(stop, buttonParams());
        panel.addView(calibrate, buttonParams());
        panel.addView(hide, buttonParams());
        play.setOnClickListener(v -> startPlayback());
        pauseButton.setOnClickListener(v -> togglePause());
        stop.setOnClickListener(v -> stopPlayback());
        calibrate.setOnClickListener(v -> beginCalibration());
        hide.setOnClickListener(v -> collapseControlPanel());

        dragTitle.setOnTouchListener(new View.OnTouchListener() {
            float downRawX, downRawY;
            int startX, startY;
            boolean moved;
            @Override public boolean onTouch(View v, MotionEvent event) {
                if (controlParams == null) return false;
                switch (event.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        downRawX = event.getRawX(); downRawY = event.getRawY();
                        startX = controlParams.x; startY = controlParams.y; moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float dx = event.getRawX() - downRawX;
                        float dy = event.getRawY() - downRawY;
                        if (Math.abs(dx) + Math.abs(dy) > dp(4)) moved = true;
                        if (moved) {
                            controlParams.x = Math.max(0, startX + Math.round(dx));
                            controlParams.y = Math.max(0, startY - Math.round(dy));
                            try { windowManager.updateViewLayout(controlOverlay, controlParams); } catch (Exception ignored) { }
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        return true;
                }
                return false;
            }
        });

        controlParams = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        controlParams.gravity = Gravity.BOTTOM | Gravity.LEFT;
        controlParams.x = prefs.getInt("overlay_x", dp(6));
        controlParams.y = prefs.getInt("overlay_y", dp(4));
        controlOverlay = panel;
        try {
            windowManager.addView(controlOverlay, controlParams);
        } catch (Exception e) {
            controlOverlay = null;
            toast("悬浮控制面板无法显示，请重启无障碍服务后重试。");
        }
    }

    private void collapseControlPanel() {
        if (controlParams != null) {
            prefs.edit().putInt("overlay_x", controlParams.x).putInt("overlay_y", controlParams.y).apply();
        }
        removeOverlay(controlOverlay);
        controlOverlay = null;
        pauseButton = null;

        TextView bubble = new TextView(this);
        bubble.setText("♫");
        bubble.setTextSize(21);
        bubble.setTextColor(Color.WHITE);
        bubble.setGravity(Gravity.CENTER);
        bubble.setBackground(rounded(0xe8262f3a, dp(24)));
        WindowManager.LayoutParams p = new WindowManager.LayoutParams(
                dp(46), dp(46), WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        p.gravity = Gravity.BOTTOM | Gravity.LEFT;
        p.x = prefs.getInt("overlay_x", dp(6));
        p.y = prefs.getInt("overlay_y", dp(8));
        bubble.setOnTouchListener(new View.OnTouchListener() {
            float downX, downY;
            int originX, originY;
            boolean moved;
            @Override public boolean onTouch(View v, MotionEvent event) {
                switch (event.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        downX = event.getRawX(); downY = event.getRawY();
                        originX = p.x; originY = p.y; moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float dx = event.getRawX() - downX;
                        float dy = event.getRawY() - downY;
                        if (Math.abs(dx) + Math.abs(dy) > dp(5)) moved = true;
                        if (moved) {
                            p.x = Math.max(0, originX + Math.round(dx));
                            p.y = Math.max(0, originY - Math.round(dy));
                            try { windowManager.updateViewLayout(bubble, p); } catch (Exception ignored) { }
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        prefs.edit().putInt("overlay_x", p.x).putInt("overlay_y", p.y).apply();
                        if (!moved) showControlPanel();
                        return true;
                    case MotionEvent.ACTION_CANCEL:
                        return true;
                }
                return false;
            }
        });
        controlOverlay = bubble;
        controlParams = p;
        try { windowManager.addView(controlOverlay, controlParams); }
        catch (Exception e) { controlOverlay = null; controlParams = null; toast("悬浮按钮已收起；如需恢复，请回到主界面点击校准入口。"); }
    }

    private void removeControlPanel() {
        if (controlParams != null && controlOverlay != null) {
            prefs.edit().putInt("overlay_x", controlParams.x).putInt("overlay_y", controlParams.y).apply();
        }
        removeOverlay(controlOverlay);
        controlOverlay = null;
        controlParams = null;
        pauseButton = null;
    }

    private void beginCalibration() {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            mainHandler.post(this::beginCalibration);
            return;
        }
        if (playbackThread != null && playbackThread.isAlive()) {
            toast("请先停止自动演奏，再校准音符位置。");
            return;
        }
        calibrationStep = 0;
        calibrating = true;
        removeControlPanel();
        FrameLayout capture = new FrameLayout(this);
        capture.setBackgroundColor(Color.TRANSPARENT);
        capture.setClickable(true);

        TextView prompt = new TextView(this);
        prompt.setText(calibrationPrompt());
        prompt.setTextColor(Color.WHITE);
        prompt.setTextSize(14);
        prompt.setGravity(Gravity.CENTER);
        prompt.setPadding(dp(14), dp(10), dp(14), dp(10));
        prompt.setBackground(rounded(0xe8262f3a, dp(12)));
        // Consume taps on the instruction itself so they are never mistaken for key calibration.
        prompt.setOnClickListener(v -> { });
        FrameLayout.LayoutParams promptParams = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        promptParams.topMargin = dp(4);
        capture.addView(prompt, promptParams);

        TextView cancel = new TextView(this);
        cancel.setText("取消");
        cancel.setTextColor(Color.WHITE);
        cancel.setTextSize(13);
        cancel.setGravity(Gravity.CENTER);
        cancel.setPadding(dp(10), dp(10), dp(10), dp(10));
        cancel.setBackground(rounded(0xff805047, dp(10)));
        FrameLayout.LayoutParams cancelParams = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.RIGHT);
        cancelParams.topMargin = dp(4);
        cancelParams.rightMargin = dp(4);
        capture.addView(cancel, cancelParams);
        cancel.setOnClickListener(v -> cancelCalibration());

        capture.setOnTouchListener((v, event) -> {
            if (event.getActionMasked() != MotionEvent.ACTION_UP) return true;
            float rawX = event.getRawX();
            float rawY = event.getRawY();
            saveCalibrationTap(Math.round(rawX), Math.round(rawY), prompt);
            return true;
        });

        WindowManager.LayoutParams p = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        p.gravity = Gravity.TOP | Gravity.LEFT;
        calibrationOverlay = capture;
        try {
            windowManager.addView(calibrationOverlay, p);
            prompt.bringToFront();
            cancel.bringToFront();
            toast("校准开始：按顶部提示逐个点击，点击位置不会触发游戏音符。");
        } catch (Exception e) {
            calibrating = false;
            calibrationOverlay = null;
            showControlPanel();
            toast("无法打开校准层，请重启无障碍服务后重试。");
        }
    }

    private String calibrationPrompt() {
        if (InstrumentLayout.MODE_PIANO88.equals(InstrumentLayout.selectedMode(prefs))) {
            return InstrumentLayout.pianoCalibrationPrompt(calibrationStep) + "；点键位，不要点此提示";
        }
        return "九键 " + (calibrationStep + 1) + "/9：点 " + InstrumentLayout.displayLabel(calibrationStep) + " 对应音符";
    }

    private void saveCalibrationTap(int x, int y, TextView prompt) {
        if (InstrumentLayout.MODE_PIANO88.equals(InstrumentLayout.selectedMode(prefs))) {
            InstrumentLayout.savePianoAnchor(prefs, calibrationStep, x, y);
        } else {
            InstrumentLayout.savePoint(prefs, calibrationStep, x, y);
        }
        calibrationStep++;
        int total = InstrumentLayout.calibrationSteps(prefs);
        if (calibrationStep >= total) {
            calibrating = false;
            removeOverlay(calibrationOverlay);
            calibrationOverlay = null;
            showControlPanel();
            toast(InstrumentLayout.MODE_PIANO88.equals(InstrumentLayout.selectedMode(prefs))
                    ? (InstrumentLayout.isPiano88Calibrated(prefs) ? "88 键校准完成。" : "88 键校准失败：请确认白键端点顺序。")
                    : "九键校准完成。现在可以开始演奏。");
            return;
        }
        prompt.setText(calibrationPrompt());
    }

    private void cancelCalibration() {
        calibrating = false;
        removeOverlay(calibrationOverlay);
        calibrationOverlay = null;
        showControlPanel();
        toast("已取消校准，已保存的旧坐标不受影响。");
    }

    private void startPlayback() {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            mainHandler.post(this::startPlayback);
            return;
        }
        if (playbackThread != null && playbackThread.isAlive()) {
            toast("自动演奏正在运行；可暂停或停止。");
            return;
        }
        String path = prefs.getString(MainActivity.KEY_SONG_PATH, "");
        if (path == null || path.isEmpty() || !new File(path).isFile()) {
            toast("请先在洛克自动琴主界面导入 MIDI 曲谱。");
            return;
        }
        final MidiParser.MidiSong song;
        try { song = MidiParser.parse(new File(path)); }
        catch (Exception e) { toast("MIDI 读取失败：" + e.getMessage()); return; }

        int transpose = prefs.getInt(MainActivity.KEY_TRANSPOSE, 0);
        List<String> missing = InstrumentLayout.missingNotes(song, transpose, prefs);
        if (!missing.isEmpty()) {
            StringBuilder msg = new StringBuilder("有 ").append(missing.size()).append(" 种音高超出当前乐器音域：");
            for (int i = 0; i < Math.min(8, missing.size()); i++) {
                if (i > 0) msg.append("、");
                msg.append(missing.get(i));
            }
            if (missing.size() > 8) msg.append("…");
            msg.append("。请在主界面尝试移调。");
            toast(msg.toString());
            return;
        }
        if (InstrumentLayout.MODE_PIANO88.equals(InstrumentLayout.selectedMode(prefs))) {
            if (!InstrumentLayout.isPiano88Calibrated(prefs)) { toast("请先校准 88 键钢琴位置。"); return; }
        } else if (InstrumentLayout.calibratedCount(prefs) != InstrumentLayout.PITCHES.length) {
            toast("请先校准完整的九个音符位置。");
            return;
        }
        // Validate every destination before any game input is sent.
        for (MidiParser.NoteEvent note : song.notes) {
            if (InstrumentLayout.pointForPitch(prefs, note.pitch + transpose) == null) {
                toast("有音符尚未映射到触控位置，已阻止演奏。");
                return;
            }
        }
        stopRequested = false;
        paused = false;
        pausedDurationMs = 0;
        pauseStartedMs = 0;
        if (pauseButton != null) pauseButton.setText("暂停");
        final int chosenTranspose = transpose;
        final int speedPercent = Math.max(50, Math.min(200, prefs.getInt(MainActivity.KEY_SPEED, 100)));
        playbackThread = new Thread(() -> playSong(song, chosenTranspose, speedPercent), "Luoke-MIDI-Playback");
        playbackThread.start();
        toast("开始演奏：" + song.name);
    }

    private void playSong(MidiParser.MidiSong song, int transpose, int speedPercent) {
        playbackStartMs = SystemClock.elapsedRealtime();
        int index = 0;
        int sentBatches = 0;
        try {
            while (index < song.notes.size() && !stopRequested) {
                long at = song.notes.get(index).startMicros;
                List<MidiParser.NoteEvent> batch = new ArrayList<>();
                while (index < song.notes.size() && song.notes.get(index).startMicros - at <= CHORD_WINDOW_MICROS) {
                    batch.add(song.notes.get(index++));
                }
                long targetMs = Math.round((at / 1000.0) * (100.0 / speedPercent));
                if (!awaitTarget(targetMs)) break;
                List<Point> points = new ArrayList<>();
                Map<String, Point> unique = new LinkedHashMap<>();
                for (MidiParser.NoteEvent note : batch) {
                    Point p = InstrumentLayout.pointForPitch(prefs, note.pitch + transpose);
                    if (p != null) unique.put(p.x + ":" + p.y, p);
                }
                points.addAll(unique.values());
                boolean dispatchOk = true;
                for (int pointStart = 0; pointStart < points.size(); pointStart += 10) {
                    int pointEnd = Math.min(points.size(), pointStart + 10);
                    if (!sendTapBatch(points.subList(pointStart, pointEnd))) {
                        dispatchOk = false;
                        break;
                    }
                }
                if (!dispatchOk) {
                    if (!stopRequested) toast("触控分发失败，演奏已停止。");
                    break;
                }
                sentBatches++;
            }
        } catch (Throwable e) {
            if (!stopRequested) toast("演奏异常：" + e.getMessage());
        } finally {
            final int finalSentBatches = sentBatches;
            final boolean stoppedByUser = stopRequested;
            synchronized (playbackLock) {
                paused = false;
                stopRequested = false;
                playbackLock.notifyAll();
            }
            mainHandler.post(() -> {
                if (pauseButton != null) pauseButton.setText("暂停");
                toast((stoppedByUser ? "演奏已停止。" : "演奏结束。") + "已触发 " + finalSentBatches + " 组音符。");
                playbackThread = null;
            });
        }
    }

    private boolean awaitTarget(long targetActiveMs) {
        synchronized (playbackLock) {
            while (!stopRequested) {
                while (paused && !stopRequested) {
                    try { playbackLock.wait(); }
                    catch (InterruptedException e) { Thread.currentThread().interrupt(); return false; }
                }
                if (stopRequested) return false;
                long now = SystemClock.elapsedRealtime();
                long activeElapsed = now - playbackStartMs - pausedDurationMs;
                long remaining = targetActiveMs - activeElapsed;
                if (remaining <= 0) return true;
                try { playbackLock.wait(Math.min(remaining, 18L)); }
                catch (InterruptedException e) { Thread.currentThread().interrupt(); return false; }
            }
            return false;
        }
    }

    private boolean sendTapBatch(List<Point> points) throws InterruptedException {
        CountDownLatch latch = new CountDownLatch(1);
        boolean[] accepted = new boolean[1];
        boolean[] completed = new boolean[1];
        mainHandler.post(() -> {
            if (stopRequested) {
                latch.countDown();
                return;
            }
            try {
                GestureDescription.Builder builder = new GestureDescription.Builder();
                for (Point point : points) {
                    Path path = new Path();
                    path.moveTo(point.x, point.y);
                    path.lineTo(point.x + 1f, point.y + 1f);
                    builder.addStroke(new GestureDescription.StrokeDescription(path, 0, TAP_DURATION_MS));
                }
                accepted[0] = dispatchGesture(builder.build(), new GestureResultCallback() {
                    @Override public void onCompleted(GestureDescription gestureDescription) { completed[0] = true; latch.countDown(); }
                    @Override public void onCancelled(GestureDescription gestureDescription) { latch.countDown(); }
                }, mainHandler);
                if (!accepted[0]) latch.countDown();
            } catch (Exception e) {
                latch.countDown();
            }
        });
        boolean callback = latch.await(700, TimeUnit.MILLISECONDS);
        if (!callback) {
            stopRequested = true;
            synchronized (playbackLock) { playbackLock.notifyAll(); }
            return false;
        }
        return accepted[0] && completed[0] && !stopRequested;
    }

    private void togglePause() {
        synchronized (playbackLock) {
            if (playbackThread == null || !playbackThread.isAlive()) {
                toast("当前没有正在运行的曲谱。");
                return;
            }
            long now = SystemClock.elapsedRealtime();
            if (paused) {
                pausedDurationMs += Math.max(0, now - pauseStartedMs);
                paused = false;
                if (pauseButton != null) pauseButton.setText("暂停");
                toast("继续演奏。");
            } else {
                paused = true;
                pauseStartedMs = now;
                if (pauseButton != null) pauseButton.setText("继续");
                toast("已暂停。");
            }
            playbackLock.notifyAll();
        }
    }

    private void stopPlayback() {
        synchronized (playbackLock) {
            stopRequested = true;
            paused = false;
            playbackLock.notifyAll();
        }
        Thread t = playbackThread;
        if (t != null) t.interrupt();
        if (pauseButton != null) pauseButton.setText("暂停");
        toast("已请求停止演奏。");
    }

    private Button smallButton(String label) {
        Button button = new Button(this);
        button.setText(label);
        button.setAllCaps(false);
        button.setTextSize(11);
        button.setTextColor(Color.WHITE);
        button.setMinWidth(0);
        button.setMinimumWidth(0);
        button.setMinHeight(0);
        button.setMinimumHeight(dp(30));
        button.setPadding(dp(8), dp(1), dp(8), dp(1));
        button.setBackground(rounded(0xff455667, dp(8)));
        return button;
    }

    private LinearLayout.LayoutParams buttonParams() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-2, dp(34));
        p.setMargins(dp(2), 0, dp(2), 0);
        return p;
    }

    private GradientDrawable rounded(int color, int radius) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(radius);
        drawable.setStroke(dp(1), 0x55ffffff);
        return drawable;
    }

    private void removeOverlay(View view) {
        if (view == null || windowManager == null) return;
        try { windowManager.removeView(view); } catch (Exception ignored) { }
    }

    private void toast(String message) {
        mainHandler.post(() -> Toast.makeText(this, message, Toast.LENGTH_LONG).show());
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
