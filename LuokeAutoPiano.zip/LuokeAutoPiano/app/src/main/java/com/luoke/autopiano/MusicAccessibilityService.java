package com.luoke.autopiano;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Point;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/** Android touch-output, calibration overlay and playback controller. */
public class MusicAccessibilityService extends AccessibilityService {
    private static volatile MusicAccessibilityService instance;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final Object playbackLock = new Object();

    private WindowManager windowManager;
    private SharedPreferences prefs;
    private View controlOverlay;
    private View calibrationOverlay;
    private View segmentOverlay;
    private NoteRollView noteRollView;
    private WindowManager.LayoutParams noteRollParams;
    private TextView pauseButton;
    private TextView miniPlaybackButton;
    private WindowManager.LayoutParams controlParams;
    private int controlGestureStartX;
    private int controlGestureStartY;
    private int controlGestureStartWidth;
    private int controlGestureStartHeight;
    private int controlResizeEdges;
    private boolean controlHeightUserSized;

    private int calibrationStep = 0;
    private volatile boolean calibrating = false;
    private volatile boolean stopRequested = false;
    private volatile boolean paused = false;
    private Thread playbackThread;
    private long playbackStartMs;
    private long pausedDurationMs;
    private long pauseStartedMs;
    private volatile long playbackPositionMicros;
    private volatile long playbackRangeStartMicros;
    private volatile long playbackRangeEndMicros;
    private volatile long playbackBaseMicros;
    private volatile long seekRequestMicros;
    private volatile int seekRequestVersion;
    private int noteRollGestureStartX;
    private int noteRollGestureStartY;
    private int noteRollGestureStartWidth;
    private int noteRollGestureStartHeight;
    private volatile int activeSpeedPercent = 100;
    private volatile boolean playbackActive;
    private volatile MidiParser.MidiSong currentSong;
    private static final String KEY_RANGE_START_MS = "practice_start_ms";
    private static final String KEY_RANGE_END_MS = "practice_end_ms";
    private static final int TAP_DURATION_MS = 38;
    private static final long CHORD_WINDOW_MICROS = 3_000L;

    public static MusicAccessibilityService getInstance() { return instance; }

    @Override public void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        prefs = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE);
        showControlPanel();
        collapseControlPanel();
        toast("洛克自动琴已连接。回到游戏后点悬浮音乐图标打开控制。");
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) { }
    @Override public void onInterrupt() { stopPlayback(); }

    @Override public void onDestroy() {
        stopPlayback();
        removeOverlay(calibrationOverlay);
        removeOverlay(controlOverlay);
        removeOverlay(segmentOverlay);
        removeOverlay(noteRollView);
        calibrationOverlay = null;
        controlOverlay = null;
        segmentOverlay = null;
        noteRollView = null;
        if (instance == this) instance = null;
        super.onDestroy();
    }

    /** Called from the main activity: the user must start the actual capture from the game overlay. */
    public void prepareCalibration() {
        mainHandler.post(() -> {
            if (calibrating) {
                toast("正在校准，请直接点击游戏中的音符位置。");
                return;
            }
            toast("请切回洛克王国：世界，点悬浮音乐图标展开控制，再点“校准”。这样不会被本应用界面挡住。");
        });
    }

    private void showControlPanel() {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            mainHandler.post(this::showControlPanel);
            return;
        }
        if (calibrating || windowManager == null) return;
        removeOverlay(controlOverlay);
        controlOverlay = null;
        miniPlaybackButton = null;

        FrameLayout window = new FrameLayout(this);
        window.setBackground(rounded(0xe8262f3a, dp(12)));
        AdaptiveFlowLayout panel = new AdaptiveFlowLayout(this);
        panel.setPadding(dp(6), dp(5), dp(6), dp(5));
        panel.setBackgroundColor(Color.TRANSPARENT);

        TextView dragTitle = new TextView(this);
        dragTitle.setText("♫ 自动琴");
        dragTitle.setTextColor(Color.WHITE);
        dragTitle.setTextSize(12);
        dragTitle.setPadding(dp(5), dp(7), dp(7), dp(7));
        dragTitle.setTypeface(null, android.graphics.Typeface.BOLD);
        panel.addView(dragTitle, flowButtonParams());

        Button play = smallButton("开始");
        pauseButton = new TextView(this);
        pauseButton.setText(paused ? "继续" : "暂停");
        pauseButton.setTextColor(Color.WHITE);
        pauseButton.setTextSize(12);
        pauseButton.setGravity(Gravity.CENTER);
        pauseButton.setPadding(dp(8), dp(7), dp(8), dp(7));
        pauseButton.setBackground(rounded(0xff4b6279, dp(8)));
        Button stop = smallButton("停止");
        Button songs = smallButton("曲目");
        Button segment = smallButton("片段");
        Button roll = smallButton("谱面");
        Button calibrate = smallButton("校准");
        Button hide = smallButton("收起");
        panel.addView(play, flowButtonParams());
        panel.addView(pauseButton, flowButtonParams());
        panel.addView(stop, flowButtonParams());
        panel.addView(songs, flowButtonParams());
        panel.addView(segment, flowButtonParams());
        panel.addView(roll, flowButtonParams());
        panel.addView(calibrate, flowButtonParams());
        panel.addView(hide, flowButtonParams());
        play.setOnClickListener(v -> startPlayback());
        pauseButton.setOnClickListener(v -> togglePause());
        stop.setOnClickListener(v -> stopPlayback());
        songs.setOnClickListener(v -> showSongPickerDialog());
        segment.setOnClickListener(v -> beginRangeEditingFromControl());
        roll.setOnClickListener(v -> toggleNoteRoll());
        calibrate.setOnClickListener(v -> beginCalibration());
        hide.setOnClickListener(v -> collapseControlPanel());

        FrameLayout.LayoutParams contentParams = new FrameLayout.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);
        contentParams.setMargins(0, 0, 0, 0);
        window.addView(panel, contentParams);

        dragTitle.setOnTouchListener(new View.OnTouchListener() {
            float downRawX, downRawY;
            int startX, startY;
            boolean moved;
            @Override public boolean onTouch(View v, MotionEvent event) {
                if (controlParams == null) return false;
                switch (event.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        downRawX = event.getRawX(); downRawY = event.getRawY();
                        startX = controlParams.x; startY = controlParams.y; moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float dx = event.getRawX() - downRawX;
                        float dy = event.getRawY() - downRawY;
                        if (Math.abs(dx) + Math.abs(dy) > dp(4)) moved = true;
                        if (moved) {
                            android.util.DisplayMetrics m = getResources().getDisplayMetrics();
                            controlParams.x = Math.max(0, Math.min(m.widthPixels - window.getWidth(), startX + Math.round(dx)));
                            controlParams.y = Math.max(0, Math.min(m.heightPixels - window.getHeight(), startY - Math.round(dy)));
                            try { windowManager.updateViewLayout(controlOverlay, controlParams); } catch (Exception ignored) { }
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        saveControlWindowPosition();
                        return true;
                }
                return false;
            }
        });

        // The border is a resize grip. The flow layout re-measures and wraps children
        // automatically as width changes. Height stays content-sized unless its edge is dragged.
        window.setOnTouchListener(new View.OnTouchListener() {
            @Override public boolean onTouch(View v, MotionEvent event) {
                float x = event.getX(), y = event.getY();
                int width = Math.max(1, v.getWidth());
                int height = Math.max(1, v.getHeight());
                switch (event.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        controlResizeEdges = controlEdges(x, y, width, height, dp(13));
                        if (controlResizeEdges == 0 || controlParams == null) return false;
                        controlGestureStartX = controlParams.x;
                        controlGestureStartY = controlParams.y;
                        controlGestureStartWidth = controlParams.width > 0 ? controlParams.width : width;
                        controlGestureStartHeight = controlParams.height > 0 ? controlParams.height : height;
                        controlResizeStartRawX = event.getRawX();
                        controlResizeStartRawY = event.getRawY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        if (controlParams == null || controlResizeEdges == 0) return false;
                        int dx = Math.round(event.getRawX() - controlResizeStartRawX);
                        int dy = Math.round(event.getRawY() - controlResizeStartRawY);
                        applyControlResize(v, event, dx, dy);
                        return true;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        if (controlResizeEdges == 0) return false;
                        saveControlWindowPosition();
                        controlResizeEdges = 0;
                        return true;
                }
                return false;
            }
        });

        android.util.DisplayMetrics metrics = getResources().getDisplayMetrics();
        int screenWidth = Math.max(1, metrics.widthPixels);
        int screenHeight = Math.max(1, metrics.heightPixels);
        int maxWidth = Math.max(dp(150), screenWidth - dp(8));
        boolean layoutV3 = prefs.getBoolean("control_overlay_resize_v3", false);
        int defaultWidth = Math.min(maxWidth, dp(500));
        int width = layoutV3 ? prefs.getInt("control_width_px", defaultWidth) : defaultWidth;
        width = Math.max(Math.min(dp(170), maxWidth), Math.min(maxWidth, width));
        int storedHeight = layoutV3 ? prefs.getInt("control_height_px", WindowManager.LayoutParams.WRAP_CONTENT)
                : WindowManager.LayoutParams.WRAP_CONTENT;
        controlHeightUserSized = storedHeight > 0;
        controlParams = new WindowManager.LayoutParams(
                width, storedHeight,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        controlParams.gravity = Gravity.BOTTOM | Gravity.LEFT;
        controlParams.x = Math.max(0, Math.min(screenWidth - width, prefs.getInt("overlay_x", dp(6))));
        controlParams.y = Math.max(0, Math.min(screenHeight - dp(44), prefs.getInt("overlay_y", dp(4))));
        controlOverlay = window;
        try {
            windowManager.addView(controlOverlay, controlParams);
            prefs.edit().putBoolean("control_overlay_resize_v3", true).apply();
        } catch (Exception e) {
            controlOverlay = null;
            toast("悬浮控制面板无法显示，请重启无障碍服务后重试。");
        }
    }

    private float controlResizeStartRawX;
    private float controlResizeStartRawY;

    private boolean applyControlResize(View window, MotionEvent event, int dx, int dy) {
        if (controlParams == null || windowManager == null) return false;
        android.util.DisplayMetrics metrics = getResources().getDisplayMetrics();
        int screenWidth = Math.max(1, metrics.widthPixels);
        int screenHeight = Math.max(1, metrics.heightPixels);
        int minWidth = Math.min(dp(170), Math.max(dp(100), screenWidth - dp(8)));
        int maxWidth = Math.max(minWidth, screenWidth - dp(8));
        int minHeight = dp(58);
        int maxHeight = Math.max(minHeight, screenHeight - dp(16));
        int width = controlGestureStartWidth;
        int height = controlGestureStartHeight;
        int x = controlGestureStartX;
        int y = controlGestureStartY;
        if ((controlResizeEdges & NoteRollView.EDGE_LEFT) != 0) {
            width = controlGestureStartWidth - dx;
            x = controlGestureStartX + dx;
        }
        if ((controlResizeEdges & NoteRollView.EDGE_RIGHT) != 0) width = controlGestureStartWidth + dx;
        if ((controlResizeEdges & NoteRollView.EDGE_TOP) != 0) {
            height = controlGestureStartHeight - dy;
            controlParams.y = controlGestureStartY;
            controlHeightUserSized = true;
        }
        if ((controlResizeEdges & NoteRollView.EDGE_BOTTOM) != 0) {
            height = controlGestureStartHeight + dy;
            y = controlGestureStartY - dy;
            controlHeightUserSized = true;
        }
        int rawWidth = width;
        width = Math.max(minWidth, Math.min(maxWidth, width));
        if ((controlResizeEdges & NoteRollView.EDGE_LEFT) != 0) x += rawWidth - width;
        controlParams.width = width;
        if ((controlResizeEdges & (NoteRollView.EDGE_TOP | NoteRollView.EDGE_BOTTOM)) != 0) {
            controlParams.height = Math.max(minHeight, Math.min(maxHeight, height));
        } else if (!controlHeightUserSized) {
            controlParams.height = WindowManager.LayoutParams.WRAP_CONTENT;
        }
        controlParams.x = Math.max(0, Math.min(screenWidth - width, x));
        if ((controlResizeEdges & NoteRollView.EDGE_BOTTOM) != 0) controlParams.y = Math.max(0, y);
        int activeHeight = controlParams.height > 0 ? controlParams.height : window.getHeight();
        controlParams.y = Math.max(0, Math.min(Math.max(0, screenHeight - activeHeight), controlParams.y));
        try { windowManager.updateViewLayout(controlOverlay, controlParams); } catch (Exception ignored) { }
        return true;
    }

    private int controlEdges(float x, float y, float w, float h, float edge) {
        int result = 0;
        if (x <= edge) result |= NoteRollView.EDGE_LEFT;
        if (x >= w - edge) result |= NoteRollView.EDGE_RIGHT;
        if (y <= edge) result |= NoteRollView.EDGE_TOP;
        if (y >= h - edge) result |= NoteRollView.EDGE_BOTTOM;
        return result;
    }

    private void saveControlWindowPosition() {
        if (controlParams == null) return;
        prefs.edit().putInt("overlay_x", controlParams.x).putInt("overlay_y", controlParams.y)
                .putInt("control_width_px", controlParams.width)
                .putInt("control_height_px", controlHeightUserSized ? controlParams.height : WindowManager.LayoutParams.WRAP_CONTENT)
                .putBoolean("control_overlay_resize_v3", true).apply();
    }

    private void collapseControlPanel() {
        saveControlWindowPosition();
        removeOverlay(controlOverlay);
        controlOverlay = null;
        pauseButton = null;

        LinearLayout bubble = new LinearLayout(this);
        bubble.setOrientation(LinearLayout.HORIZONTAL);
        bubble.setGravity(Gravity.CENTER);
        bubble.setPadding(dp(3), dp(3), dp(3), dp(3));
        bubble.setBackground(rounded(0xe8262f3a, dp(22)));

        TextView open = new TextView(this);
        open.setText("♫");
        open.setTextSize(21);
        open.setTextColor(Color.WHITE);
        open.setGravity(Gravity.CENTER);
        open.setMinWidth(dp(38));
        open.setMinHeight(dp(38));
        open.setBackground(rounded(0xff455667, dp(20)));
        TextView quick = new TextView(this);
        quick.setTextColor(Color.WHITE);
        quick.setTextSize(15);
        quick.setGravity(Gravity.CENTER);
        quick.setMinWidth(dp(38));
        quick.setMinHeight(dp(38));
        quick.setPadding(dp(7), 0, dp(7), 0);
        quick.setBackground(rounded(0xff4b6279, dp(20)));
        miniPlaybackButton = quick;
        refreshMiniPlaybackButton();
        LinearLayout.LayoutParams miniParams = new LinearLayout.LayoutParams(dp(38), dp(38));
        miniParams.setMargins(dp(2), 0, dp(2), 0);
        bubble.addView(open, miniParams);
        bubble.addView(quick, miniParams);
        quick.setOnClickListener(v -> {
            if (playbackThread != null && playbackThread.isAlive()) togglePause();
            else startPlayback();
            refreshMiniPlaybackButton();
        });

        WindowManager.LayoutParams p = new WindowManager.LayoutParams(
                dp(86), dp(44), WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        p.gravity = Gravity.BOTTOM | Gravity.LEFT;
        p.x = prefs.getInt("overlay_x", dp(6));
        p.y = prefs.getInt("overlay_y", dp(8));
        open.setOnTouchListener(new View.OnTouchListener() {
            float downX, downY;
            int originX, originY;
            boolean moved;
            @Override public boolean onTouch(View v, MotionEvent event) {
                switch (event.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        downX = event.getRawX(); downY = event.getRawY();
                        originX = p.x; originY = p.y; moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float dx = event.getRawX() - downX;
                        float dy = event.getRawY() - downY;
                        if (Math.abs(dx) + Math.abs(dy) > dp(5)) moved = true;
                        if (moved) {
                            android.util.DisplayMetrics m = getResources().getDisplayMetrics();
                            p.x = Math.max(0, Math.min(m.widthPixels - dp(86), originX + Math.round(dx)));
                            p.y = Math.max(0, originY - Math.round(dy));
                            try { windowManager.updateViewLayout(bubble, p); } catch (Exception ignored) { }
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        prefs.edit().putInt("overlay_x", p.x).putInt("overlay_y", p.y).apply();
                        if (!moved) showControlPanel();
                        return true;
                    case MotionEvent.ACTION_CANCEL:
                        return true;
                }
                return false;
            }
        });
        controlOverlay = bubble;
        controlParams = p;
        try { windowManager.addView(controlOverlay, controlParams); }
        catch (Exception e) { controlOverlay = null; controlParams = null; miniPlaybackButton = null; toast("悬浮按钮无法显示，请回到主界面重新开启校准入口。"); }
    }

    private void refreshMiniPlaybackButton() {
        if (miniPlaybackButton == null) return;
        boolean alive = playbackThread != null && playbackThread.isAlive();
        miniPlaybackButton.setText(alive && playbackActive && !paused ? "Ⅱ" : "▶");
        miniPlaybackButton.setContentDescription(alive && playbackActive && !paused ? "暂停自动演奏" : "开始或继续演奏");
    }

    private void removeControlPanel() {
        if (controlParams != null && controlOverlay != null) {
            prefs.edit().putInt("overlay_x", controlParams.x).putInt("overlay_y", controlParams.y).apply();
        }
        removeOverlay(controlOverlay);
        controlOverlay = null;
        controlParams = null;
        pauseButton = null;
        miniPlaybackButton = null;
    }

    private void toggleNoteRoll() {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            mainHandler.post(this::toggleNoteRoll);
            return;
        }
        dismissSegmentDialog();
        if (noteRollView != null) {
            removeOverlay(noteRollView);
            noteRollView = null;
            prefs.edit().putBoolean("note_roll_enabled", false).apply();
            toast("音符谱面已隐藏。再次点“谱面”可显示。 ");
        } else {
            prefs.edit().putBoolean("note_roll_enabled", true).apply();
            showNoteRoll();
        }
    }

    private MidiParser.MidiSong readCurrentSong() {
        String path = prefs.getString(MainActivity.KEY_SONG_PATH, "");
        if (path == null || path.isEmpty() || !new File(path).isFile()) return null;
        try { return MidiParser.parse(new File(path)); }
        catch (Exception ex) { toast("谱面载入失败：" + ex.getMessage()); return null; }
    }

    private void showNoteRoll() {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            mainHandler.post(this::showNoteRoll);
            return;
        }
        if (windowManager == null) return;
        MidiParser.MidiSong song = readCurrentSong();
        if (song == null) {
            toast("请先在洛克自动琴主界面导入 MIDI 曲谱，再显示音符谱面。");
            return;
        }
        currentSong = song;
        if (noteRollView == null) {
            noteRollView = new NoteRollView(this);
            noteRollView.setInteractionListener(new NoteRollView.InteractionListener() {
                @Override public void onSeek(long positionMicros) { seekPlaybackTo(positionMicros); }
                @Override public void onPracticeRangeChange(long startMicros, long endMicros) { savePracticeRangeMicros(startMicros, endMicros); }
                @Override public void onWindowGesture(int mode, int edges, int dx, int dy, int phase) {
                    handleNoteRollWindowGesture(mode, edges, dx, dy, phase);
                }
                @Override public void onClose() {
                    removeOverlay(noteRollView);
                    noteRollView = null;
                    prefs.edit().putBoolean("note_roll_enabled", false).apply();
                }
                @Override public void onTogglePlayPause() {
                    if (playbackThread != null && playbackThread.isAlive()) togglePause();
                    else startPlayback();
                    refreshMiniPlaybackButton();
                }
                @Override public void onEditSegment() { toggleRangeEditingMode(); }
            });
            android.util.DisplayMetrics metrics = getResources().getDisplayMetrics();
            int screenWidth = Math.max(1, metrics.widthPixels);
            int screenHeight = Math.max(1, metrics.heightPixels);
            int minWidth = Math.min(dp(150), Math.max(dp(110), screenWidth - dp(8)));
            int maxWidth = Math.max(minWidth, screenWidth - dp(8));
            int minHeight = Math.min(dp(100), Math.max(dp(78), screenHeight - dp(12)));
            int maxHeight = Math.max(minHeight, Math.min(screenHeight - dp(8), (int) (screenHeight * .58f)));
            int defaultWidth = Math.min(maxWidth, Math.max(minWidth, Math.round(screenWidth * .32f)));
            int defaultHeight = Math.min(maxHeight, dp(112));
            boolean noteLayoutV3 = prefs.getBoolean("note_roll_layout_v3", false);
            int width = noteLayoutV3 ? Math.max(minWidth, Math.min(maxWidth, prefs.getInt("note_roll_width_px", defaultWidth))) : defaultWidth;
            int height = noteLayoutV3 ? Math.max(minHeight, Math.min(maxHeight, prefs.getInt("note_roll_height_px", defaultHeight))) : defaultHeight;
            noteRollParams = new WindowManager.LayoutParams(
                    width, height,
                    WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                            | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                    PixelFormat.TRANSLUCENT);
            noteRollParams.gravity = Gravity.TOP | Gravity.LEFT;
            noteRollParams.x = noteLayoutV3 ? Math.max(0, Math.min(screenWidth - width, prefs.getInt("note_roll_x", dp(6)))) : dp(6);
            noteRollParams.y = noteLayoutV3 ? Math.max(0, Math.min(screenHeight - height, prefs.getInt("note_roll_y", dp(5)))) : dp(5);
            try { windowManager.addView(noteRollView, noteRollParams);
                prefs.edit().putBoolean("note_roll_layout_v3", true).apply();
            }
            catch (Exception e) {
                noteRollView = null;
                noteRollParams = null;
                toast("音符谱面无法显示，请重新开启无障碍服务后重试。");
                return;
            }
        }
        refreshNoteRollData();
    }

    private void beginRangeEditingFromControl() {
        if (currentSong == null) currentSong = readCurrentSong();
        if (currentSong == null) {
            toast("请先导入 MIDI 曲谱。 ");
            return;
        }
        if (noteRollView == null) showNoteRoll();
        if (noteRollView != null) {
            if (playbackActive && !paused) togglePause();
            dismissSegmentDialog();
            noteRollView.setRangeEditing(true);
            toast("片段选择已开启：直接在谱面上横向拖动，调整最近的起点或终点；点“选”退出。 ");
        }
    }

    private void toggleRangeEditingMode() {
        if (noteRollView == null) {
            beginRangeEditingFromControl();
            return;
        }
        dismissSegmentDialog();
        boolean enable = !noteRollView.isRangeEditing();
        if (enable && playbackActive && !paused) togglePause();
        noteRollView.setRangeEditing(enable);
        toast(enable ? "片段选择已开启：在谱面上横向拖动起止点。 " : "已退出片段选择。 ");
    }

    private void savePracticeRangeMicros(long startMicros, long endMicros) {
        if (currentSong == null) currentSong = readCurrentSong();
        if (currentSong == null) return;
        long duration = Math.max(1L, currentSong.durationMicros);
        long minGap = Math.min(duration, Math.min(500_000L, Math.max(30_000L, duration / 2000L)));
        long start = Math.max(0L, Math.min(startMicros, duration - minGap));
        long end = Math.max(start + minGap, Math.min(duration, endMicros));
        prefs.edit().putLong(KEY_RANGE_START_MS, start / 1000L)
                .putLong(KEY_RANGE_END_MS, end / 1000L).apply();
        playbackRangeStartMicros = start;
        playbackRangeEndMicros = end;
        if (playbackPositionMicros < start || playbackPositionMicros >= end) {
            playbackPositionMicros = start;
            playbackBaseMicros = start;
            if (playbackThread != null && playbackThread.isAlive() && playbackActive) {
                seekRequestMicros = start;
                seekRequestVersion++;
                synchronized (playbackLock) { playbackLock.notifyAll(); }
            }
        }
        refreshNoteRollData();
    }

    private void handleNoteRollWindowGesture(int mode, int edges, int dx, int dy, int phase) {
        if (noteRollParams == null || noteRollView == null || windowManager == null) return;
        if (phase == NoteRollView.PHASE_START) {
            noteRollGestureStartX = noteRollParams.x;
            noteRollGestureStartY = noteRollParams.y;
            noteRollGestureStartWidth = noteRollParams.width;
            noteRollGestureStartHeight = noteRollParams.height;
            return;
        }
        if (phase == NoteRollView.PHASE_UPDATE) {
            android.util.DisplayMetrics metrics = getResources().getDisplayMetrics();
            int screenWidth = Math.max(1, metrics.widthPixels);
            int screenHeight = Math.max(1, metrics.heightPixels);
            int width = noteRollGestureStartWidth;
            int height = noteRollGestureStartHeight;
            int x = noteRollGestureStartX;
            int y = noteRollGestureStartY;
            if (mode == NoteRollView.MODE_MOVE) {
                x = noteRollGestureStartX + dx;
                y = noteRollGestureStartY + dy;
            } else {
                if ((edges & NoteRollView.EDGE_LEFT) != 0) {
                    width = noteRollGestureStartWidth - dx;
                    x = noteRollGestureStartX + dx;
                }
                if ((edges & NoteRollView.EDGE_RIGHT) != 0) width = noteRollGestureStartWidth + dx;
                if ((edges & NoteRollView.EDGE_TOP) != 0) {
                    height = noteRollGestureStartHeight - dy;
                    y = noteRollGestureStartY + dy;
                }
                if ((edges & NoteRollView.EDGE_BOTTOM) != 0) height = noteRollGestureStartHeight + dy;
                int minWidth = Math.min(dp(150), Math.max(dp(110), screenWidth - dp(8)));
                int maxWidth = Math.max(minWidth, screenWidth - dp(8));
                int minHeight = Math.min(dp(100), Math.max(dp(78), screenHeight - dp(12)));
                int maxHeight = Math.max(minHeight, Math.min(screenHeight - dp(8), (int) (screenHeight * .58f)));
                int unclampedWidth = width;
                int unclampedHeight = height;
                width = Math.max(minWidth, Math.min(maxWidth, width));
                height = Math.max(minHeight, Math.min(maxHeight, height));
                if ((edges & NoteRollView.EDGE_LEFT) != 0) x += unclampedWidth - width;
                if ((edges & NoteRollView.EDGE_TOP) != 0) y += unclampedHeight - height;
            }
            int minWidth = Math.min(dp(150), Math.max(dp(110), screenWidth - dp(8)));
            int maxWidth = Math.max(minWidth, screenWidth - dp(8));
            int minHeight = Math.min(dp(100), Math.max(dp(78), screenHeight - dp(12)));
            int maxHeight = Math.max(minHeight, Math.min(screenHeight - dp(8), (int) (screenHeight * .58f)));
            noteRollParams.width = Math.max(minWidth, Math.min(maxWidth, width));
            noteRollParams.height = Math.max(minHeight, Math.min(maxHeight, height));
            noteRollParams.x = Math.max(0, Math.min(screenWidth - noteRollParams.width, x));
            noteRollParams.y = Math.max(0, Math.min(screenHeight - noteRollParams.height, y));
            try { windowManager.updateViewLayout(noteRollView, noteRollParams); } catch (Exception ignored) { }
        } else if (phase == NoteRollView.PHASE_END) {
            prefs.edit().putInt("note_roll_width_px", noteRollParams.width)
                    .putInt("note_roll_height_px", noteRollParams.height)
                    .putInt("note_roll_x", noteRollParams.x)
                    .putInt("note_roll_y", noteRollParams.y).apply();
            refreshNoteRollData();
        }
    }

    private void refreshNoteRollData() {
        if (noteRollView == null) return;
        if (currentSong == null) currentSong = readCurrentSong();
        if (currentSong == null) return;
        long duration = currentSong.durationMicros;
        long startMs = Math.max(0L, prefs.getLong(KEY_RANGE_START_MS, 0L));
        long savedEnd = prefs.getLong(KEY_RANGE_END_MS, -1L);
        long endMs = (savedEnd <= 0L || savedEnd > duration / 1000L) ? duration / 1000L : savedEnd;
        long start = Math.min(duration, startMs * 1000L);
        long end = Math.min(duration, endMs * 1000L);
        if (end <= start) { start = 0L; end = duration; }
        if (playbackPositionMicros < start || playbackPositionMicros > end) playbackPositionMicros = start;
        if (!playbackActive) {
            playbackRangeStartMicros = start;
            playbackRangeEndMicros = end;
            playbackBaseMicros = playbackPositionMicros;
        }
        int speed = Math.max(50, Math.min(200, prefs.getInt(MainActivity.KEY_SPEED, 100)));
        noteRollView.setData(currentSong,
                prefs.getString(MainActivity.KEY_SONG_NAME, currentSong.name),
                prefs.getInt(MainActivity.KEY_TRANSPOSE, 0), playbackPositionMicros,
                duration, start, end, speed, playbackActive && !paused);
    }

    private void seekPlaybackTo(long requestedPositionMicros) {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            mainHandler.post(() -> seekPlaybackTo(requestedPositionMicros));
            return;
        }
        if (currentSong == null) currentSong = readCurrentSong();
        if (currentSong == null) return;
        long duration = currentSong.durationMicros;
        long start = playbackRangeEndMicros > playbackRangeStartMicros
                ? playbackRangeStartMicros : Math.max(0L, prefs.getLong(KEY_RANGE_START_MS, 0L)) * 1000L;
        long end = playbackRangeEndMicros > playbackRangeStartMicros
                ? playbackRangeEndMicros : duration;
        end = Math.min(duration, end);
        long target = Math.max(start, Math.min(Math.max(start, end - 1L), requestedPositionMicros));
        playbackPositionMicros = target;
        playbackBaseMicros = target;
        if (playbackThread != null && playbackThread.isAlive() && playbackActive) {
            seekRequestMicros = target;
            seekRequestVersion++;
            synchronized (playbackLock) { playbackLock.notifyAll(); }
        }
        if (noteRollView != null) noteRollView.setCursor(target, playbackActive && !paused);
    }

    private static final class ImportedSong {
        final File file;
        final String name;
        ImportedSong(File file, String name) { this.file = file; this.name = name; }
    }

    private List<ImportedSong> listImportedSongs() {
        Map<String, ImportedSong> unique = new LinkedHashMap<>();
        File dir = new File(getFilesDir(), "imported_songs");
        File[] files = dir.listFiles();
        if (files != null) {
            for (File file : files) {
                if (!file.isFile()) continue;
                String lower = file.getName().toLowerCase(java.util.Locale.ROOT);
                if (!lower.endsWith(".mid") && !lower.endsWith(".midi")) continue;
                String label = prefs.getString("song_label_" + file.getName(), null);
                if (label == null || label.trim().isEmpty()) {
                    String n = file.getName();
                    int underscore = n.indexOf('_');
                    if (underscore > 0 && n.substring(0, underscore).matches("[0-9]+")) n = n.substring(underscore + 1);
                    label = n;
                }
                unique.put(file.getAbsolutePath(), new ImportedSong(file, label));
            }
        }
        File legacy = new File(getFilesDir(), "current_song.mid");
        if (legacy.isFile()) unique.put(legacy.getAbsolutePath(), new ImportedSong(legacy,
                prefs.getString(MainActivity.KEY_SONG_NAME, "旧曲目")));
        List<ImportedSong> result = new ArrayList<>(unique.values());
        java.util.Collections.sort(result, (a, b) -> Long.compare(b.file.lastModified(), a.file.lastModified()));
        return result;
    }

    private void showSongPickerDialog() {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            mainHandler.post(this::showSongPickerDialog);
            return;
        }
        if (windowManager == null) return;
        dismissSegmentDialog();
        List<ImportedSong> songs = listImportedSongs();
        if (songs.isEmpty()) {
            toast("还没有已导入曲目，请先回主界面导入 MIDI。");
            return;
        }
        String currentPath = prefs.getString(MainActivity.KEY_SONG_PATH, "");
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(0x55060b12);
        root.setClickable(true);
        root.setOnClickListener(v -> dismissSegmentDialog());
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(12), dp(12), dp(12), dp(12));
        card.setBackground(rounded(0xf4f5f9fc, dp(15)));
        card.setClickable(true);
        card.setOnClickListener(v -> { });
        TextView title = new TextView(this);
        title.setText("已导入曲目");
        title.setTextColor(0xff192a35);
        title.setTextSize(17);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        title.setPadding(dp(4), dp(3), dp(4), dp(8));
        card.addView(title);
        TextView hint = new TextView(this);
        hint.setText("点选即可切换；演奏中切换会先停止当前曲目。");
        hint.setTextColor(0xff617583);
        hint.setTextSize(11);
        hint.setPadding(dp(4), 0, dp(4), dp(8));
        card.addView(hint);
        ScrollView scroll = new ScrollView(this);
        LinearLayout rows = new LinearLayout(this);
        rows.setOrientation(LinearLayout.VERTICAL);
        for (ImportedSong imported : songs) {
            boolean selected = imported.file.getAbsolutePath().equals(currentPath);
            TextView item = new TextView(this);
            item.setText((selected ? "✓  " : "♪  ") + imported.name);
            item.setTextColor(selected ? 0xff125744 : 0xff253441);
            item.setTextSize(13);
            item.setMaxLines(2);
            item.setPadding(dp(11), dp(10), dp(11), dp(10));
            item.setBackground(rounded(selected ? 0xffc9f0e1 : 0xffe7edf3, dp(10)));
            LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(-1, -2);
            ip.setMargins(0, 0, 0, dp(5));
            rows.addView(item, ip);
            item.setOnClickListener(v -> selectImportedSong(imported.file.getAbsolutePath(), imported.name));
        }
        scroll.addView(rows);
        card.addView(scroll, new LinearLayout.LayoutParams(-1, Math.min(dp(330), Math.max(dp(100), getResources().getDisplayMetrics().heightPixels * 2 / 5))));
        Button close = dialogButton("关闭", 0xff526777);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, dp(38));
        cp.setMargins(0, dp(8), 0, 0);
        card.addView(close, cp);
        close.setOnClickListener(v -> dismissSegmentDialog());
        int screenWidth = getResources().getDisplayMetrics().widthPixels;
        FrameLayout.LayoutParams cardParams = new FrameLayout.LayoutParams(Math.min(screenWidth - dp(32), dp(390)), -2, Gravity.CENTER);
        root.addView(card, cardParams);
        WindowManager.LayoutParams overlayParams = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        overlayParams.gravity = Gravity.TOP | Gravity.LEFT;
        segmentOverlay = root;
        try { windowManager.addView(root, overlayParams); }
        catch (Exception e) { segmentOverlay = null; toast("曲目列表无法显示。"); }
    }

    private void selectImportedSong(String path, String displayName) {
        if (playbackThread != null && playbackThread.isAlive()) {
            if (!stopRequested) stopPlayback();
            mainHandler.postDelayed(() -> selectImportedSong(path, displayName), 80L);
            return;
        }
        File file = new File(path);
        if (!file.isFile()) { toast("曲目文件已不存在，请重新导入。"); dismissSegmentDialog(); return; }
        final MidiParser.MidiSong selected;
        try { selected = MidiParser.parse(file); }
        catch (Exception ex) { toast("曲目读取失败：" + ex.getMessage()); dismissSegmentDialog(); return; }
        prefs.edit().putString(MainActivity.KEY_SONG_PATH, file.getAbsolutePath())
                .putString(MainActivity.KEY_SONG_NAME, displayName)
                .putLong(KEY_RANGE_START_MS, 0L).putLong(KEY_RANGE_END_MS, -1L).apply();
        currentSong = selected;
        playbackPositionMicros = 0L;
        playbackBaseMicros = 0L;
        playbackRangeStartMicros = 0L;
        playbackRangeEndMicros = selected.durationMicros;
        seekRequestMicros = 0L;
        seekRequestVersion++;
        dismissSegmentDialog();
        if (noteRollView != null) refreshNoteRollData();
        else if (prefs.getBoolean("note_roll_enabled", true)) showNoteRoll();
        toast("已切换曲目：" + displayName);
    }

    // SEGMENT_EDIT_IN_ROLL_ONLY_V1: select a slice directly on the note roll; never create a fullscreen blocker.
    private void showSegmentDialog() {
        beginRangeEditingFromControl();
    }

    private Button dialogButton(String label, int color) {
        Button button = smallButton(label);
        button.setTextSize(12);
        button.setBackground(rounded(color, dp(8)));
        return button;
    }

    private void savePracticeRange(long startMs, long endMs, int speed) {
        prefs.edit().putLong(KEY_RANGE_START_MS, Math.max(0L, startMs))
                .putLong(KEY_RANGE_END_MS, Math.max(startMs + 1L, endMs))
                .putInt(MainActivity.KEY_SPEED, Math.max(50, Math.min(200, speed))).apply();
        if (noteRollView != null) refreshNoteRollData();
    }

    private void dismissSegmentDialog() {
        removeOverlay(segmentOverlay);
        segmentOverlay = null;
    }

    private void beginCalibration() {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            mainHandler.post(this::beginCalibration);
            return;
        }
        if (playbackThread != null && playbackThread.isAlive()) {
            toast("请先停止自动演奏，再校准音符位置。");
            return;
        }
        calibrationStep = 0;
        calibrating = true;
        removeControlPanel();
        FrameLayout capture = new FrameLayout(this);
        capture.setBackgroundColor(Color.TRANSPARENT);
        capture.setClickable(true);

        TextView prompt = new TextView(this);
        prompt.setText(calibrationPrompt());
        prompt.setTextColor(Color.WHITE);
        prompt.setTextSize(14);
        prompt.setGravity(Gravity.CENTER);
        prompt.setPadding(dp(14), dp(10), dp(14), dp(10));
        prompt.setBackground(rounded(0xe8262f3a, dp(12)));
        // Consume taps on the instruction itself so they are never mistaken for key calibration.
        prompt.setOnClickListener(v -> { });
        FrameLayout.LayoutParams promptParams = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        promptParams.topMargin = dp(4);
        capture.addView(prompt, promptParams);

        TextView cancel = new TextView(this);
        cancel.setText("取消");
        cancel.setTextColor(Color.WHITE);
        cancel.setTextSize(13);
        cancel.setGravity(Gravity.CENTER);
        cancel.setPadding(dp(10), dp(10), dp(10), dp(10));
        cancel.setBackground(rounded(0xff805047, dp(10)));
        FrameLayout.LayoutParams cancelParams = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.RIGHT);
        cancelParams.topMargin = dp(4);
        cancelParams.rightMargin = dp(4);
        capture.addView(cancel, cancelParams);
        cancel.setOnClickListener(v -> cancelCalibration());

        capture.setOnTouchListener((v, event) -> {
            if (event.getActionMasked() != MotionEvent.ACTION_UP) return true;
            float rawX = event.getRawX();
            float rawY = event.getRawY();
            saveCalibrationTap(Math.round(rawX), Math.round(rawY), prompt);
            return true;
        });

        WindowManager.LayoutParams p = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        p.gravity = Gravity.TOP | Gravity.LEFT;
        calibrationOverlay = capture;
        try {
            windowManager.addView(calibrationOverlay, p);
            prompt.bringToFront();
            cancel.bringToFront();
            toast("校准开始：按顶部提示逐个点击，点击位置不会触发游戏音符。");
        } catch (Exception e) {
            calibrating = false;
            calibrationOverlay = null;
            showControlPanel();
            toast("无法打开校准层，请重启无障碍服务后重试。");
        }
    }

    private String calibrationPrompt() {
        if (InstrumentLayout.MODE_PIANO88.equals(InstrumentLayout.selectedMode(prefs))) {
            return InstrumentLayout.pianoCalibrationPrompt(calibrationStep) + "；点键位，不要点此提示";
        }
        return "九键 " + (calibrationStep + 1) + "/9：点 " + InstrumentLayout.displayLabel(calibrationStep) + " 对应音符";
    }

    private void saveCalibrationTap(int x, int y, TextView prompt) {
        if (InstrumentLayout.MODE_PIANO88.equals(InstrumentLayout.selectedMode(prefs))) {
            InstrumentLayout.savePianoAnchor(prefs, calibrationStep, x, y);
        } else {
            InstrumentLayout.savePoint(prefs, calibrationStep, x, y);
        }
        calibrationStep++;
        int total = InstrumentLayout.calibrationSteps(prefs);
        if (calibrationStep >= total) {
            calibrating = false;
            removeOverlay(calibrationOverlay);
            calibrationOverlay = null;
            showControlPanel();
            toast(InstrumentLayout.MODE_PIANO88.equals(InstrumentLayout.selectedMode(prefs))
                    ? (InstrumentLayout.isPiano88Calibrated(prefs) ? "88 键校准完成。" : "88 键校准失败：请确认白键端点顺序。")
                    : "九键校准完成。现在可以开始演奏。");
            return;
        }
        prompt.setText(calibrationPrompt());
    }

    private void cancelCalibration() {
        calibrating = false;
        removeOverlay(calibrationOverlay);
        calibrationOverlay = null;
        showControlPanel();
        toast("已取消校准，已保存的旧坐标不受影响。");
    }

    private void startPlayback() {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            mainHandler.post(this::startPlayback);
            return;
        }
        if (playbackThread != null && playbackThread.isAlive()) {
            toast("自动演奏正在运行；可暂停或停止。");
            return;
        }
        String path = prefs.getString(MainActivity.KEY_SONG_PATH, "");
        if (path == null || path.isEmpty() || !new File(path).isFile()) {
            toast("请先在洛克自动琴主界面导入 MIDI 曲谱。");
            return;
        }
        final MidiParser.MidiSong song;
        try { song = MidiParser.parse(new File(path)); }
        catch (Exception e) { toast("MIDI 读取失败：" + e.getMessage()); return; }

        currentSong = song;
        long durationMs = Math.max(1L, (song.durationMicros + 999L) / 1000L);
        long rangeStartMs = Math.max(0L, Math.min(durationMs, prefs.getLong(KEY_RANGE_START_MS, 0L)));
        long storedEndMs = prefs.getLong(KEY_RANGE_END_MS, -1L);
        long rangeEndMs = (storedEndMs <= 0L || storedEndMs > durationMs) ? durationMs : storedEndMs;
        if (rangeEndMs <= rangeStartMs) { rangeStartMs = 0L; rangeEndMs = durationMs; }
        final long selectedRangeStartMicros = rangeStartMs * 1000L;
        final long chosenEndMicros = Math.max(selectedRangeStartMicros + 1L, rangeEndMs * 1000L);
        long cursor = playbackPositionMicros;
        final long chosenStartMicros = cursor > selectedRangeStartMicros && cursor < chosenEndMicros
                ? cursor : selectedRangeStartMicros;
        int transpose = prefs.getInt(MainActivity.KEY_TRANSPOSE, 0);
        java.util.Set<Integer> missingSet = new java.util.TreeSet<>();
        for (MidiParser.NoteEvent note : song.notes) {
            if (note.startMicros >= chosenStartMicros && note.startMicros < chosenEndMicros
                    && !InstrumentLayout.supportsPitch(prefs, note.pitch + transpose)) {
                missingSet.add(note.pitch + transpose);
            }
        }
        List<String> missing = new ArrayList<>();
        for (Integer pitch : missingSet) missing.add(MidiParser.noteName(pitch));
        if (!missing.isEmpty()) {
            StringBuilder msg = new StringBuilder("有 ").append(missing.size()).append(" 种音高超出当前乐器音域：");
            for (int i = 0; i < Math.min(8, missing.size()); i++) {
                if (i > 0) msg.append("、");
                msg.append(missing.get(i));
            }
            if (missing.size() > 8) msg.append("…");
            msg.append("。请在主界面尝试移调。");
            toast(msg.toString());
            return;
        }
        if (InstrumentLayout.MODE_PIANO88.equals(InstrumentLayout.selectedMode(prefs))) {
            if (!InstrumentLayout.isPiano88Calibrated(prefs)) { toast("请先校准 88 键钢琴位置。"); return; }
        } else if (InstrumentLayout.calibratedCount(prefs) != InstrumentLayout.PITCHES.length) {
            toast("请先校准完整的九个音符位置。");
            return;
        }
        for (MidiParser.NoteEvent note : song.notes) {
            if (note.startMicros >= chosenStartMicros && note.startMicros < chosenEndMicros
                    && InstrumentLayout.pointForPitch(prefs, note.pitch + transpose) == null) {
                toast("所选片段中有音符尚未映射到触控位置，已阻止演奏。");
                return;
            }
        }
        stopRequested = false;
        paused = false;
        pausedDurationMs = 0;
        pauseStartedMs = 0;
        playbackRangeStartMicros = selectedRangeStartMicros;
        playbackRangeEndMicros = Math.min(song.durationMicros, chosenEndMicros);
        if (playbackRangeEndMicros <= playbackRangeStartMicros) playbackRangeEndMicros = song.durationMicros;
        playbackBaseMicros = chosenStartMicros;
        seekRequestMicros = chosenStartMicros;
        seekRequestVersion++;
        playbackPositionMicros = chosenStartMicros;
        final int chosenTranspose = transpose;
        final int speedPercent = Math.max(50, Math.min(200, prefs.getInt(MainActivity.KEY_SPEED, 100)));
        activeSpeedPercent = speedPercent;
        playbackActive = true;
        if (pauseButton != null) pauseButton.setText("暂停");
        refreshMiniPlaybackButton();
        if (prefs.getBoolean("note_roll_enabled", true)) showNoteRoll();
        else if (noteRollView != null) refreshNoteRollData();
        playbackThread = new Thread(() -> playSong(song, chosenTranspose, speedPercent,
                playbackRangeStartMicros, playbackRangeEndMicros), "Luoke-MIDI-Playback");
        playbackThread.start();
        refreshMiniPlaybackButton();
        toast("开始演奏：" + song.name + "（" + NoteRollView.formatTime(playbackRangeStartMicros)
                + "－" + NoteRollView.formatTime(playbackRangeEndMicros) + "）");
    }

    private int firstNoteAtOrAfter(MidiParser.MidiSong song, long timeMicros) {
        int low = 0, high = song.notes.size();
        while (low < high) {
            int mid = (low + high) >>> 1;
            if (song.notes.get(mid).startMicros < timeMicros) low = mid + 1;
            else high = mid;
        }
        return low;
    }

    private void playSong(MidiParser.MidiSong song, int transpose, int speedPercent,
                          long rangeStartMicros, long rangeEndMicros) {
        playbackStartMs = SystemClock.elapsedRealtime();
        long baseMicros = playbackBaseMicros;
        int observedSeekVersion = seekRequestVersion;
        int index = firstNoteAtOrAfter(song, baseMicros);
        int sentBatches = 0;
        try {
            while (!stopRequested) {
                if (seekRequestVersion != observedSeekVersion) {
                    observedSeekVersion = seekRequestVersion;
                    baseMicros = Math.max(rangeStartMicros, Math.min(rangeEndMicros, seekRequestMicros));
                    playbackBaseMicros = baseMicros;
                    playbackPositionMicros = baseMicros;
                    playbackStartMs = SystemClock.elapsedRealtime();
                    pausedDurationMs = 0L;
                    if (paused) pauseStartedMs = playbackStartMs;
                    index = firstNoteAtOrAfter(song, baseMicros);
                    mainHandler.post(() -> { if (noteRollView != null) noteRollView.setCursor(playbackPositionMicros, playbackActive && !paused); });
                    if (baseMicros >= rangeEndMicros) break;
                }
                if (index >= song.notes.size() || song.notes.get(index).startMicros >= rangeEndMicros) break;
                long at = song.notes.get(index).startMicros;
                List<MidiParser.NoteEvent> batch = new ArrayList<>();
                while (index < song.notes.size() && song.notes.get(index).startMicros < rangeEndMicros
                        && song.notes.get(index).startMicros - at <= CHORD_WINDOW_MICROS) {
                    batch.add(song.notes.get(index++));
                }
                long targetMs = Math.round(Math.max(0L, at - baseMicros) / 1000.0 * (100.0 / speedPercent));
                if (!awaitTarget(targetMs, observedSeekVersion)) {
                    if (stopRequested) break;
                    continue;
                }
                // A scrub that lands while a chord is waiting must reposition before sending it.
                if (seekRequestVersion != observedSeekVersion) continue;
                List<Point> points = new ArrayList<>();
                Map<String, Point> unique = new LinkedHashMap<>();
                for (MidiParser.NoteEvent note : batch) {
                    Point p = InstrumentLayout.pointForPitch(prefs, note.pitch + transpose);
                    if (p != null) unique.put(p.x + ":" + p.y, p);
                }
                points.addAll(unique.values());
                boolean dispatchOk = true;
                for (int pointStart = 0; pointStart < points.size(); pointStart += 10) {
                    if (seekRequestVersion != observedSeekVersion) { dispatchOk = false; break; }
                    int pointEnd = Math.min(points.size(), pointStart + 10);
                    if (!sendTapBatch(points.subList(pointStart, pointEnd)) ) {
                        dispatchOk = false;
                        break;
                    }
                }
                if (!dispatchOk) {
                    if (stopRequested) break;
                    if (seekRequestVersion != observedSeekVersion) continue;
                    if (!stopRequested) toast("触控分发失败，演奏已停止。");
                    break;
                }
                sentBatches++;
            }
        } catch (Throwable e) {
            if (!stopRequested) toast("演奏异常：" + e.getMessage());
        } finally {
            final int finalSentBatches = sentBatches;
            final boolean stoppedByUser = stopRequested;
            playbackActive = false;
            synchronized (playbackLock) {
                paused = false;
                stopRequested = false;
                playbackLock.notifyAll();
            }
            mainHandler.post(() -> {
                if (pauseButton != null) pauseButton.setText("暂停");
                if (!stoppedByUser) playbackPositionMicros = playbackRangeEndMicros;
                if (noteRollView != null) noteRollView.setCursor(playbackPositionMicros, false);
                playbackThread = null;
                refreshMiniPlaybackButton();
                toast((stoppedByUser ? "演奏已停止。" : "演奏结束。") + "已触发 " + finalSentBatches + " 组音符。");
            });
        }
    }

    private boolean awaitTarget(long targetActiveMs, int expectedSeekVersion) {
        synchronized (playbackLock) {
            while (!stopRequested) {
                if (seekRequestVersion != expectedSeekVersion) return false;
                while (paused && !stopRequested && seekRequestVersion == expectedSeekVersion) {
                    try { playbackLock.wait(); }
                    catch (InterruptedException e) { Thread.currentThread().interrupt(); return false; }
                }
                if (stopRequested || seekRequestVersion != expectedSeekVersion) return false;
                long now = SystemClock.elapsedRealtime();
                long activeElapsed = Math.max(0L, now - playbackStartMs - pausedDurationMs);
                playbackPositionMicros = playbackBaseMicros
                        + Math.min(Math.max(0L, playbackRangeEndMicros - playbackBaseMicros), activeElapsed * activeSpeedPercent * 10L);
                if (noteRollView != null) {
                    final long cursor = playbackPositionMicros;
                    final boolean isRunning = playbackActive && !paused && !stopRequested;
                    mainHandler.post(() -> { if (noteRollView != null) noteRollView.setCursor(cursor, isRunning); });
                }
                long remaining = targetActiveMs - activeElapsed;
                if (remaining <= 0) return true;
                try { playbackLock.wait(Math.min(remaining, 35L)); }
                catch (InterruptedException e) { Thread.currentThread().interrupt(); return false; }
            }
            return false;
        }
    }

    private boolean sendTapBatch(List<Point> points) throws InterruptedException {
        CountDownLatch latch = new CountDownLatch(1);
        boolean[] accepted = new boolean[1];
        boolean[] completed = new boolean[1];
        mainHandler.post(() -> {
            if (stopRequested) {
                latch.countDown();
                return;
            }
            try {
                GestureDescription.Builder builder = new GestureDescription.Builder();
                for (Point point : points) {
                    Path path = new Path();
                    path.moveTo(point.x, point.y);
                    path.lineTo(point.x + 1f, point.y + 1f);
                    builder.addStroke(new GestureDescription.StrokeDescription(path, 0, TAP_DURATION_MS));
                }
                accepted[0] = dispatchGesture(builder.build(), new GestureResultCallback() {
                    @Override public void onCompleted(GestureDescription gestureDescription) { completed[0] = true; latch.countDown(); }
                    @Override public void onCancelled(GestureDescription gestureDescription) { latch.countDown(); }
                }, mainHandler);
                if (!accepted[0]) latch.countDown();
            } catch (Exception e) {
                latch.countDown();
            }
        });
        boolean callback = latch.await(700, TimeUnit.MILLISECONDS);
        if (!callback) {
            stopRequested = true;
            synchronized (playbackLock) { playbackLock.notifyAll(); }
            return false;
        }
        return accepted[0] && completed[0] && !stopRequested;
    }

    private void togglePause() {
        synchronized (playbackLock) {
            if (playbackThread == null || !playbackThread.isAlive()) {
                toast("当前没有正在运行的曲谱。");
                return;
            }
            long now = SystemClock.elapsedRealtime();
            if (paused) {
                pausedDurationMs += Math.max(0, now - pauseStartedMs);
                paused = false;
                if (pauseButton != null) pauseButton.setText("暂停");
                refreshMiniPlaybackButton();
                if (noteRollView != null) noteRollView.setCursor(playbackPositionMicros, true);
                toast("继续演奏。");
            } else {
                paused = true;
                pauseStartedMs = now;
                if (pauseButton != null) pauseButton.setText("继续");
                refreshMiniPlaybackButton();
                if (noteRollView != null) noteRollView.setCursor(playbackPositionMicros, false);
                toast("已暂停。");
            }
            playbackLock.notifyAll();
        }
    }

    private void stopPlayback() {
        synchronized (playbackLock) {
            stopRequested = true;
            paused = false;
            playbackLock.notifyAll();
        }
        Thread t = playbackThread;
        if (t != null) t.interrupt();
        playbackActive = false;
        if (noteRollView != null) noteRollView.setCursor(playbackPositionMicros, false);
        if (pauseButton != null) pauseButton.setText("暂停");
        refreshMiniPlaybackButton();
        toast("已请求停止演奏。");
    }

    private Button smallButton(String label) {
        Button button = new Button(this);
        button.setText(label);
        button.setAllCaps(false);
        button.setTextSize(11);
        button.setTextColor(Color.WHITE);
        button.setMinWidth(0);
        button.setMinimumWidth(0);
        button.setMinHeight(0);
        button.setMinimumHeight(dp(30));
        button.setPadding(dp(8), dp(1), dp(8), dp(1));
        button.setBackground(rounded(0xff455667, dp(8)));
        return button;
    }

    private AdaptiveFlowLayout.LayoutParams flowButtonParams() {
        AdaptiveFlowLayout.LayoutParams p = new AdaptiveFlowLayout.LayoutParams(-2, dp(34));
        p.setMargins(dp(1), dp(1), dp(1), dp(1));
        return p;
    }

    private GradientDrawable rounded(int color, int radius) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(radius);
        drawable.setStroke(dp(1), 0x55ffffff);
        return drawable;
    }

    private void removeOverlay(View view) {
        if (view == null || windowManager == null) return;
        try { windowManager.removeView(view); } catch (Exception ignored) { }
    }

    private void toast(String message) {
        mainHandler.post(() -> Toast.makeText(this, message, Toast.LENGTH_LONG).show());
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
