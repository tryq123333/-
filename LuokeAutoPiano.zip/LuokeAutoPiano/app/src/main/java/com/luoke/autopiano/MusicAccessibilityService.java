package com.luoke.autopiano;

import android.accessibilityservice.AccessibilityService;
import android.app.AlertDialog;
import android.accessibilityservice.GestureDescription;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Point;
import android.graphics.drawable.GradientDrawable;
import android.content.res.ColorStateList;
import android.text.InputType;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/** Android touch-output, calibration overlay and playback controller. COLLAPSED_MUSIC_STATUS_BUBBLE_V1 TOP_LEFT_CALIBRATION_FLOW_V1 AB_LOOP_SETTINGS_V1 AB_LOOP_FIXES_V2 NOTE_ROLL_PLAY_REWIND_SEEK_GUARD_V1 SONG_SPECIFIC_ROLL_UI_V2 ROLL_SINGLE_PERFORMANCE_REAL_ICONS_FADE_V3 ROLL_SEEK_ICON_STABILITY_V4 ROLL_FINAL_CONTROLS_SEEK_LAUNCHER_V6 */
public class MusicAccessibilityService extends AccessibilityService {
    private static volatile MusicAccessibilityService instance;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final Object playbackLock = new Object();

    private WindowManager windowManager;
    private SharedPreferences prefs;
    private View controlOverlay;
    private View calibrationOverlay;
    private View segmentOverlay;
    private NoteRollView noteRollView;
    private WindowManager.LayoutParams noteRollParams;
    private TextView pauseButton;
    private View startPlaybackButton;
    private View rewindControlButton;
    private View noteRollControlButton;
    private WindowManager.LayoutParams segmentOverlayParams;
    private boolean playbackWasRunningBeforeNoteScrub;
    private TextView miniPlaybackButton;
    private LinearLayout collapsedBubble;
    private TextView collapsedMusicIcon;
    private TextView collapsedStatusTitle;
    private TextView collapsedStatusTime;
    private TextView collapsedExpandButton;
    private TextView collapsedCloseButton;
    private boolean controlPanelCollapsed;
    private boolean statusBubbleMode;
    private boolean playbackEverStarted;
    private boolean statusBubbleDismissed;
    private WindowManager.LayoutParams controlParams;
    private int controlGestureStartX;
    private int controlGestureStartY;
    private int controlGestureStartWidth;
    private int controlGestureStartHeight;
    private int controlResizeEdges;
    private boolean controlHeightUserSized;

    private int calibrationStep = 0;
    private volatile boolean calibrating = false;
    private volatile boolean stopRequested = false;
    private volatile boolean paused = false;
    private Thread playbackThread;
    private long playbackStartMs;
    private long pausedDurationMs;
    private long pauseStartedMs;
    private volatile long playbackPositionMicros;
    private volatile long playbackUiGeneration;
    private volatile long playbackRangeStartMicros;
    private volatile long playbackRangeEndMicros;
    private volatile long playbackBaseMicros;
    private volatile long seekRequestMicros;
    private volatile int seekRequestVersion;
    private int noteRollGestureStartX;
    private int noteRollGestureStartY;
    private int noteRollGestureStartWidth;
    private int noteRollGestureStartHeight;
    private volatile int activeSpeedPercent = 100;
    private volatile boolean playbackActive;
    private volatile MidiParser.MidiSong currentSong;
    private static final String KEY_RANGE_START_MS = "practice_start_ms";
    private static final String KEY_RANGE_END_MS = "practice_end_ms";
    private static final String KEY_AB_LOOP_ENABLED = "ab_loop_enabled";
    private static final int TAP_DURATION_MS = 38;
    private static final long CHORD_WINDOW_MICROS = 3_000L;

    public static MusicAccessibilityService getInstance() { return instance; }

    @Override public void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        prefs = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE);
        if (!prefs.getBoolean("overlay_top_left_default_v1", false)) {
            prefs.edit().putInt("overlay_x", dp(6)).putInt("overlay_y", dp(6))
                    .putBoolean("overlay_top_left_default_v1", true).apply();
        }
        showControlPanel();
        collapseControlPanel();
        toast("洛克乐器演奏已连接。回到游戏后点悬浮音乐图标打开控制。");
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) { }
    @Override public void onInterrupt() { stopPlayback(); }

    @Override public void onDestroy() {
        stopPlayback();
        removeOverlay(calibrationOverlay);
        removeOverlay(controlOverlay);
        removeOverlay(segmentOverlay);
        removeOverlay(noteRollView);
        calibrationOverlay = null;
        controlOverlay = null;
        segmentOverlay = null;
        noteRollView = null;
        if (instance == this) instance = null;
        super.onDestroy();
    }

    /** Called from the main activity: the user must start the actual capture from the game overlay. */
    private boolean isCurrentLayoutCalibrated() {
            if (InstrumentLayout.MODE_PIANO88.equals(InstrumentLayout.selectedMode(prefs))) {
                return InstrumentLayout.isPiano88Calibrated(prefs);
            }
            return InstrumentLayout.calibratedCount(prefs) == InstrumentLayout.PITCHES.length;
        }

        public void prepareCalibration() {
        mainHandler.post(() -> {
            if (calibrating) {
                toast("正在校准，请直接点击游戏中的音符位置。");
                return;
            }
            toast("请切回洛克王国：世界，点悬浮音乐图标展开控制，再点“校准”。这样不会被本应用界面挡住。");
        });
    }

    private void showControlPanel() {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            mainHandler.post(this::showControlPanel);
            return;
        }
        if (calibrating || windowManager == null) return;
        removeOverlay(controlOverlay);
        controlOverlay = null;
        miniPlaybackButton = null;
        collapsedBubble = null;
        collapsedStatusTitle = null;
        collapsedStatusTime = null;
        collapsedExpandButton = null;
        collapsedCloseButton = null;
        controlPanelCollapsed = false;
        statusBubbleMode = false;

        FrameLayout window = new FrameLayout(this);
        window.setBackground(rounded(0xe8262f3a, dp(12)));
        AdaptiveFlowLayout panel = new AdaptiveFlowLayout(this);
        panel.setPadding(dp(6), dp(5), dp(6), dp(5));
        panel.setBackgroundColor(Color.TRANSPARENT);

        TextView dragTitle = new TextView(this);
        dragTitle.setText("♫");
        dragTitle.setTextColor(Color.WHITE);
        dragTitle.setTextSize(21);
        dragTitle.setGravity(Gravity.CENTER);
        dragTitle.setMinWidth(dp(38));
        dragTitle.setMinHeight(dp(38));
        dragTitle.setBackground(roundedNoStroke(0xff455667, dp(22)));
        dragTitle.setContentDescription("收起音乐控制面板");
        dragTitle.setTypeface(null, android.graphics.Typeface.BOLD);
        AdaptiveFlowLayout.LayoutParams musicIconParams = new AdaptiveFlowLayout.LayoutParams(dp(38), dp(38));
        musicIconParams.setMargins(dp(1), dp(1), dp(1), dp(1));
        panel.addView(dragTitle, musicIconParams);

        boolean calibrated = isCurrentLayoutCalibrated();
        Button play = smallButton("演奏");
        startPlaybackButton = calibrated ? play : null;
        pauseButton = null;
        Button stop = smallButton("⏮︎");
        rewindControlButton = stop;
        Button songs = smallButton("曲目");
        Button segment = smallButton("A/B循环");
        Button roll = smallButton("谱面");
        noteRollControlButton = roll;
        Button calibrate = smallButton("校准");
        if (calibrated) {
            panel.addView(play, flowButtonParams());
            panel.addView(stop, flowButtonParams());
            panel.addView(songs, flowButtonParams());
            panel.addView(segment, flowButtonParams());
            panel.addView(roll, flowButtonParams());
        }
        if (!calibrated) panel.addView(calibrate, flowButtonParams());
        if (calibrated) {
            play.setOnClickListener(v -> toggleUnifiedPlayback());
            stop.setContentDescription("回到起始点");
            stop.setOnClickListener(v -> rewindPlaybackToStart());
            songs.setOnClickListener(v -> showSongPickerDialog());
            segment.setOnClickListener(v -> showSegmentDialog());
            roll.setOnClickListener(v -> toggleNoteRoll());
        }
        calibrate.setOnClickListener(v -> beginCalibration());
        updateControlPanelPlaybackButtons();

        FrameLayout.LayoutParams contentParams = new FrameLayout.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);
        contentParams.setMargins(0, 0, 0, 0);
        window.addView(panel, contentParams);

        dragTitle.setOnTouchListener(new View.OnTouchListener() {
            float downRawX, downRawY;
            int startX, startY;
            boolean moved;
            @Override public boolean onTouch(View v, MotionEvent event) {
                if (controlParams == null) return false;
                switch (event.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        downRawX = event.getRawX(); downRawY = event.getRawY();
                        startX = controlParams.x; startY = controlParams.y; moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float dx = event.getRawX() - downRawX;
                        float dy = event.getRawY() - downRawY;
                        if (Math.abs(dx) + Math.abs(dy) > dp(4)) moved = true;
                        if (moved) {
                            android.util.DisplayMetrics m = getResources().getDisplayMetrics();
                            controlParams.x = Math.max(0, Math.min(m.widthPixels - window.getWidth(), startX + Math.round(dx)));
                            controlParams.y = Math.max(0, Math.min(m.heightPixels - window.getHeight(), startY + Math.round(dy)));
                            try { windowManager.updateViewLayout(controlOverlay, controlParams); } catch (Exception ignored) { }
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (moved) saveControlWindowPosition();
                        else collapseControlPanel();
                        return true;
                    case MotionEvent.ACTION_CANCEL:
                        saveControlWindowPosition();
                        return true;
                }
                return false;
            }
        });

        // The border is a resize grip. The flow layout re-measures and wraps children
        // automatically as width changes. Height stays content-sized unless its edge is dragged.
        window.setOnTouchListener(new View.OnTouchListener() {
            @Override public boolean onTouch(View v, MotionEvent event) {
                float x = event.getX(), y = event.getY();
                int width = Math.max(1, v.getWidth());
                int height = Math.max(1, v.getHeight());
                switch (event.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        controlResizeEdges = controlEdges(x, y, width, height, dp(13));
                        if (controlResizeEdges == 0 || controlParams == null) return false;
                        controlGestureStartX = controlParams.x;
                        controlGestureStartY = controlParams.y;
                        controlGestureStartWidth = controlParams.width > 0 ? controlParams.width : width;
                        controlGestureStartHeight = controlParams.height > 0 ? controlParams.height : height;
                        controlResizeStartRawX = event.getRawX();
                        controlResizeStartRawY = event.getRawY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        if (controlParams == null || controlResizeEdges == 0) return false;
                        int dx = Math.round(event.getRawX() - controlResizeStartRawX);
                        int dy = Math.round(event.getRawY() - controlResizeStartRawY);
                        applyControlResize(v, event, dx, dy);
                        return true;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        if (controlResizeEdges == 0) return false;
                        saveControlWindowPosition();
                        controlResizeEdges = 0;
                        return true;
                }
                return false;
            }
        });

        android.util.DisplayMetrics metrics = getResources().getDisplayMetrics();
        int screenWidth = Math.max(1, metrics.widthPixels);
        int screenHeight = Math.max(1, metrics.heightPixels);
        int maxWidth = Math.max(dp(150), screenWidth - dp(8));
        boolean layoutV3 = prefs.getBoolean("control_overlay_resize_v3", false);
        int defaultWidth = Math.min(maxWidth, dp(500));
        int width = layoutV3 ? prefs.getInt("control_width_px", defaultWidth) : defaultWidth;
        width = Math.max(Math.min(dp(170), maxWidth), Math.min(maxWidth, width));
        int storedHeight = layoutV3 ? prefs.getInt("control_height_px", WindowManager.LayoutParams.WRAP_CONTENT)
                : WindowManager.LayoutParams.WRAP_CONTENT;
        controlHeightUserSized = calibrated && storedHeight > 0;
        controlParams = new WindowManager.LayoutParams(
                calibrated ? width : WindowManager.LayoutParams.WRAP_CONTENT,
                calibrated ? storedHeight : WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        controlParams.gravity = Gravity.TOP | Gravity.LEFT;
        int positionWidth = calibrated ? width : dp(126);
        controlParams.x = Math.max(0, Math.min(screenWidth - positionWidth, prefs.getInt("overlay_x", dp(6))));
        controlParams.y = Math.max(0, Math.min(screenHeight - dp(92), prefs.getInt("overlay_y", dp(6))));
        controlOverlay = window;
        try {
            windowManager.addView(controlOverlay, controlParams);
            prefs.edit().putBoolean("control_overlay_resize_v3", true).apply();
        } catch (Exception e) {
            controlOverlay = null;
            toast("悬浮控制面板无法显示，请重启无障碍服务后重试。");
        }
    }

    private float controlResizeStartRawX;
    private float controlResizeStartRawY;

    private boolean applyControlResize(View window, MotionEvent event, int dx, int dy) {
        if (controlParams == null || windowManager == null) return false;
        android.util.DisplayMetrics metrics = getResources().getDisplayMetrics();
        int screenWidth = Math.max(1, metrics.widthPixels);
        int screenHeight = Math.max(1, metrics.heightPixels);
        int minWidth = Math.min(dp(170), Math.max(dp(100), screenWidth - dp(8)));
        int maxWidth = Math.max(minWidth, screenWidth - dp(8));
        int minHeight = dp(58);
        int maxHeight = Math.max(minHeight, screenHeight - dp(16));
        int width = controlGestureStartWidth;
        int height = controlGestureStartHeight;
        int x = controlGestureStartX;
        int y = controlGestureStartY;
        if ((controlResizeEdges & NoteRollView.EDGE_LEFT) != 0) {
            width = controlGestureStartWidth - dx;
            x = controlGestureStartX + dx;
        }
        if ((controlResizeEdges & NoteRollView.EDGE_RIGHT) != 0) width = controlGestureStartWidth + dx;
        if ((controlResizeEdges & NoteRollView.EDGE_TOP) != 0) {
            height = controlGestureStartHeight - dy;
            y = controlGestureStartY + dy;
            controlHeightUserSized = true;
        }
        if ((controlResizeEdges & NoteRollView.EDGE_BOTTOM) != 0) {
            height = controlGestureStartHeight + dy;
            y = controlGestureStartY;
            controlHeightUserSized = true;
        }
        int rawWidth = width;
        width = Math.max(minWidth, Math.min(maxWidth, width));
        if ((controlResizeEdges & NoteRollView.EDGE_LEFT) != 0) x += rawWidth - width;
        controlParams.width = width;
        if ((controlResizeEdges & (NoteRollView.EDGE_TOP | NoteRollView.EDGE_BOTTOM)) != 0) {
            controlParams.height = Math.max(minHeight, Math.min(maxHeight, height));
        } else if (!controlHeightUserSized) {
            controlParams.height = WindowManager.LayoutParams.WRAP_CONTENT;
        }
        controlParams.x = Math.max(0, Math.min(screenWidth - width, x));
        if ((controlResizeEdges & (NoteRollView.EDGE_TOP | NoteRollView.EDGE_BOTTOM)) != 0) controlParams.y = Math.max(0, y);
        int activeHeight = controlParams.height > 0 ? controlParams.height : window.getHeight();
        controlParams.y = Math.max(0, Math.min(Math.max(0, screenHeight - activeHeight), controlParams.y));
        try { windowManager.updateViewLayout(controlOverlay, controlParams); } catch (Exception ignored) { }
        return true;
    }

    private int controlEdges(float x, float y, float w, float h, float edge) {
        int result = 0;
        if (x <= edge) result |= NoteRollView.EDGE_LEFT;
        if (x >= w - edge) result |= NoteRollView.EDGE_RIGHT;
        if (y <= edge) result |= NoteRollView.EDGE_TOP;
        if (y >= h - edge) result |= NoteRollView.EDGE_BOTTOM;
        return result;
    }

    private void saveControlWindowPosition() {
        if (controlParams == null) return;
        prefs.edit().putInt("overlay_x", controlParams.x).putInt("overlay_y", controlParams.y)
                .putInt("control_width_px", controlParams.width)
                .putInt("control_height_px", controlHeightUserSized ? controlParams.height : WindowManager.LayoutParams.WRAP_CONTENT)
                .putBoolean("control_overlay_resize_v3", true).apply();
    }

    private void collapseControlPanel() {
        saveControlWindowPosition();
        int oldX = controlParams == null ? prefs.getInt("overlay_x", dp(6)) : controlParams.x;
        int oldY = controlParams == null ? prefs.getInt("overlay_y", dp(8)) : controlParams.y;
        removeOverlay(controlOverlay);
        controlOverlay = null;
        pauseButton = null;
        controlPanelCollapsed = true;
        if (controlParams == null) controlParams = new WindowManager.LayoutParams();
        controlParams.gravity = Gravity.TOP | Gravity.LEFT;
        controlParams.x = Math.max(0, oldX);
        controlParams.y = Math.max(0, oldY);
        // COLLAPSE_TO_MUSIC_ICON_V1: always return to the original single music icon.
        renderCollapsedBubble(false);
    }

    private void renderCollapsedBubble(boolean showStatus) {
        if (!controlPanelCollapsed || windowManager == null || controlParams == null) return;
        int x = controlParams.x;
        int y = controlParams.y;
        removeOverlay(controlOverlay);

        LinearLayout bubble = new LinearLayout(this);
        bubble.setOrientation(LinearLayout.HORIZONTAL);
        bubble.setGravity(Gravity.CENTER_VERTICAL);
        if (showStatus) {
            bubble.setPadding(dp(10), dp(3), dp(3), dp(3));
            bubble.setBackground(roundedNoStroke(0xeef4f7f8, dp(22)));
        } else {
            bubble.setPadding(0, 0, 0, 0);
            bubble.setBackgroundColor(Color.TRANSPARENT);
        }

        collapsedMusicIcon = null;
        collapsedStatusTitle = null;
        collapsedStatusTime = null;
        collapsedExpandButton = null;
        collapsedCloseButton = null;
        miniPlaybackButton = null;
        statusBubbleMode = showStatus;

        if (showStatus) {
            LinearLayout textGroup = new LinearLayout(this);
            textGroup.setOrientation(LinearLayout.HORIZONTAL);
            textGroup.setGravity(Gravity.CENTER_VERTICAL);
            collapsedStatusTitle = new TextView(this);
            collapsedStatusTitle.setTextColor(0xff293842);
            collapsedStatusTitle.setTextSize(12);
            collapsedStatusTitle.setSingleLine(true);
            collapsedStatusTitle.setEllipsize(android.text.TextUtils.TruncateAt.END);
            int screenWidth = getResources().getDisplayMetrics().widthPixels;
            collapsedStatusTitle.setMaxWidth(Math.max(dp(60), Math.min(dp(220), (int) (screenWidth * .30f))));
            textGroup.addView(collapsedStatusTitle, new LinearLayout.LayoutParams(-2, dp(38)));

            collapsedStatusTime = new TextView(this);
            collapsedStatusTime.setTextColor(0xff818b92);
            collapsedStatusTime.setTextSize(10.5f);
            collapsedStatusTime.setSingleLine(true);
            collapsedStatusTime.setPadding(dp(7), 0, dp(8), 0);
            textGroup.addView(collapsedStatusTime, new LinearLayout.LayoutParams(-2, dp(38)));
            bubble.addView(textGroup, new LinearLayout.LayoutParams(-2, dp(38)));
            attachCollapsedBubbleDrag(textGroup, bubble);

            collapsedExpandButton = bubbleButton("⤢", Color.TRANSPARENT, 0xff65727a);
            LinearLayout.LayoutParams expandParams = new LinearLayout.LayoutParams(dp(30), dp(34));
            expandParams.setMargins(dp(1), 0, dp(1), 0);
            bubble.addView(collapsedExpandButton, expandParams);
            collapsedExpandButton.setOnClickListener(v -> showControlPanel());
            collapsedExpandButton.setContentDescription("展开洛克乐器演奏控制面板");

            collapsedCloseButton = bubbleButton("×", Color.TRANSPARENT, 0xff455762);
            LinearLayout.LayoutParams closeParams = new LinearLayout.LayoutParams(dp(30), dp(34));
            closeParams.setMargins(dp(1), 0, dp(1), 0);
            bubble.addView(collapsedCloseButton, closeParams);
            collapsedCloseButton.setOnClickListener(v -> {
                statusBubbleDismissed = true;
                refreshMiniPlaybackButton();
            });
            collapsedCloseButton.setContentDescription("收起曲名和播放时间");
            updateCollapsedStatusText();
            controlParams.width = WindowManager.LayoutParams.WRAP_CONTENT;
        } else {
            TextView open = new TextView(this);
            open.setText("♫");
            open.setTextSize(21);
            open.setTextColor(Color.WHITE);
            open.setGravity(Gravity.CENTER);
            open.setMinWidth(dp(38));
            open.setMinHeight(dp(38));
            open.setBackground(roundedNoStroke(0xff455667, dp(22)));
            collapsedMusicIcon = open;
            bubble.addView(open, new LinearLayout.LayoutParams(dp(38), dp(38)));
            attachCollapsedBubbleDrag(open, bubble);
            controlParams.width = dp(38);
        }

        controlParams.height = showStatus ? dp(44) : dp(38);
        controlParams.gravity = Gravity.TOP | Gravity.LEFT;
        controlParams.x = x;
        controlParams.y = y;
        controlOverlay = bubble;
        collapsedBubble = bubble;
        try {
            windowManager.addView(controlOverlay, controlParams);
            android.util.DisplayMetrics metrics = getResources().getDisplayMetrics();
            int width = bubble.getWidth() > 0 ? bubble.getWidth() : (showStatus ? metrics.widthPixels - dp(24) : dp(44));
            controlParams.x = Math.max(0, Math.min(Math.max(0, metrics.widthPixels - width), controlParams.x));
            windowManager.updateViewLayout(controlOverlay, controlParams);
            prefs.edit().putInt("overlay_x", controlParams.x).putInt("overlay_y", controlParams.y).apply();
        } catch (Exception e) {
            controlOverlay = null;
            collapsedBubble = null;
            miniPlaybackButton = null;
            toast("悬浮按钮无法显示，请回到主界面重新开启校准入口。");
        }
    }

    private TextView bubbleButton(String text, int backgroundColor, int textColor) {
        TextView button = new TextView(this);
        button.setText(text);
        button.setTextSize(17);
        button.setTextColor(textColor);
        button.setGravity(Gravity.CENTER);
        button.setBackground(roundedNoStroke(backgroundColor, dp(18)));
        return button;
    }

    private void attachCollapsedBubbleDrag(View handle, View bubble) {
        handle.setOnTouchListener(new View.OnTouchListener() {
            float downX, downY;
            int originX, originY;
            boolean moved;
            @Override public boolean onTouch(View v, MotionEvent event) {
                if (controlParams == null) return false;
                switch (event.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        downX = event.getRawX(); downY = event.getRawY();
                        originX = controlParams.x; originY = controlParams.y; moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float dx = event.getRawX() - downX;
                        float dy = event.getRawY() - downY;
                        if (Math.abs(dx) + Math.abs(dy) > dp(5)) moved = true;
                        if (moved) {
                            android.util.DisplayMetrics m = getResources().getDisplayMetrics();
                            int bw = Math.max(dp(38), bubble.getWidth());
                            controlParams.x = Math.max(0, Math.min(m.widthPixels - bw, originX + Math.round(dx)));
                            controlParams.y = Math.max(0, Math.min(m.heightPixels - Math.max(dp(38), bubble.getHeight()), originY + Math.round(dy)));
                            try { windowManager.updateViewLayout(bubble, controlParams); } catch (Exception ignored) { }
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        prefs.edit().putInt("overlay_x", controlParams.x).putInt("overlay_y", controlParams.y).apply();
                        if (!moved) showControlPanel();
                        return true;
                    case MotionEvent.ACTION_CANCEL:
                        prefs.edit().putInt("overlay_x", controlParams.x).putInt("overlay_y", controlParams.y).apply();
                        return true;
                }
                return false;
            }
        });
    }

    private void updateCollapsedStatusText() {
        if (collapsedStatusTitle == null || collapsedStatusTime == null) return;
        String title = prefs.getString(MainActivity.KEY_SONG_NAME,
                currentSong == null ? "洛克乐器演奏" : currentSong.name);
        if (title == null || title.trim().isEmpty()) title = "洛克乐器演奏";
        long duration = currentSong != null ? currentSong.durationMicros : Math.max(playbackRangeEndMicros, 1L);
        collapsedStatusTitle.setText(title);
        collapsedStatusTime.setText(NoteRollView.formatTime(playbackPositionMicros) + "–" + NoteRollView.formatTime(duration));
    }

    private void refreshMiniPlaybackButton() {
        boolean shouldShowStatus = false; // COLLAPSE_TO_MUSIC_ICON_V1
        if (controlPanelCollapsed && controlOverlay != null && statusBubbleMode != shouldShowStatus) {
            renderCollapsedBubble(shouldShowStatus);
        }
        updateCollapsedStatusText();
        if (miniPlaybackButton != null) {
            boolean alive = playbackThread != null && playbackThread.isAlive();
            miniPlaybackButton.setText(alive && playbackActive && !paused ? "Ⅱ" : "▶");
            miniPlaybackButton.setContentDescription(alive && playbackActive && !paused ? "暂停自动演奏" : "开始或继续演奏");
        }
        refreshUnifiedPlaybackButton();
    }

    private void removeControlPanel() {
        if (controlParams != null && controlOverlay != null) {
            prefs.edit().putInt("overlay_x", controlParams.x).putInt("overlay_y", controlParams.y).apply();
        }
        removeOverlay(controlOverlay);
        controlOverlay = null;
        controlParams = null;
        pauseButton = null;
        miniPlaybackButton = null;
        collapsedBubble = null;
        collapsedStatusTitle = null;
        collapsedStatusTime = null;
        collapsedExpandButton = null;
        collapsedCloseButton = null;
        controlPanelCollapsed = false;
        statusBubbleMode = false;
    }

    private void toggleNoteRoll() {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            mainHandler.post(this::toggleNoteRoll);
            return;
        }
        dismissSegmentDialog();
        if (noteRollView != null) {
            removeOverlay(noteRollView);
            noteRollView = null;
            updateControlPanelPlaybackButtons();
            prefs.edit().putBoolean("note_roll_enabled", false).apply();
            toast("音符谱面已隐藏。再次点“谱面”可显示。 ");
        } else {
            prefs.edit().putBoolean("note_roll_enabled", true).apply();
            showNoteRoll();
        }
    }

    private MidiParser.MidiSong readCurrentSong() {
        String path = prefs.getString(MainActivity.KEY_SONG_PATH, "");
        if (path == null || path.isEmpty() || !new File(path).isFile()) return null;
        try { return MidiParser.parse(new File(path)); }
        catch (Exception ex) { toast("谱面载入失败：" + ex.getMessage()); return null; }
    }

    private void showNoteRoll() {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            mainHandler.post(this::showNoteRoll);
            return;
        }
        if (windowManager == null) return;
        MidiParser.MidiSong song = readCurrentSong();
        if (song == null) {
            toast("请先在洛克乐器演奏主界面导入 MIDI 曲谱，再显示音符谱面。");
            return;
        }
        currentSong = song;
        if (noteRollView == null) {
            noteRollView = new NoteRollView(this);
            noteRollView.setInteractionListener(new NoteRollView.InteractionListener() {
                @Override public void onSeek(long positionMicros) { seekPlaybackTo(positionMicros); }
                @Override public void onPracticeRangeChange(long startMicros, long endMicros) { savePracticeRangeMicros(startMicros, endMicros); }
                @Override public void onWindowGesture(int mode, int edges, int dx, int dy, int phase) {
                    handleNoteRollWindowGesture(mode, edges, dx, dy, phase);
                }
                @Override public void onClose() {
                    removeOverlay(noteRollView);
                    noteRollView = null;
                    updateControlPanelPlaybackButtons();
                    prefs.edit().putBoolean("note_roll_enabled", false).apply();
                }
                @Override public void onTogglePlayPause() {
                    if (playbackThread != null && playbackThread.isAlive()) togglePause();
                    else startPlayback();
                    refreshMiniPlaybackButton();
                }
                @Override public void onRewind() { rewindPlaybackToStart(); }
                @Override public void onBeginSeekGesture() { beginNoteRollSeekGesture(); }
                @Override public void onEndSeekGesture() { endNoteRollSeekGesture(); }
                @Override public void onEditSegment() { toggleRangeEditingMode(); }
                @Override public void onToggleAbLoop() { toggleAbLoopEnabled(); }
                @Override public void onSpeedChange(int speedPercent) { changePlaybackSpeedFromNoteRoll(speedPercent); }
            });
            android.util.DisplayMetrics metrics = getResources().getDisplayMetrics();
            int screenWidth = Math.max(1, metrics.widthPixels);
            int screenHeight = Math.max(1, metrics.heightPixels);
            int minWidth = Math.min(dp(150), Math.max(dp(110), screenWidth - dp(8)));
            int maxWidth = Math.max(minWidth, screenWidth - dp(8));
            int minHeight = Math.min(dp(100), Math.max(dp(78), screenHeight - dp(12)));
            int maxHeight = Math.max(minHeight, Math.min(screenHeight - dp(8), (int) (screenHeight * .58f)));
            int defaultWidth = Math.min(maxWidth, Math.max(minWidth, Math.round(screenWidth * .32f)));
            int defaultHeight = Math.min(maxHeight, dp(132));
        if (!prefs.getBoolean("note_roll_header_layout_v4", false)) {
            int savedHeight = prefs.getInt("note_roll_height_px", -1);
            if (savedHeight > 0 && savedHeight <= dp(118)) {
                prefs.edit().putInt("note_roll_height_px", defaultHeight).apply();
            }
            prefs.edit().putBoolean("note_roll_header_layout_v4", true).apply();
        }
        boolean noteLayoutV3 = prefs.getBoolean("note_roll_layout_v3", false);
            int width = noteLayoutV3 ? Math.max(minWidth, Math.min(maxWidth, prefs.getInt("note_roll_width_px", defaultWidth))) : defaultWidth;
            int height = noteLayoutV3 ? Math.max(minHeight, Math.min(maxHeight, prefs.getInt("note_roll_height_px", defaultHeight))) : defaultHeight;
            noteRollParams = new WindowManager.LayoutParams(
                    width, height,
                    WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                            | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                    PixelFormat.TRANSLUCENT);
            noteRollParams.gravity = Gravity.TOP | Gravity.LEFT;
            noteRollParams.x = noteLayoutV3 ? Math.max(0, Math.min(screenWidth - width, prefs.getInt("note_roll_x", dp(6)))) : dp(6);
            noteRollParams.y = noteLayoutV3 ? Math.max(0, Math.min(screenHeight - height, prefs.getInt("note_roll_y", dp(5)))) : dp(5);
            try { windowManager.addView(noteRollView, noteRollParams);
                prefs.edit().putBoolean("note_roll_layout_v3", true).apply();
            }
            catch (Exception e) {
                noteRollView = null;
                noteRollParams = null;
                toast("音符谱面无法显示，请重新开启无障碍服务后重试。");
                return;
            }
        }
        refreshNoteRollData();
        updateControlPanelPlaybackButtons();
    }

    private void beginNoteRollSeekGesture() {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            mainHandler.post(this::beginNoteRollSeekGesture);
            return;
        }
        playbackUiGeneration++;
        synchronized (playbackLock) {
            playbackWasRunningBeforeNoteScrub = playbackThread != null && playbackThread.isAlive()
                    && playbackActive && !paused && !stopRequested;
            if (playbackWasRunningBeforeNoteScrub) {
                paused = true;
                pauseStartedMs = SystemClock.elapsedRealtime();
                playbackLock.notifyAll();
            }
        }
    }

    private void endNoteRollSeekGesture() {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            mainHandler.post(this::endNoteRollSeekGesture);
            return;
        }
        playbackUiGeneration++;
        synchronized (playbackLock) {
            if (playbackWasRunningBeforeNoteScrub && playbackThread != null && playbackThread.isAlive()
                    && playbackActive && paused && !stopRequested) {
                long now = SystemClock.elapsedRealtime();
                pausedDurationMs += Math.max(0L, now - pauseStartedMs);
                paused = false;
            }
            playbackWasRunningBeforeNoteScrub = false;
            playbackLock.notifyAll();
        }
        refreshMiniPlaybackButton();
    }

    private void toggleUnifiedPlayback() {
        if (playbackThread != null && playbackThread.isAlive() && playbackActive && !stopRequested) {
            togglePause();
        } else {
            startPlayback();
        }
        refreshUnifiedPlaybackButton();
    }

    private void refreshUnifiedPlaybackButton() {
        if (!(startPlaybackButton instanceof TextView)) return;
        TextView button = (TextView) startPlaybackButton;
        boolean active = playbackThread != null && playbackThread.isAlive()
                && playbackActive && !paused && !stopRequested;
        button.setText("演奏");
        button.setTextColor(Color.WHITE);
        button.setBackground(rounded(active ? 0xff4c8d80 : 0xff4b6279, dp(8)));
        button.setContentDescription(active ? "正在演奏，点击暂停" : "演奏，点击开始或继续");
    }

    private void updateControlPanelPlaybackButtons() {
        int visibility = noteRollView == null ? View.VISIBLE : View.GONE;
        if (startPlaybackButton != null) startPlaybackButton.setVisibility(visibility);
        if (pauseButton != null) pauseButton.setVisibility(visibility);
        if (rewindControlButton != null) rewindControlButton.setVisibility(visibility);
        if (noteRollControlButton != null) noteRollControlButton.setVisibility(visibility);
        refreshUnifiedPlaybackButton();
    }

    private void beginRangeEditingFromControl() {
        if (currentSong == null) currentSong = readCurrentSong();
        if (currentSong == null) {
            toast("请先导入 MIDI 曲谱。 ");
            return;
        }
        if (noteRollView == null) showNoteRoll();
        if (noteRollView != null) {
            if (playbackActive && !paused) togglePause();
            dismissSegmentDialog();
            noteRollView.setRangeEditing(true);
            toast("片段选择已开启：直接在谱面上横向拖动，调整最近的起点或终点；点“选”退出。 ");
        }
    }

    private void toggleRangeEditingMode() {
        if (noteRollView == null) {
            beginRangeEditingFromControl();
            return;
        }
        dismissSegmentDialog();
        boolean enable = !noteRollView.isRangeEditing();
        if (enable && playbackActive && !paused) togglePause();
        noteRollView.setRangeEditing(enable);
        toast(enable ? "片段选择已开启：在谱面上横向拖动起止点。 " : "已退出片段选择。 ");
    }

    private void toggleAbLoopEnabled() {
        boolean enabled = !prefs.getBoolean(KEY_AB_LOOP_ENABLED, false);
        prefs.edit().putBoolean(KEY_AB_LOOP_ENABLED, enabled).apply();
        if (currentSong == null) currentSong = readCurrentSong();
        if (currentSong != null) {
            long duration = Math.max(1L, currentSong.durationMicros);
            long activeStart = 0L;
            long activeEnd = duration;
            if (enabled) {
                long start = Math.max(0L, prefs.getLong(KEY_RANGE_START_MS, 0L)) * 1000L;
                long rawEndMs = prefs.getLong(KEY_RANGE_END_MS, -1L);
                long end = (rawEndMs <= 0L || rawEndMs * 1000L > duration)
                        ? duration : rawEndMs * 1000L;
                if (end <= start) { start = 0L; end = duration; }
                activeStart = Math.min(start, duration);
                activeEnd = Math.max(activeStart + 1L, Math.min(duration, end));
                if (playbackPositionMicros < activeStart || playbackPositionMicros >= activeEnd) {
                    playbackPositionMicros = activeStart;
                    playbackBaseMicros = activeStart;
                    if (playbackThread != null && playbackThread.isAlive() && playbackActive) {
                        seekRequestMicros = activeStart;
                        seekRequestVersion++;
                        synchronized (playbackLock) { playbackLock.notifyAll(); }
                    }
                }
            }
            long previousStart = playbackRangeStartMicros;
            long previousEnd = playbackRangeEndMicros;
            playbackRangeStartMicros = activeStart;
            playbackRangeEndMicros = activeEnd;
            if ((previousStart != activeStart || previousEnd != activeEnd)
                    && playbackThread != null && playbackThread.isAlive() && playbackActive) {
                // Stop the old worker so the next start uses the new active scope.
                stopPlayback();
            }
        }
        if (noteRollView != null) {
            noteRollView.setAbLoopEnabled(enabled);
            refreshNoteRollData();
        }
        toast(enabled ? "A/B循环已开启；长按谱面上的 A/B循环 可编辑起止点。"
                : "A/B循环已关闭，播放范围已恢复整首歌。起止点设置会保留。");
    }

    private boolean saveAbLoopSettings(CheckBox enabled, EditText aField, EditText bField) {
        if (currentSong == null) currentSong = readCurrentSong();
        if (currentSong == null) {
            toast("请先导入 MIDI 曲谱。");
            return false;
        }
        long durationMs = Math.max(1L, (currentSong.durationMicros + 999L) / 1000L);
        long startMs;
        long endMs;
        try {
            double aSeconds = Double.parseDouble(aField.getText().toString().trim());
            double bSeconds = Double.parseDouble(bField.getText().toString().trim());
            if (!Double.isFinite(aSeconds) || !Double.isFinite(bSeconds)
                    || aSeconds < 0 || bSeconds < 0) throw new NumberFormatException();
            startMs = Math.round(aSeconds * 1000.0);
            endMs = Math.round(bSeconds * 1000.0);
        } catch (Exception ex) {
            toast("请输入有效的 A、B 时间（秒）。");
            return false;
        }
        if (startMs >= durationMs || endMs > durationMs || endMs <= startMs) {
            toast("B 终点必须大于 A 起点，并且不能超过歌曲时长。");
            return false;
        }

        long startMicros = startMs * 1000L;
        long endMicros = endMs * 1000L;
        boolean loopEnabled = enabled.isChecked();
        long effectiveStart = loopEnabled ? startMicros : 0L;
        long effectiveEnd = loopEnabled ? endMicros : durationMs * 1000L;
        boolean rangeChanged = effectiveStart != playbackRangeStartMicros
                || effectiveEnd != playbackRangeEndMicros;
        prefs.edit().putBoolean(KEY_AB_LOOP_ENABLED, loopEnabled)
                .putLong(KEY_RANGE_START_MS, startMs).putLong(KEY_RANGE_END_MS, endMs).apply();
        playbackRangeStartMicros = effectiveStart;
        playbackRangeEndMicros = effectiveEnd;
        if (rangeChanged && playbackThread != null && playbackThread.isAlive()) {
            // The running worker captured the old scope. Stop cleanly; the next start uses the new scope.
            stopPlayback();
        }
        if (loopEnabled && (playbackPositionMicros < effectiveStart || playbackPositionMicros >= effectiveEnd)) {
            playbackPositionMicros = effectiveStart;
            playbackBaseMicros = effectiveStart;
        }
        if (noteRollView != null) refreshNoteRollData();
        return true;
    }

    private String formatSecondsField(long millis) {
        String value = String.format(java.util.Locale.US, "%.2f", Math.max(0L, millis) / 1000.0);
        while (value.contains(".") && value.endsWith("0")) value = value.substring(0, value.length() - 1);
        if (value.endsWith(".")) value = value.substring(0, value.length() - 1);
        return value;
    }

    private TextView abSettingsLabel(String text) {
        TextView label = new TextView(this);
        label.setText(text);
        label.setTextColor(0xff40594c);
        label.setTextSize(15);
        return label;
    }

    private EditText abSecondsField(String initialValue) {
        EditText field = new EditText(this);
        field.setSingleLine(true);
        field.setText(initialValue);
        field.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        field.setTextColor(0xff30473d);
        field.setTextSize(22);
        field.setPadding(dp(12), dp(6), dp(12), dp(6));
        field.setBackground(roundedBorder(0xffffffff, 0xffdce5de, dp(12)));
        field.setSelectAllOnFocus(false);
        return field;
    }

    // A compact, keyboard-focusable floating card patterned after the user's reference image.
    private void showSegmentDialog() {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            mainHandler.post(this::showSegmentDialog);
            return;
        }
        if (windowManager == null) return;
        if (currentSong == null) currentSong = readCurrentSong();
        if (currentSong == null) {
            toast("请先导入 MIDI 曲谱。");
            return;
        }
        dismissSegmentDialog();
        if (playbackActive && !paused) togglePause();

        long durationMs = Math.max(1L, (currentSong.durationMicros + 999L) / 1000L);
        long startMs = Math.max(0L, Math.min(durationMs - 1L, prefs.getLong(KEY_RANGE_START_MS, 0L)));
        long storedEnd = prefs.getLong(KEY_RANGE_END_MS, -1L);
        long endMs = storedEnd <= 0L || storedEnd > durationMs ? durationMs : storedEnd;
        if (endMs <= startMs) { startMs = 0L; endMs = durationMs; }

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(10), dp(7), dp(10), dp(8));
        card.setBackground(roundedBorder(0xfffcfdfb, 0xffdce5de, dp(15)));
        card.setClickable(true);
        card.setFocusableInTouchMode(true);

        LinearLayout titleRow = new LinearLayout(this);
        titleRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView heading = new TextView(this);
        heading.setText("☷  练习设置");
        heading.setTextColor(0xff304b3e);
        heading.setTextSize(17);
        heading.setTypeface(null, android.graphics.Typeface.BOLD);
        titleRow.addView(heading, new LinearLayout.LayoutParams(0, dp(34), 1f));
        TextView close = new TextView(this);
        close.setText("×");
        close.setTextSize(21);
        close.setTextColor(0xff304b3e);
        close.setGravity(Gravity.CENTER);
        titleRow.addView(close, new LinearLayout.LayoutParams(dp(34), dp(34)));
        card.addView(titleRow);
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        ScrollView bodyScroll = new ScrollView(this);
        bodyScroll.setFillViewport(false);
        bodyScroll.addView(body);
        card.addView(bodyScroll, new LinearLayout.LayoutParams(-1, 0, 1f));

        CheckBox enabled = new CheckBox(this);
        enabled.setText("A/B 循环");
        enabled.setTextSize(15);
        enabled.setTextColor(0xff40594c);
        enabled.setButtonTintList(ColorStateList.valueOf(0xff547c68));
        enabled.setChecked(prefs.getBoolean(KEY_AB_LOOP_ENABLED, false));
        LinearLayout.LayoutParams checkParams = new LinearLayout.LayoutParams(-1, dp(31));
        checkParams.setMargins(0, dp(2), 0, dp(4));
        body.addView(enabled, checkParams);

        LinearLayout columns = new LinearLayout(this);
        columns.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout aColumn = new LinearLayout(this);
        aColumn.setOrientation(LinearLayout.VERTICAL);
        LinearLayout bColumn = new LinearLayout(this);
        bColumn.setOrientation(LinearLayout.VERTICAL);
        aColumn.addView(abSettingsLabel("A 起点（秒）"));
        bColumn.addView(abSettingsLabel("B 终点（秒）"));
        EditText aField = abSecondsField(formatSecondsField(startMs));
        EditText bField = abSecondsField(formatSecondsField(endMs));
        LinearLayout.LayoutParams inputParams = new LinearLayout.LayoutParams(-1, dp(36));
        inputParams.setMargins(0, dp(4), 0, 0);
        aColumn.addView(aField, inputParams);
        LinearLayout.LayoutParams bInputParams = new LinearLayout.LayoutParams(-1, dp(36));
        bInputParams.setMargins(0, dp(8), 0, 0);
        bColumn.addView(bField, bInputParams);
        LinearLayout.LayoutParams aColParams = new LinearLayout.LayoutParams(0, -2, 1f);
        aColParams.setMargins(0, 0, dp(7), 0);
        LinearLayout.LayoutParams bColParams = new LinearLayout.LayoutParams(0, -2, 1f);
        bColParams.setMargins(dp(4), 0, 0, 0);
        columns.addView(aColumn, aColParams);
        columns.addView(bColumn, bColParams);
        body.addView(columns);

        LinearLayout setButtons = new LinearLayout(this);
        setButtons.setOrientation(LinearLayout.HORIZONTAL);
        Button setA = dialogButton("当前位置设为 A", 0xfff8fbf8);
        setA.setTextColor(0xff304b3e);
        setA.setBackground(roundedBorder(0xfff8fbf8, 0xffdce5de, dp(12)));
        Button setB = dialogButton("当前位置设为 B", 0xfff8fbf8);
        setB.setTextColor(0xff304b3e);
        setB.setBackground(roundedBorder(0xfff8fbf8, 0xffdce5de, dp(12)));
        LinearLayout.LayoutParams setAParams = new LinearLayout.LayoutParams(0, dp(32), 1f);
        setAParams.setMargins(0, dp(8), dp(8), 0);
        LinearLayout.LayoutParams setBParams = new LinearLayout.LayoutParams(0, dp(40), 1f);
        setBParams.setMargins(dp(4), dp(8), 0, 0);
        setButtons.addView(setA, setAParams);
        setButtons.addView(setB, setBParams);
        body.addView(setButtons);
        setA.setOnClickListener(v -> aField.setText(formatSecondsField(playbackPositionMicros / 1000L)));
        setB.setOnClickListener(v -> bField.setText(formatSecondsField(playbackPositionMicros / 1000L)));

        LinearLayout footerButtons = new LinearLayout(this);
        footerButtons.setOrientation(LinearLayout.HORIZONTAL);
        Button reset = dialogButton("重置 A/B", 0xfff8fbf8);
        reset.setTextColor(0xff304b3e);
        reset.setBackground(roundedBorder(0xfff8fbf8, 0xffdce5de, dp(12)));
        Button done = dialogButton("完成", 0xff547c68);
        done.setTextColor(Color.WHITE);
        LinearLayout.LayoutParams resetParams = new LinearLayout.LayoutParams(0, dp(30), 1f);
        resetParams.setMargins(0, dp(8), dp(6), 0);
        LinearLayout.LayoutParams doneParams = new LinearLayout.LayoutParams(0, dp(36), 1f);
        doneParams.setMargins(dp(6), dp(8), 0, 0);
        footerButtons.addView(reset, resetParams);
        footerButtons.addView(done, doneParams);
        body.addView(footerButtons);
        reset.setOnClickListener(v -> {
            long resetDurationMs = Math.max(1L, (currentSong.durationMicros + 999L) / 1000L);
            aField.setText("0");
            bField.setText(formatSecondsField(resetDurationMs));
            prefs.edit().putLong(KEY_RANGE_START_MS, 0L)
                    .putLong(KEY_RANGE_END_MS, resetDurationMs).apply();
            playbackRangeStartMicros = 0L;
            playbackRangeEndMicros = currentSong.durationMicros;
            if (playbackPositionMicros < 0L || playbackPositionMicros > currentSong.durationMicros) {
                playbackPositionMicros = 0L;
                playbackBaseMicros = 0L;
            }
            if (noteRollView != null) refreshNoteRollData();
            toast("A/B起止点已重置：A=0，B=整首歌时长。");
        });

        TextView resizeHandle = new TextView(this);
        resizeHandle.setText("↘ 拖动调整大小");
        resizeHandle.setTextColor(0xff71867a);
        resizeHandle.setTextSize(9);
        resizeHandle.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        resizeHandle.setPadding(0, 0, dp(4), 0);
        card.addView(resizeHandle, new LinearLayout.LayoutParams(-1, dp(15)));

        int screenWidth = getResources().getDisplayMetrics().widthPixels;
        int screenHeight = getResources().getDisplayMetrics().heightPixels;
        int defaultWidth = Math.min(Math.max(dp(230), screenWidth - dp(36)), dp(310));
        int defaultHeight = Math.min(Math.max(dp(190), screenHeight - dp(40)), dp(245));
        int width = Math.max(dp(220), Math.min(Math.min(screenWidth - dp(24), dp(310)),
                prefs.getInt("ab_dialog_width_px", defaultWidth)));
        int height = Math.max(dp(185), Math.min(Math.min(screenHeight - dp(24), dp(245)),
                prefs.getInt("ab_dialog_height_px", defaultHeight)));
        WindowManager.LayoutParams overlayParams = new WindowManager.LayoutParams(
                width, height,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
                PixelFormat.TRANSLUCENT);
        overlayParams.gravity = Gravity.TOP | Gravity.LEFT;
        overlayParams.x = Math.max(0, Math.min(screenWidth - width,
                prefs.getInt("ab_dialog_x", Math.max(0, (screenWidth - width) / 2))));
        overlayParams.y = Math.max(0, Math.min(screenHeight - height,
                prefs.getInt("ab_dialog_y", dp(24))));
        overlayParams.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE;
        segmentOverlay = card;
        segmentOverlayParams = overlayParams;
        heading.setOnTouchListener(new View.OnTouchListener() {
            float downX, downY;
            int startX, startY;
            boolean moved;
            @Override public boolean onTouch(View v, MotionEvent event) {
                if (segmentOverlayParams == null) return false;
                switch (event.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        downX = event.getRawX(); downY = event.getRawY();
                        startX = segmentOverlayParams.x; startY = segmentOverlayParams.y;
                        moved = false; return true;
                    case MotionEvent.ACTION_MOVE:
                        float dx = event.getRawX() - downX;
                        float dy = event.getRawY() - downY;
                        if (Math.hypot(dx, dy) > dp(4)) moved = true;
                        if (moved) {
                            segmentOverlayParams.x = Math.max(0, Math.min(
                                    getResources().getDisplayMetrics().widthPixels - segmentOverlayParams.width,
                                    startX + Math.round(dx)));
                            segmentOverlayParams.y = Math.max(0, Math.min(
                                    getResources().getDisplayMetrics().heightPixels - segmentOverlayParams.height,
                                    startY + Math.round(dy)));
                            try { windowManager.updateViewLayout(card, segmentOverlayParams); } catch (Exception ignored) { }
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (moved) prefs.edit().putInt("ab_dialog_x", segmentOverlayParams.x)
                                .putInt("ab_dialog_y", segmentOverlayParams.y).apply();
                        return true;
                    default: return true;
                }
            }
        });
        resizeHandle.setOnTouchListener(new View.OnTouchListener() {
            float downX, downY;
            int startWidth, startHeight;
            boolean moved;
            @Override public boolean onTouch(View v, MotionEvent event) {
                if (segmentOverlayParams == null) return false;
                switch (event.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        downX = event.getRawX(); downY = event.getRawY();
                        startWidth = segmentOverlayParams.width; startHeight = segmentOverlayParams.height;
                        moved = false; return true;
                    case MotionEvent.ACTION_MOVE:
                        float dx = event.getRawX() - downX;
                        float dy = event.getRawY() - downY;
                        if (Math.hypot(dx, dy) > dp(4)) moved = true;
                        if (moved) {
                            int maxW = getResources().getDisplayMetrics().widthPixels - dp(16);
                            int maxH = getResources().getDisplayMetrics().heightPixels - dp(16);
                            segmentOverlayParams.width = Math.max(dp(220), Math.min(maxW, startWidth + Math.round(dx)));
                            segmentOverlayParams.height = Math.max(dp(185), Math.min(maxH, startHeight + Math.round(dy)));
                            try { windowManager.updateViewLayout(card, segmentOverlayParams); } catch (Exception ignored) { }
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (moved) prefs.edit().putInt("ab_dialog_width_px", segmentOverlayParams.width)
                                .putInt("ab_dialog_height_px", segmentOverlayParams.height).apply();
                        return true;
                    default: return true;
                }
            }
        });
        card.setOnKeyListener((v, keyCode, event) -> {
            if (keyCode == android.view.KeyEvent.KEYCODE_BACK
                    && event.getAction() == android.view.KeyEvent.ACTION_UP) {
                dismissSegmentDialog();
                return true;
            }
            return false;
        });
        card.setOnTouchListener((v, event) -> {
            if (event.getActionMasked() == MotionEvent.ACTION_OUTSIDE) {
                dismissSegmentDialog();
                return true;
            }
            return false;
        });
        close.setOnClickListener(v -> dismissSegmentDialog());
        done.setOnClickListener(v -> {
            if (saveAbLoopSettings(enabled, aField, bField)) dismissSegmentDialog();
        });
        try {
            windowManager.addView(card, overlayParams);
            card.requestFocus();
        } catch (Exception ex) {
            segmentOverlay = null;
            segmentOverlayParams = null;
            toast("A/B循环设置无法显示，请重新开启无障碍服务后重试。");
        }
    }

    private void savePracticeRangeMicros(long startMicros, long endMicros) {
        if (currentSong == null) currentSong = readCurrentSong();
        if (currentSong == null) return;
        long duration = Math.max(1L, currentSong.durationMicros);
        long minGap = Math.min(duration, Math.min(500_000L, Math.max(30_000L, duration / 2000L)));
        long start = Math.max(0L, Math.min(startMicros, duration - minGap));
        long end = Math.max(start + minGap, Math.min(duration, endMicros));
        prefs.edit().putLong(KEY_RANGE_START_MS, start / 1000L)
                .putLong(KEY_RANGE_END_MS, end / 1000L).apply();
        boolean loopEnabled = prefs.getBoolean(KEY_AB_LOOP_ENABLED, false);
        playbackRangeStartMicros = loopEnabled ? start : 0L;
        playbackRangeEndMicros = loopEnabled ? end : duration;
        if (loopEnabled && (playbackPositionMicros < start || playbackPositionMicros >= end)) {
            playbackPositionMicros = start;
            playbackBaseMicros = start;
            if (playbackThread != null && playbackThread.isAlive() && playbackActive) {
                seekRequestMicros = start;
                seekRequestVersion++;
                synchronized (playbackLock) { playbackLock.notifyAll(); }
            }
        }
        refreshNoteRollData();
    }

    private void handleNoteRollWindowGesture(int mode, int edges, int dx, int dy, int phase) {
        if (noteRollParams == null || noteRollView == null || windowManager == null) return;
        if (phase == NoteRollView.PHASE_START) {
            noteRollGestureStartX = noteRollParams.x;
            noteRollGestureStartY = noteRollParams.y;
            noteRollGestureStartWidth = noteRollParams.width;
            noteRollGestureStartHeight = noteRollParams.height;
            return;
        }
        if (phase == NoteRollView.PHASE_UPDATE) {
            android.util.DisplayMetrics metrics = getResources().getDisplayMetrics();
            int screenWidth = Math.max(1, metrics.widthPixels);
            int screenHeight = Math.max(1, metrics.heightPixels);
            int width = noteRollGestureStartWidth;
            int height = noteRollGestureStartHeight;
            int x = noteRollGestureStartX;
            int y = noteRollGestureStartY;
            if (mode == NoteRollView.MODE_MOVE) {
                x = noteRollGestureStartX + dx;
                y = noteRollGestureStartY + dy;
            } else {
                if ((edges & NoteRollView.EDGE_LEFT) != 0) {
                    width = noteRollGestureStartWidth - dx;
                    x = noteRollGestureStartX + dx;
                }
                if ((edges & NoteRollView.EDGE_RIGHT) != 0) width = noteRollGestureStartWidth + dx;
                if ((edges & NoteRollView.EDGE_TOP) != 0) {
                    height = noteRollGestureStartHeight - dy;
                    y = noteRollGestureStartY + dy;
                }
                if ((edges & NoteRollView.EDGE_BOTTOM) != 0) height = noteRollGestureStartHeight + dy;
                int minWidth = Math.min(dp(150), Math.max(dp(110), screenWidth - dp(8)));
                int maxWidth = Math.max(minWidth, screenWidth - dp(8));
                int minHeight = Math.min(dp(100), Math.max(dp(78), screenHeight - dp(12)));
                int maxHeight = Math.max(minHeight, Math.min(screenHeight - dp(8), (int) (screenHeight * .58f)));
                int unclampedWidth = width;
                int unclampedHeight = height;
                width = Math.max(minWidth, Math.min(maxWidth, width));
                height = Math.max(minHeight, Math.min(maxHeight, height));
                if ((edges & NoteRollView.EDGE_LEFT) != 0) x += unclampedWidth - width;
                if ((edges & NoteRollView.EDGE_TOP) != 0) y += unclampedHeight - height;
            }
            int minWidth = Math.min(dp(150), Math.max(dp(110), screenWidth - dp(8)));
            int maxWidth = Math.max(minWidth, screenWidth - dp(8));
            int minHeight = Math.min(dp(100), Math.max(dp(78), screenHeight - dp(12)));
            int maxHeight = Math.max(minHeight, Math.min(screenHeight - dp(8), (int) (screenHeight * .58f)));
            noteRollParams.width = Math.max(minWidth, Math.min(maxWidth, width));
            noteRollParams.height = Math.max(minHeight, Math.min(maxHeight, height));
            noteRollParams.x = Math.max(0, Math.min(screenWidth - noteRollParams.width, x));
            noteRollParams.y = Math.max(0, Math.min(screenHeight - noteRollParams.height, y));
            try { windowManager.updateViewLayout(noteRollView, noteRollParams); } catch (Exception ignored) { }
        } else if (phase == NoteRollView.PHASE_END) {
            prefs.edit().putInt("note_roll_width_px", noteRollParams.width)
                    .putInt("note_roll_height_px", noteRollParams.height)
                    .putInt("note_roll_x", noteRollParams.x)
                    .putInt("note_roll_y", noteRollParams.y).apply();
            refreshNoteRollData();
        }
    }

    private void refreshNoteRollData() {
        if (noteRollView == null) return;
        if (currentSong == null) currentSong = readCurrentSong();
        if (currentSong == null) return;
        long duration = Math.max(1L, currentSong.durationMicros);
        long startMs = Math.max(0L, prefs.getLong(KEY_RANGE_START_MS, 0L));
        long savedEnd = prefs.getLong(KEY_RANGE_END_MS, -1L);
        long endMs = (savedEnd <= 0L || savedEnd > duration / 1000L)
                ? duration / 1000L : savedEnd;
        long pointStart = Math.min(duration, startMs * 1000L);
        long pointEnd = Math.min(duration, endMs * 1000L);
        if (pointEnd <= pointStart) { pointStart = 0L; pointEnd = duration; }
        boolean loopEnabled = prefs.getBoolean(KEY_AB_LOOP_ENABLED, false);
        long activeStart = loopEnabled ? pointStart : 0L;
        long activeEnd = loopEnabled ? pointEnd : duration;
        playbackRangeStartMicros = activeStart;
        playbackRangeEndMicros = activeEnd;
        if (playbackPositionMicros < activeStart || playbackPositionMicros > activeEnd) {
            playbackPositionMicros = activeStart;
            playbackBaseMicros = activeStart;
            if (loopEnabled && playbackThread != null && playbackThread.isAlive() && playbackActive) {
                seekRequestMicros = activeStart;
                seekRequestVersion++;
                synchronized (playbackLock) { playbackLock.notifyAll(); }
            }
        }
        if (!playbackActive) playbackBaseMicros = playbackPositionMicros;
        int speed = Math.max(50, Math.min(200, prefs.getInt(MainActivity.KEY_SPEED, 100)));
        noteRollView.setAbLoopEnabled(loopEnabled);
        noteRollView.setData(currentSong,
                prefs.getString(MainActivity.KEY_SONG_NAME, currentSong.name),
                MainActivity.songTranspose(prefs, prefs.getString(MainActivity.KEY_SONG_PATH, "")), playbackPositionMicros,
                duration, pointStart, pointEnd, speed, playbackActive && !paused);
    }

    private void seekPlaybackTo(long requestedPositionMicros) {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            mainHandler.post(() -> seekPlaybackTo(requestedPositionMicros));
            return;
        }
        if (currentSong == null) currentSong = readCurrentSong();
        if (currentSong == null) return;
        long duration = currentSong.durationMicros;
        long start = playbackRangeEndMicros > playbackRangeStartMicros
                ? playbackRangeStartMicros : Math.max(0L, prefs.getLong(KEY_RANGE_START_MS, 0L)) * 1000L;
        long end = playbackRangeEndMicros > playbackRangeStartMicros
                ? playbackRangeEndMicros : duration;
        end = Math.min(duration, end);
        long target = Math.max(start, Math.min(Math.max(start, end - 1L), requestedPositionMicros));
        playbackUiGeneration++;
        playbackPositionMicros = target;
        playbackBaseMicros = target;
        if (playbackThread != null && playbackThread.isAlive() && playbackActive) {
            seekRequestMicros = target;
            seekRequestVersion++;
            synchronized (playbackLock) { playbackLock.notifyAll(); }
        }
        if (noteRollView != null) noteRollView.setCursor(target, playbackActive && !paused);
    }

    private static final class ImportedSong {
        final File file;
        final String name;
        ImportedSong(File file, String name) { this.file = file; this.name = name; }
    }

    private List<ImportedSong> listImportedSongs() {
        Map<String, ImportedSong> unique = new LinkedHashMap<>();
        File dir = new File(getFilesDir(), "imported_songs");
        File[] files = dir.listFiles();
        if (files != null) {
            for (File file : files) {
                if (!file.isFile()) continue;
                String lower = file.getName().toLowerCase(java.util.Locale.ROOT);
                if (!lower.endsWith(".mid") && !lower.endsWith(".midi")) continue;
                String label = prefs.getString("song_label_" + file.getName(), null);
                if (label == null || label.trim().isEmpty()) {
                    String n = file.getName();
                    int underscore = n.indexOf('_');
                    if (underscore > 0 && n.substring(0, underscore).matches("[0-9]+")) n = n.substring(underscore + 1);
                    label = n;
                }
                unique.put(file.getAbsolutePath(), new ImportedSong(file, label));
            }
        }
        File legacy = new File(getFilesDir(), "current_song.mid");
        if (legacy.isFile()) unique.put(legacy.getAbsolutePath(), new ImportedSong(legacy,
                prefs.getString(MainActivity.KEY_SONG_NAME, "旧曲目")));
        List<ImportedSong> result = new ArrayList<>(unique.values());
        java.util.Collections.sort(result, (a, b) -> Long.compare(b.file.lastModified(), a.file.lastModified()));
        return result;
    }

    private void showSongPickerDialog() { // SONG_PICKER_LIVE_SEARCH_V1
        if (Looper.myLooper() != Looper.getMainLooper()) {
            mainHandler.post(this::showSongPickerDialog);
            return;
        }
        if (windowManager == null) return;
        dismissSegmentDialog();
        List<ImportedSong> songs = listImportedSongs();
        if (songs.isEmpty()) {
            toast("还没有已导入曲目，请先回主界面导入 MIDI。");
            return;
        }
        String currentPath = prefs.getString(MainActivity.KEY_SONG_PATH, "");
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(0x55060b12);
        root.setClickable(true);
        root.setOnClickListener(v -> dismissSegmentDialog());
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(12), dp(12), dp(12), dp(12));
        card.setBackground(rounded(0xf4f5f9fc, dp(15)));
        card.setClickable(true);
        card.setOnClickListener(v -> { });
        TextView title = new TextView(this);
        title.setText("已导入曲目");
        title.setTextColor(0xff192a35);
        title.setTextSize(17);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        title.setPadding(dp(4), dp(3), dp(4), dp(8));
        card.addView(title);
        TextView hint = new TextView(this);
        hint.setText("点曲名切换歌曲；下方滑杆单独移调，音域检查会同步更新。");
        hint.setTextColor(0xff617583);
        hint.setTextSize(11);
        hint.setPadding(dp(4), 0, dp(4), dp(8));
        card.addView(hint);

        EditText searchField = new EditText(this);
        searchField.setSingleLine(true);
        searchField.setTextSize(13);
        searchField.setTextColor(0xff192a35);
        searchField.setHintTextColor(0xff82919a);
        searchField.setHint("搜索已导入的歌曲名");
        searchField.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_AUTO_CORRECT);
        searchField.setFocusable(true);
        searchField.setFocusableInTouchMode(true);
        searchField.setPadding(dp(11), 0, dp(11), 0);
        searchField.setBackground(rounded(0xffe7edf3, dp(10)));
        LinearLayout.LayoutParams searchParams = new LinearLayout.LayoutParams(-1, dp(42));
        searchParams.setMargins(0, 0, 0, dp(8));
        card.addView(searchField, searchParams);

        ScrollView scroll = new ScrollView(this);
        LinearLayout rows = new LinearLayout(this);
        rows.setOrientation(LinearLayout.VERTICAL);
        for (ImportedSong imported : songs) {
            final String songPath = imported.file.getAbsolutePath();
            boolean selected = songPath.equals(currentPath);
            int shift = MainActivity.songTranspose(prefs, songPath);
            LinearLayout songCard = new LinearLayout(this);
            songCard.setOrientation(LinearLayout.VERTICAL);
            songCard.setPadding(dp(8), dp(6), dp(8), dp(4));
            songCard.setBackground(rounded(selected ? 0xffd9f0e6 : 0xffe7edf3, dp(10)));

            LinearLayout titleRow = new LinearLayout(this);
            titleRow.setOrientation(LinearLayout.HORIZONTAL);
            titleRow.setGravity(Gravity.CENTER_VERTICAL);
            TextView item = new TextView(this);
            item.setText((selected ? "✓  " : "♪  ") + imported.name);
            item.setTextColor(selected ? 0xff125744 : 0xff253441);
            item.setTextSize(13);
            item.setMaxLines(2);
            item.setPadding(dp(3), dp(3), dp(3), dp(2));
            titleRow.addView(item, new LinearLayout.LayoutParams(0, -2, 1f));
            Button removeSongButton = dialogButton("移除", 0xffa94f50);
            LinearLayout.LayoutParams removeSongParams = new LinearLayout.LayoutParams(dp(48), dp(29));
            removeSongParams.setMargins(dp(5), dp(1), 0, dp(1));
            titleRow.addView(removeSongButton, removeSongParams);
            songCard.addView(titleRow, new LinearLayout.LayoutParams(-1, -2));
            removeSongButton.setOnClickListener(v -> confirmRemoveImportedSong(imported));

            TextView rangeInfo = new TextView(this);
            rangeInfo.setText(describeSongRange(imported.file, shift));
            rangeInfo.setTextColor(0xff617583);
            rangeInfo.setTextSize(10);
            rangeInfo.setPadding(dp(3), 0, dp(3), 0);
            songCard.addView(rangeInfo, new LinearLayout.LayoutParams(-1, -2));

            SeekBar shiftBar = new SeekBar(this);
            shiftBar.setMax(24);
            shiftBar.setProgress(Math.max(0, Math.min(24, shift + 12)));
            songCard.addView(shiftBar, new LinearLayout.LayoutParams(-1, dp(34)));
            LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(-1, -2);
            ip.setMargins(0, 0, 0, dp(6));
            songCard.setTag(imported.name);
            rows.addView(songCard, ip);
            item.setOnClickListener(v -> selectImportedSong(songPath, imported.name));
            shiftBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                    if (!fromUser) return;
                    int nextShift = progress - 12;
                    boolean selectedSong = songPath.equals(prefs.getString(MainActivity.KEY_SONG_PATH, ""));
                    if (selectedSong && playbackThread != null && playbackThread.isAlive()
                            && playbackActive && !stopRequested) stopPlayback();
                    SharedPreferences.Editor editor = prefs.edit()
                            .putInt(MainActivity.songTransposePreferenceKey(songPath), nextShift);
                    if (selectedSong) editor.putInt(MainActivity.KEY_TRANSPOSE, nextShift);
                    editor.apply();
                    rangeInfo.setText(describeSongRange(imported.file, nextShift));
                    if (selectedSong && noteRollView != null) refreshNoteRollData();
                }
                @Override public void onStartTrackingTouch(SeekBar bar) { }
                @Override public void onStopTrackingTouch(SeekBar bar) { }
            });
        }
        TextView noResults = new TextView(this);
        noResults.setText("没有找到匹配的曲目");
        noResults.setTextColor(0xff71808a);
        noResults.setTextSize(12);
        noResults.setGravity(Gravity.CENTER);
        noResults.setPadding(dp(8), dp(14), dp(8), dp(14));
        noResults.setVisibility(View.GONE);
        rows.addView(noResults, new LinearLayout.LayoutParams(-1, -2));

        searchField.addTextChangedListener(new android.text.TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                String query = s == null ? "" : s.toString().trim().toLowerCase(java.util.Locale.ROOT);
                int matches = 0;
                for (int i = 0; i < rows.getChildCount(); i++) {
                    View child = rows.getChildAt(i);
                    if (child == noResults) continue;
                    Object tag = child.getTag();
                    if (!(tag instanceof String)) continue;
                    boolean visible = query.isEmpty()
                            || ((String) tag).toLowerCase(java.util.Locale.ROOT).contains(query);
                    child.setVisibility(visible ? View.VISIBLE : View.GONE);
                    if (visible) matches++;
                }
                noResults.setVisibility(matches == 0 ? View.VISIBLE : View.GONE);
            }
            @Override public void afterTextChanged(android.text.Editable s) { }
        });

        scroll.addView(rows);
        card.addView(scroll, new LinearLayout.LayoutParams(-1, Math.min(dp(330), Math.max(dp(100), getResources().getDisplayMetrics().heightPixels * 2 / 5))));
        Button close = dialogButton("关闭", 0xff526777);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, dp(38));
        cp.setMargins(0, dp(8), 0, 0);
        card.addView(close, cp);
        close.setOnClickListener(v -> dismissSegmentDialog());
        int screenWidth = getResources().getDisplayMetrics().widthPixels;
        FrameLayout.LayoutParams cardParams = new FrameLayout.LayoutParams(Math.min(screenWidth - dp(32), dp(390)), -2, Gravity.CENTER);
        root.addView(card, cardParams);
        WindowManager.LayoutParams overlayParams = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
                PixelFormat.TRANSLUCENT);
        overlayParams.gravity = Gravity.TOP | Gravity.LEFT;
        overlayParams.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
                | WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN;
        segmentOverlay = root;
        try { windowManager.addView(root, overlayParams); }
        catch (Exception e) { segmentOverlay = null; toast("曲目列表无法显示。"); }
    }

    private void confirmRemoveImportedSong(ImportedSong imported) {
        if (imported == null || imported.file == null) return;
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("移除曲目")
                .setMessage("确定从本应用曲目列表移除“" + imported.name
                        + "”吗？只删除应用内导入副本，不会删除下载目录中的原始文件。")
                .setNegativeButton("取消", (d, which) -> d.dismiss())
                .setPositiveButton("移除", (d, which) -> removeImportedSongNow(imported))
                .create();
        try {
            if (dialog.getWindow() != null) {
                dialog.getWindow().setType(WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY);
            }
            dialog.show();
        } catch (Exception ex) {
            toast("无法显示移除确认窗口，请稍后重试。");
        }
    }

    private void removeImportedSongNow(ImportedSong imported) {
        if (imported == null || imported.file == null) return;
        String path = imported.file.getAbsolutePath();
        String selectedPath = prefs.getString(MainActivity.KEY_SONG_PATH, "");
        boolean selected = path.equals(selectedPath);

        if (selected && playbackThread != null && playbackThread.isAlive()) {
            if (!stopRequested) stopPlayback();
            mainHandler.postDelayed(() -> removeImportedSongNow(imported), 100L);
            return;
        }

        if (imported.file.exists() && !imported.file.delete()) {
            toast("移除失败：文件暂时无法删除。");
            return;
        }

        SharedPreferences.Editor editor = prefs.edit()
                .remove("song_label_" + imported.file.getName())
                .remove(MainActivity.songTransposePreferenceKey(path));
        if (selected) {
            editor.remove(MainActivity.KEY_SONG_PATH)
                    .remove(MainActivity.KEY_SONG_NAME)
                    .putInt(MainActivity.KEY_TRANSPOSE, 0)
                    .remove(KEY_RANGE_START_MS)
                    .remove(KEY_RANGE_END_MS)
                    .putBoolean("note_roll_enabled", false);
            playbackPositionMicros = 0L;
            playbackBaseMicros = 0L;
            seekRequestMicros = 0L;
            currentSong = null;
            if (noteRollView != null) {
                removeOverlay(noteRollView);
                noteRollView = null;
            }
        }
        editor.apply();
        if (selected) updateControlPanelPlaybackButtons();
        toast("已移除曲目：" + imported.name);
        dismissSegmentDialog();
        showSongPickerDialog();
    }

    private String describeSongRange(File file, int transpose) {
        String shift = (transpose > 0 ? "+" : "") + transpose;
        try {
            MidiParser.MidiSong song = MidiParser.parse(file);
            List<String> missing = InstrumentLayout.missingNotes(song, transpose, prefs);
            if (missing.isEmpty()) return "移调 " + shift + " 半音 · 音域检查通过";
            StringBuilder text = new StringBuilder("移调 ").append(shift).append(" 半音 · 超出音域 ")
                    .append(missing.size()).append(" 种：");
            for (int i = 0; i < Math.min(4, missing.size()); i++) {
                if (i > 0) text.append("、");
                text.append(missing.get(i));
            }
            if (missing.size() > 4) text.append("…");
            return text.toString();
        } catch (Exception ex) {
            return "移调 " + shift + " 半音 · 曲谱读取失败";
        }
    }

    private void selectImportedSong(String path, String displayName) {
        if (playbackThread != null && playbackThread.isAlive()) {
            if (!stopRequested) stopPlayback();
            mainHandler.postDelayed(() -> selectImportedSong(path, displayName), 80L);
            return;
        }
        File file = new File(path);
        if (!file.isFile()) { toast("曲目文件已不存在，请重新导入。"); dismissSegmentDialog(); return; }
        final MidiParser.MidiSong selected;
        try { selected = MidiParser.parse(file); }
        catch (Exception ex) { toast("曲目读取失败：" + ex.getMessage()); dismissSegmentDialog(); return; }
        String previousPath = prefs.getString(MainActivity.KEY_SONG_PATH, "");
        String transposeKey = MainActivity.songTransposePreferenceKey(file.getAbsolutePath());
        int selectedTranspose = prefs.contains(transposeKey) ? prefs.getInt(transposeKey, 0)
                : (file.getAbsolutePath().equals(previousPath) ? prefs.getInt(MainActivity.KEY_TRANSPOSE, 0) : 0);
        prefs.edit().putString(MainActivity.KEY_SONG_PATH, file.getAbsolutePath())
                .putString(MainActivity.KEY_SONG_NAME, displayName)
                .putInt(transposeKey, selectedTranspose).putInt(MainActivity.KEY_TRANSPOSE, selectedTranspose)
                .putLong(KEY_RANGE_START_MS, 0L).putLong(KEY_RANGE_END_MS, -1L).apply();
        currentSong = selected;
        playbackPositionMicros = 0L;
        playbackBaseMicros = 0L;
        playbackRangeStartMicros = 0L;
        playbackRangeEndMicros = selected.durationMicros;
        seekRequestMicros = 0L;
        seekRequestVersion++;
        dismissSegmentDialog();
        if (noteRollView != null) refreshNoteRollData();
        else if (prefs.getBoolean("note_roll_enabled", true)) showNoteRoll();
        refreshMiniPlaybackButton();
        toast("已切换曲目：" + displayName);
    }

    private Button dialogButton(String label, int color) {
        Button button = smallButton(label);
        button.setTextSize(12);
        button.setBackground(rounded(color, dp(8)));
        return button;
    }

    private void changePlaybackSpeedFromNoteRoll(int requestedSpeed) {
        int nextSpeed = Math.max(50, Math.min(200, Math.round(requestedSpeed / 5f) * 5));
        int previousSpeed = activeSpeedPercent;
        boolean running = playbackThread != null && playbackThread.isAlive()
                && playbackActive && !stopRequested;
        if (running) {
            synchronized (playbackLock) {
                long now = SystemClock.elapsedRealtime();
                long cursor = playbackPositionMicros;
                if (!paused) {
                    long elapsed = Math.max(0L, now - playbackStartMs - pausedDurationMs);
                    cursor = playbackBaseMicros + elapsed * Math.max(50, Math.min(200, previousSpeed)) * 10L;
                }
                long start = playbackRangeStartMicros;
                long end = Math.max(start + 1L, playbackRangeEndMicros);
                cursor = Math.max(start, Math.min(end - 1L, cursor));
                playbackPositionMicros = cursor;
                playbackBaseMicros = cursor;
                seekRequestMicros = cursor;
                seekRequestVersion++;
                playbackUiGeneration++;
                activeSpeedPercent = nextSpeed;
                prefs.edit().putInt(MainActivity.KEY_SPEED, nextSpeed).apply();
                playbackLock.notifyAll();
            }
        } else {
            activeSpeedPercent = nextSpeed;
            prefs.edit().putInt(MainActivity.KEY_SPEED, nextSpeed).apply();
        }
        if (noteRollView != null) noteRollView.setCursor(playbackPositionMicros, playbackActive && !paused);
        toast("演奏速度：" + nextSpeed + "%");
    }

    private void savePracticeRange(long startMs, long endMs, int speed) {
        prefs.edit().putLong(KEY_RANGE_START_MS, Math.max(0L, startMs))
                .putLong(KEY_RANGE_END_MS, Math.max(startMs + 1L, endMs))
                .putInt(MainActivity.KEY_SPEED, Math.max(50, Math.min(200, speed))).apply();
        if (noteRollView != null) refreshNoteRollData();
    }

    private void dismissSegmentDialog() {
        removeOverlay(segmentOverlay);
        segmentOverlay = null;
        segmentOverlayParams = null;
    }

    private void beginCalibration() {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            mainHandler.post(this::beginCalibration);
            return;
        }
        if (playbackThread != null && playbackThread.isAlive()) {
            toast("请先停止自动演奏，再校准音符位置。");
            return;
        }
        calibrationStep = 0;
        calibrating = true;
        removeControlPanel();
        FrameLayout capture = new FrameLayout(this);
        capture.setBackgroundColor(Color.TRANSPARENT);
        capture.setClickable(true);

        TextView prompt = new TextView(this);
        prompt.setText(calibrationPrompt());
        prompt.setTextColor(Color.WHITE);
        prompt.setTextSize(14);
        prompt.setGravity(Gravity.CENTER);
        prompt.setPadding(dp(14), dp(10), dp(14), dp(10));
        prompt.setBackground(rounded(0xe8262f3a, dp(12)));
        // Consume taps on the instruction itself so they are never mistaken for key calibration.
        prompt.setOnClickListener(v -> { });
        FrameLayout.LayoutParams promptParams = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        promptParams.topMargin = dp(4);
        capture.addView(prompt, promptParams);

        TextView cancel = new TextView(this);
        cancel.setText("取消");
        cancel.setTextColor(Color.WHITE);
        cancel.setTextSize(13);
        cancel.setGravity(Gravity.CENTER);
        cancel.setPadding(dp(10), dp(10), dp(10), dp(10));
        cancel.setBackground(rounded(0xff805047, dp(10)));
        FrameLayout.LayoutParams cancelParams = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.RIGHT);
        cancelParams.topMargin = dp(4);
        cancelParams.rightMargin = dp(4);
        capture.addView(cancel, cancelParams);
        cancel.setOnClickListener(v -> cancelCalibration());

        capture.setOnTouchListener((v, event) -> {
            if (event.getActionMasked() != MotionEvent.ACTION_UP) return true;
            float rawX = event.getRawX();
            float rawY = event.getRawY();
            saveCalibrationTap(Math.round(rawX), Math.round(rawY), prompt);
            return true;
        });

        WindowManager.LayoutParams p = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        p.gravity = Gravity.TOP | Gravity.LEFT;
        calibrationOverlay = capture;
        try {
            windowManager.addView(calibrationOverlay, p);
            prompt.bringToFront();
            cancel.bringToFront();
            toast("校准开始：按顶部提示逐个点击，点击位置不会触发游戏音符。");
        } catch (Exception e) {
            calibrating = false;
            calibrationOverlay = null;
            showControlPanel();
            toast("无法打开校准层，请重启无障碍服务后重试。");
        }
    }

    private String calibrationPrompt() {
        if (InstrumentLayout.MODE_PIANO88.equals(InstrumentLayout.selectedMode(prefs))) {
            return InstrumentLayout.pianoCalibrationPrompt(calibrationStep) + "；点键位，不要点此提示";
        }
        return "九键 " + (calibrationStep + 1) + "/9：点 " + InstrumentLayout.displayLabel(calibrationStep) + " 对应音符";
    }

    private void saveCalibrationTap(int x, int y, TextView prompt) {
        if (InstrumentLayout.MODE_PIANO88.equals(InstrumentLayout.selectedMode(prefs))) {
            InstrumentLayout.savePianoAnchor(prefs, calibrationStep, x, y);
        } else {
            InstrumentLayout.savePoint(prefs, calibrationStep, x, y);
        }
        calibrationStep++;
        int total = InstrumentLayout.calibrationSteps(prefs);
        if (calibrationStep >= total) {
            calibrating = false;
            removeOverlay(calibrationOverlay);
            calibrationOverlay = null;
            showControlPanel();
            toast(InstrumentLayout.MODE_PIANO88.equals(InstrumentLayout.selectedMode(prefs))
                    ? (InstrumentLayout.isPiano88Calibrated(prefs) ? "88 键校准完成。" : "88 键校准失败：请确认白键端点顺序。")
                    : "九键校准完成。现在可以开始演奏。");
            return;
        }
        prompt.setText(calibrationPrompt());
    }

    private void cancelCalibration() {
        calibrating = false;
        removeOverlay(calibrationOverlay);
        calibrationOverlay = null;
        showControlPanel();
        toast("已取消校准，已保存的旧坐标不受影响。");
    }

    private void startPlayback() {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            mainHandler.post(this::startPlayback);
            return;
        }
        if (playbackThread != null && playbackThread.isAlive()) {
            toast("自动演奏正在运行；可暂停或停止。");
            return;
        }
        String path = prefs.getString(MainActivity.KEY_SONG_PATH, "");
        if (path == null || path.isEmpty() || !new File(path).isFile()) {
            toast("请先在洛克乐器演奏主界面导入 MIDI 曲谱。");
            return;
        }
        final MidiParser.MidiSong song;
        try { song = MidiParser.parse(new File(path)); }
        catch (Exception e) { toast("MIDI 读取失败：" + e.getMessage()); return; }

        currentSong = song;
        long durationMs = Math.max(1L, (song.durationMicros + 999L) / 1000L);
        boolean abLoopEnabled = prefs.getBoolean(KEY_AB_LOOP_ENABLED, false);
        long rangeStartMs = abLoopEnabled
                ? Math.max(0L, Math.min(durationMs, prefs.getLong(KEY_RANGE_START_MS, 0L))) : 0L;
        long storedEndMs = prefs.getLong(KEY_RANGE_END_MS, -1L);
        long rangeEndMs = !abLoopEnabled ? durationMs
                : ((storedEndMs <= 0L || storedEndMs > durationMs) ? durationMs : storedEndMs);
        if (rangeEndMs <= rangeStartMs) { rangeStartMs = 0L; rangeEndMs = durationMs; }
        final long selectedRangeStartMicros = rangeStartMs * 1000L;
        final long chosenEndMicros = Math.max(selectedRangeStartMicros + 1L, rangeEndMs * 1000L);
        long cursor = playbackPositionMicros;
        final long chosenStartMicros = cursor > selectedRangeStartMicros && cursor < chosenEndMicros
                ? cursor : selectedRangeStartMicros;
        int transpose = MainActivity.songTranspose(prefs, prefs.getString(MainActivity.KEY_SONG_PATH, ""));
        java.util.Set<Integer> missingSet = new java.util.TreeSet<>();
        for (MidiParser.NoteEvent note : song.notes) {
            if (note.startMicros >= chosenStartMicros && note.startMicros < chosenEndMicros
                    && !InstrumentLayout.supportsPitch(prefs, note.pitch + transpose)) {
                missingSet.add(note.pitch + transpose);
            }
        }
        List<String> missing = new ArrayList<>();
        for (Integer pitch : missingSet) missing.add(MidiParser.noteName(pitch));
        if (!missing.isEmpty()) {
            StringBuilder msg = new StringBuilder("有 ").append(missing.size()).append(" 种音高超出当前乐器音域：");
            for (int i = 0; i < Math.min(8, missing.size()); i++) {
                if (i > 0) msg.append("、");
                msg.append(missing.get(i));
            }
            if (missing.size() > 8) msg.append("…");
            msg.append("。请在主界面尝试移调。");
            toast(msg.toString());
            return;
        }
        if (InstrumentLayout.MODE_PIANO88.equals(InstrumentLayout.selectedMode(prefs))) {
            if (!InstrumentLayout.isPiano88Calibrated(prefs)) { toast("请先校准 88 键钢琴位置。"); return; }
        } else if (InstrumentLayout.calibratedCount(prefs) != InstrumentLayout.PITCHES.length) {
            toast("请先校准完整的九个音符位置。");
            return;
        }
        for (MidiParser.NoteEvent note : song.notes) {
            if (note.startMicros >= chosenStartMicros && note.startMicros < chosenEndMicros
                    && InstrumentLayout.pointForPitch(prefs, note.pitch + transpose) == null) {
                toast("所选片段中有音符尚未映射到触控位置，已阻止演奏。");
                return;
            }
        }
        stopRequested = false;
        paused = false;
        pausedDurationMs = 0;
        pauseStartedMs = 0;
        playbackRangeStartMicros = selectedRangeStartMicros;
        playbackRangeEndMicros = Math.min(song.durationMicros, chosenEndMicros);
        if (playbackRangeEndMicros <= playbackRangeStartMicros) playbackRangeEndMicros = song.durationMicros;
        playbackBaseMicros = chosenStartMicros;
        seekRequestMicros = chosenStartMicros;
        seekRequestVersion++;
        playbackPositionMicros = chosenStartMicros;
        final int chosenTranspose = transpose;
        final int speedPercent = Math.max(50, Math.min(200, prefs.getInt(MainActivity.KEY_SPEED, 100)));
        activeSpeedPercent = speedPercent;
        playbackEverStarted = true;
        statusBubbleDismissed = false;
        playbackActive = true;
        if (pauseButton != null) pauseButton.setText("暂停");
        refreshMiniPlaybackButton();
        if (prefs.getBoolean("note_roll_enabled", true)) showNoteRoll();
        else if (noteRollView != null) refreshNoteRollData();
        playbackThread = new Thread(() -> playSong(song, chosenTranspose, speedPercent,
                playbackRangeStartMicros, playbackRangeEndMicros), "Luoke-MIDI-Playback");
        playbackThread.start();
        refreshMiniPlaybackButton();
        toast("开始演奏：" + song.name + "（" + NoteRollView.formatTime(playbackRangeStartMicros)
                + "－" + NoteRollView.formatTime(playbackRangeEndMicros) + "）");
    }

    private int firstNoteAtOrAfter(MidiParser.MidiSong song, long timeMicros) {
        int low = 0, high = song.notes.size();
        while (low < high) {
            int mid = (low + high) >>> 1;
            if (song.notes.get(mid).startMicros < timeMicros) low = mid + 1;
            else high = mid;
        }
        return low;
    }

    private void playSong(MidiParser.MidiSong song, int transpose, int speedPercent,
                          long rangeStartMicros, long rangeEndMicros) {
        final Thread playbackWorker = Thread.currentThread();
        playbackStartMs = SystemClock.elapsedRealtime();
        long baseMicros = playbackBaseMicros;
        int observedSeekVersion = seekRequestVersion;
        int index = firstNoteAtOrAfter(song, baseMicros);
        int sentBatches = 0;
        try {
            while (!stopRequested) {
                if (seekRequestVersion != observedSeekVersion) {
                    observedSeekVersion = seekRequestVersion;
                    baseMicros = Math.max(rangeStartMicros, Math.min(rangeEndMicros, seekRequestMicros));
                    playbackBaseMicros = baseMicros;
                    playbackPositionMicros = baseMicros;
                    playbackStartMs = SystemClock.elapsedRealtime();
                    pausedDurationMs = 0L;
                    if (paused) pauseStartedMs = playbackStartMs;
                    index = firstNoteAtOrAfter(song, baseMicros);
                    speedPercent = Math.max(50, Math.min(200, activeSpeedPercent));
                    mainHandler.post(() -> {
                        if (noteRollView != null) noteRollView.setCursor(playbackPositionMicros, playbackActive && !paused);
                        refreshMiniPlaybackButton();
                    });
                    if (baseMicros >= rangeEndMicros) break;
                }
                if (index >= song.notes.size() || song.notes.get(index).startMicros >= rangeEndMicros) {
                    if (!stopRequested && prefs.getBoolean(KEY_AB_LOOP_ENABLED, false)) {
                        int loopStartIndex = firstNoteAtOrAfter(song, rangeStartMicros);
                        if (loopStartIndex >= song.notes.size()
                                || song.notes.get(loopStartIndex).startMicros >= rangeEndMicros) break;
                        baseMicros = rangeStartMicros;
                        playbackBaseMicros = baseMicros;
                        playbackPositionMicros = baseMicros;
                        playbackStartMs = SystemClock.elapsedRealtime();
                        pausedDurationMs = 0L;
                        index = loopStartIndex;
                        final long loopRestart = baseMicros;
                        mainHandler.post(() -> {
                            if (noteRollView != null) noteRollView.setCursor(loopRestart, playbackActive && !paused);
                            refreshMiniPlaybackButton();
                        });
                        continue;
                    }
                    break;
                }
                long at = song.notes.get(index).startMicros;
                List<MidiParser.NoteEvent> batch = new ArrayList<>();
                while (index < song.notes.size() && song.notes.get(index).startMicros < rangeEndMicros
                        && song.notes.get(index).startMicros - at <= CHORD_WINDOW_MICROS) {
                    batch.add(song.notes.get(index++));
                }
                long targetMs = Math.round(Math.max(0L, at - baseMicros) / 1000.0 * (100.0 / speedPercent));
                if (!awaitTarget(targetMs, observedSeekVersion)) {
                    if (stopRequested) break;
                    continue;
                }
                // A scrub that lands while a chord is waiting must reposition before sending it.
                if (seekRequestVersion != observedSeekVersion) continue;
                List<Point> points = new ArrayList<>();
                Map<String, Point> unique = new LinkedHashMap<>();
                for (MidiParser.NoteEvent note : batch) {
                    Point p = InstrumentLayout.pointForPitch(prefs, note.pitch + transpose);
                    if (p != null) unique.put(p.x + ":" + p.y, p);
                }
                points.addAll(unique.values());
                boolean dispatchOk = true;
                for (int pointStart = 0; pointStart < points.size(); pointStart += 10) {
                    if (seekRequestVersion != observedSeekVersion) { dispatchOk = false; break; }
                    int pointEnd = Math.min(points.size(), pointStart + 10);
                    if (!sendTapBatch(points.subList(pointStart, pointEnd)) ) {
                        dispatchOk = false;
                        break;
                    }
                }
                if (!dispatchOk) {
                    if (stopRequested) break;
                    if (seekRequestVersion != observedSeekVersion) continue;
                    if (!stopRequested) toast("触控分发失败，演奏已停止。");
                    break;
                }
                sentBatches++;
            }
        } catch (Throwable e) {
            if (!stopRequested) toast("演奏异常：" + e.getMessage());
        } finally {
            final int finalSentBatches = sentBatches;
            final boolean stoppedByUser = stopRequested;
            playbackActive = false;
            synchronized (playbackLock) {
                paused = false;
                stopRequested = false;
                playbackLock.notifyAll();
            }
            mainHandler.post(() -> {
                if (pauseButton != null) pauseButton.setText("暂停");
                // Keep the last rendered cursor rather than snapping the note window to the
                // A/B end on natural completion; this prevents the visible notes changing abruptly.
                if (playbackThread == playbackWorker) {
                    if (noteRollView != null) noteRollView.setCursor(playbackPositionMicros, false);
                    playbackThread = null;
                }
                refreshMiniPlaybackButton();
                toast((stoppedByUser ? "演奏已停止。" : "演奏结束。") + "已触发 " + finalSentBatches + " 组音符。");
            });
        }
    }

    private boolean awaitTarget(long targetActiveMs, int expectedSeekVersion) {
        synchronized (playbackLock) {
            while (!stopRequested) {
                if (seekRequestVersion != expectedSeekVersion) return false;
                while (paused && !stopRequested && seekRequestVersion == expectedSeekVersion) {
                    try { playbackLock.wait(); }
                    catch (InterruptedException e) { Thread.currentThread().interrupt(); return false; }
                }
                if (stopRequested || seekRequestVersion != expectedSeekVersion) return false;
                long now = SystemClock.elapsedRealtime();
                long activeElapsed = Math.max(0L, now - playbackStartMs - pausedDurationMs);
                playbackPositionMicros = playbackBaseMicros
                        + Math.min(Math.max(0L, playbackRangeEndMicros - playbackBaseMicros), activeElapsed * activeSpeedPercent * 10L);
                if (noteRollView != null) {
                    final long cursor = playbackPositionMicros;
                    final boolean isRunning = playbackActive && !paused && !stopRequested;
                    final long cursorGeneration = playbackUiGeneration;
                    mainHandler.post(() -> {
                        // A generation check discards frames posted before a seek or while a finger
                        // is dragging. This remains safe even if the UI queue drains after resume.
                        if (cursorGeneration == playbackUiGeneration
                                && playbackActive && !stopRequested && !paused && noteRollView != null) {
                            noteRollView.setCursor(cursor, isRunning);
                        }
                        refreshMiniPlaybackButton();
                    });
                }
                long remaining = targetActiveMs - activeElapsed;
                if (remaining <= 0) return true;
                try { playbackLock.wait(Math.min(remaining, 35L)); }
                catch (InterruptedException e) { Thread.currentThread().interrupt(); return false; }
            }
            return false;
        }
    }

    private boolean sendTapBatch(List<Point> points) throws InterruptedException {
        CountDownLatch latch = new CountDownLatch(1);
        boolean[] accepted = new boolean[1];
        boolean[] completed = new boolean[1];
        mainHandler.post(() -> {
            if (stopRequested) {
                latch.countDown();
                return;
            }
            try {
                GestureDescription.Builder builder = new GestureDescription.Builder();
                for (Point point : points) {
                    Path path = new Path();
                    path.moveTo(point.x, point.y);
                    path.lineTo(point.x + 1f, point.y + 1f);
                    builder.addStroke(new GestureDescription.StrokeDescription(path, 0, TAP_DURATION_MS));
                }
                accepted[0] = dispatchGesture(builder.build(), new GestureResultCallback() {
                    @Override public void onCompleted(GestureDescription gestureDescription) { completed[0] = true; latch.countDown(); }
                    @Override public void onCancelled(GestureDescription gestureDescription) { latch.countDown(); }
                }, mainHandler);
                if (!accepted[0]) latch.countDown();
            } catch (Exception e) {
                latch.countDown();
            }
        });
        boolean callback = latch.await(700, TimeUnit.MILLISECONDS);
        if (!callback) {
            stopRequested = true;
            synchronized (playbackLock) { playbackLock.notifyAll(); }
            return false;
        }
        return accepted[0] && completed[0] && !stopRequested;
    }

    private void togglePause() {
        synchronized (playbackLock) {
            if (playbackThread == null || !playbackThread.isAlive()) {
                toast("当前没有正在运行的曲谱。");
                return;
            }
            long now = SystemClock.elapsedRealtime();
            if (paused) {
                pausedDurationMs += Math.max(0, now - pauseStartedMs);
                paused = false;
                if (pauseButton != null) pauseButton.setText("暂停");
                refreshMiniPlaybackButton();
                if (noteRollView != null) noteRollView.setCursor(playbackPositionMicros, true);
                toast("继续演奏。");
            } else {
                paused = true;
                pauseStartedMs = now;
                if (pauseButton != null) pauseButton.setText("继续");
                refreshMiniPlaybackButton();
                if (noteRollView != null) noteRollView.setCursor(playbackPositionMicros, false);
                toast("已暂停。");
            }
            playbackLock.notifyAll();
        }
    }

    private void rewindPlaybackToStart() {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            mainHandler.post(this::rewindPlaybackToStart);
            return;
        }
        if (currentSong == null) currentSong = readCurrentSong();
        if (currentSong == null) {
            toast("请先导入 MIDI 曲谱，再回到起始点。");
            return;
        }
        long duration = Math.max(1L, currentSong.durationMicros);
        boolean loopEnabled = prefs.getBoolean(KEY_AB_LOOP_ENABLED, false);
        long target = 0L;
        long activeEnd = duration;
        if (loopEnabled) {
            long startMs = Math.max(0L, prefs.getLong(KEY_RANGE_START_MS, 0L));
            long storedEndMs = prefs.getLong(KEY_RANGE_END_MS, -1L);
            long start = Math.min(duration, startMs * 1000L);
            long end = (storedEndMs <= 0L || storedEndMs * 1000L > duration)
                    ? duration : Math.max(0L, storedEndMs * 1000L);
            if (end <= start) {
                start = 0L;
                end = duration;
            }
            target = Math.min(start, Math.max(0L, duration - 1L));
            activeEnd = Math.max(target + 1L, Math.min(duration, end));
        }
        playbackRangeStartMicros = loopEnabled ? target : 0L;
        playbackRangeEndMicros = loopEnabled ? activeEnd : duration;
        playbackPositionMicros = target;
        playbackBaseMicros = target;
        seekRequestMicros = target;
        Thread running = playbackThread;
        if (running != null && running.isAlive() && playbackActive) {
            seekRequestVersion++;
            synchronized (playbackLock) { playbackLock.notifyAll(); }
        }
        if (noteRollView != null) {
            noteRollView.setCursor(target, playbackActive && !paused);
            refreshNoteRollData();
        }
        refreshMiniPlaybackButton();
        toast(loopEnabled ? "已回到 A 点。" : "已回到歌曲起点。");
    }

    private void stopPlayback() {
        synchronized (playbackLock) {
            stopRequested = true;
            paused = false;
            playbackLock.notifyAll();
        }
        Thread t = playbackThread;
        if (t != null) t.interrupt();
        playbackActive = false;
        if (noteRollView != null) noteRollView.setCursor(playbackPositionMicros, false);
        if (pauseButton != null) pauseButton.setText("暂停");
        refreshMiniPlaybackButton();
        toast("已请求停止演奏。");
    }

    private Button smallButton(String label) {
        Button button = new Button(this);
        button.setText(label);
        button.setAllCaps(false);
        button.setTextSize(11);
        button.setTextColor(Color.WHITE);
        button.setMinWidth(0);
        button.setMinimumWidth(0);
        button.setMinHeight(0);
        button.setMinimumHeight(dp(30));
        button.setPadding(dp(8), dp(1), dp(8), dp(1));
        button.setBackground(rounded(0xff455667, dp(8)));
        return button;
    }

    private AdaptiveFlowLayout.LayoutParams flowButtonParams() {
        AdaptiveFlowLayout.LayoutParams p = new AdaptiveFlowLayout.LayoutParams(-2, dp(34));
        p.setMargins(dp(1), dp(1), dp(1), dp(1));
        return p;
    }

    private GradientDrawable rounded(int color, int radius) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(radius);
        drawable.setStroke(dp(1), 0x55ffffff);
        return drawable;
    }

    private GradientDrawable roundedBorder(int color, int strokeColor, int radius) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(radius);
        drawable.setStroke(dp(1), strokeColor);
        return drawable;
    }

    private GradientDrawable roundedNoStroke(int color, int radius) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(radius);
        return drawable;
    }

    private void removeOverlay(View view) {
        if (view == null || windowManager == null) return;
        try { windowManager.removeView(view); } catch (Exception ignored) { }
    }

    private void toast(String message) {
        mainHandler.post(() -> Toast.makeText(this, message, Toast.LENGTH_LONG).show());
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
