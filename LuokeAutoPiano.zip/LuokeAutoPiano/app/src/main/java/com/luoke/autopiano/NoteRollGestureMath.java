package com.luoke.autopiano;

/** Pure gesture math shared by NoteRollView and JVM regression tests. NOTE_ROLL_PLAY_REWIND_SEEK_GUARD_V1 */
final class NoteRollGestureMath {
    private NoteRollGestureMath() { }

    static long gentlePanDelta(float dx, float width, long visibleWindowMicros) {
        float safeWidth = Math.max(1f, width);
        long maximum = Math.min(500_000L, Math.max(0L, Math.round(visibleWindowMicros * 0.06f)));
        return Math.round((-dx / safeWidth) * maximum);
    }

    static boolean shouldUpdateAbsoluteSeek(float dx, float dy, int touchSlop) {
        return Math.abs(dx) > touchSlop && Math.abs(dx) > Math.abs(dy) * 0.85f;
    }
}
