package com.luoke.autopiano;

/** Pure gesture math shared by NoteRollView and JVM regression tests. NOTE_ROLL_PLAY_REWIND_SEEK_GUARD_V1 */
final class NoteRollGestureMath {
    private NoteRollGestureMath() { }

    static long gentlePanDelta(float dx, float width, long visibleWindowMicros) {
        float safeWidth = Math.max(1f, width);
        long maximum = Math.min(500_000L, Math.max(0L, Math.round(visibleWindowMicros * 0.06f)));
        return Math.round((-dx / safeWidth) * maximum);
    }

    static boolean shouldUpdateAbsoluteSeek(float dx, float dy, int touchSlop) {
        return Math.abs(dx) > touchSlop && Math.abs(dx) > Math.abs(dy) * 0.85f;
    }

    static boolean pastEntranceBuffer(float noteStartX, float rightEdge, float density) {
        float reserve = 24f * Math.max(0f, density);
        return noteStartX <= rightEdge - reserve;
    }

    static float enteringNoteFadeIn(float noteStartX, float rightEdge, float density) {
        float safeDensity = Math.max(0.01f, density);
        float travelledInside = rightEdge - noteStartX - 24f * safeDensity;
        return Math.max(0f, Math.min(1f, travelledInside / (30f * safeDensity)));
    }
}
