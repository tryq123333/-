package com.luoke.autopiano;

import android.accessibilityservice.AccessibilityServiceInfo;
import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.database.Cursor;
import android.graphics.Typeface;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.View;
import android.view.accessibility.AccessibilityManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.List;

public class MainActivity extends Activity { // SONG_RANGE_CHECK_TOGGLE_V18
    private static final int REQUEST_MIDI = 1001;
    /** SONG_SPECIFIC_ROLL_UI_V2 */
    static final String PREFS = "luoke_auto_piano";
    static final String KEY_SONG_PATH = "song_path";
    static final String KEY_SONG_NAME = "song_name";
    static final String KEY_TRANSPOSE = "transpose";
    static final String KEY_SPEED = "speed_percent";

    static String songTransposePreferenceKey(String path) {
        return "song_transpose_" + Integer.toHexString(path == null ? 0 : path.hashCode());
    }

    static int songTranspose(SharedPreferences prefs, String path) {
        if (path == null || path.isEmpty()) return prefs.getInt(KEY_TRANSPOSE, 0);
        String key = songTransposePreferenceKey(path);
        if (prefs.contains(key)) return prefs.getInt(key, 0);
        return path.equals(prefs.getString(KEY_SONG_PATH, ""))
                ? prefs.getInt(KEY_TRANSPOSE, 0) : 0;
    }

    private android.content.SharedPreferences prefs;
    private TextView serviceStatus;
    private TextView songInfo;
    private TextView mapInfo;
    private TextView pitchShiftValue;
    private TextView speedValue;
    private SeekBar transposeBar;
    private SeekBar speedBar;
    private Button calibrateButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        buildUi();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshUi();
    }

    private void buildUi() {
        int pad = dp(18);
        ScrollView scroller = new ScrollView(this);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(pad, pad, pad, pad);
        content.setBackgroundColor(0xfff5f3ee);
        scroller.addView(content);

        TextView title = text("奏乐", 27, true);
        content.addView(title);
        TextView subtitle = text("洛克王国世界九键手碟 MIDI 演奏助手", 14, false);
        subtitle.setTextColor(0xff5d655f);
        content.addView(subtitle, margin(0, dp(3), 0, dp(14)));

        serviceStatus = text("触控服务状态检查中…", 15, true);
        content.addView(card(serviceStatus), margin(0, 0, 0, dp(12)));

        TextView modeLabel = text("当前乐器：九键手碟", 16, true);
        content.addView(modeLabel, margin(0, 0, 0, dp(12)));

        Button enable = button("1. 开启无障碍触控服务");
        enable.setOnClickListener(v -> openAccessibilitySettings());
        content.addView(enable, margin(0, 0, 0, dp(8)));

        Button importButton = button("2. 批量导入 MIDI 曲谱（支持多选）");
        importButton.setOnClickListener(v -> openMidiPicker());
        content.addView(importButton, margin(0, 0, 0, dp(8)));

        songInfo = text("还没有导入曲谱。", 14, false);
        content.addView(card(songInfo), margin(0, 0, 0, dp(12)));

        TextView shiftTitle = text("移调", 16, true);
        content.addView(shiftTitle);
        pitchShiftValue = text("0 半音", 14, false);
        content.addView(pitchShiftValue);
        transposeBar = new SeekBar(this);
        transposeBar.setMax(24);
        transposeBar.setProgress(songTranspose(prefs, prefs.getString(KEY_SONG_PATH, "")) + 12);
        transposeBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int shift = progress - 12;
                String currentPath = prefs.getString(KEY_SONG_PATH, "");
                SharedPreferences.Editor transposeEdit = prefs.edit().putInt(KEY_TRANSPOSE, shift);
                if (currentPath != null && !currentPath.isEmpty()) {
                    transposeEdit.putInt(songTransposePreferenceKey(currentPath), shift);
                }
                transposeEdit.apply();
                pitchShiftValue.setText((shift > 0 ? "+" : "") + shift + " 半音");
                if (fromUser) refreshSongInfo();
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });
        content.addView(transposeBar, margin(0, 0, 0, dp(12)));

        TextView speedTitle = text("演奏速度", 16, true);
        content.addView(speedTitle);
        speedValue = text("100%", 14, false);
        content.addView(speedValue);
        speedBar = new SeekBar(this);
        speedBar.setMax(150);
        speedBar.setProgress(prefs.getInt(KEY_SPEED, 100) - 50);
        speedBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int speed = progress + 50;
                prefs.edit().putInt(KEY_SPEED, speed).apply();
                speedValue.setText(speed + "%");
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });
        content.addView(speedBar, margin(0, 0, 0, dp(12)));

        calibrateButton = button("3. 准备九键校准（回游戏点悬浮图标）");
        calibrateButton.setOnClickListener(v -> {
            MusicAccessibilityService service = MusicAccessibilityService.getInstance();
            if (service == null) {
                Toast.makeText(this, "请先开启无障碍服务，再返回游戏", Toast.LENGTH_LONG).show();
                openAccessibilitySettings();
            } else {
                service.prepareCalibration();
            }
        });
        content.addView(calibrateButton, margin(0, 0, 0, dp(8)));

        Button reset = button("重置当前乐器的校准位置");
        reset.setOnClickListener(v -> {
            InstrumentLayout.clearCurrentLayout(prefs);
            refreshUi();
            Toast.makeText(this, "音符位置已清除", Toast.LENGTH_SHORT).show();
        });
        content.addView(reset, margin(0, 0, 0, dp(12)));

        mapInfo = text("已校准 0/9 个音符", 14, false);
        content.addView(card(mapInfo), margin(0, 0, 0, dp(12)));

        TextView notice = text(
                "使用方法：先导入 MIDI 并开启无障碍触控服务。回到游戏、打开乐器后，点悬浮面板的“校准”，按顶部提示完成校准；之后可从悬浮面板开始、暂停或停止。\n\n" +
                "当前仅支持九键手碟，映射为 A2、E3、F3、G3、A3、B3、C4、D4、E4。先完成九键校准，再选择曲谱并检查音域；超出九键音域的曲谱可尝试移调。\n\n" +
                "曲谱有超出当前音域的音符时会阻止演奏并列出缺音，可尝试移调。校准层会暂时接收点击位置，不会触发游戏音符；请在游戏横屏乐器界面校准。触控兼容性和节奏需实机验证；自动输入可能违反游戏规则或触发限制，请自行评估。",
                13, false);
        notice.setTextColor(0xff4b534e);
        content.addView(card(notice));

        setContentView(scroller);
    }

    private void refreshUi() {
        boolean enabled = isAccessibilityEnabled();
        serviceStatus.setText(enabled
                ? "触控服务：已开启。回到游戏后可使用悬浮控制。"
                : "触控服务：未开启。点击上方按钮进入系统设置并手动启用。");
        serviceStatus.setTextColor(enabled ? 0xff236b43 : 0xff8c4b1f);
        mapInfo.setText("当前九键手碟已校准 " + InstrumentLayout.calibratedCount(prefs) + "/9 个音符" +
                (MusicAccessibilityService.getInstance() == null ? "；服务还未连接" : "；服务已连接"));
        updateCalibrationButtonLabel();
        String activePath = prefs.getString(KEY_SONG_PATH, "");
        int activeTranspose = songTranspose(prefs, activePath);
        if (transposeBar != null) transposeBar.setProgress(activeTranspose + 12);
        pitchShiftValue.setText((activeTranspose > 0 ? "+" : "") + activeTranspose + " 半音");
        speedValue.setText(prefs.getInt(KEY_SPEED, 100) + "%");
        refreshSongInfo();
    }

    private void updateCalibrationButtonLabel() {
        if (calibrateButton == null) return;
        calibrateButton.setText("3. 准备九键校准（回游戏点悬浮图标）");
    }

    private void refreshSongInfo() {
        String path = prefs.getString(KEY_SONG_PATH, "");
        if (path == null || path.isEmpty() || !new File(path).isFile()) {
            songInfo.setText("还没有导入曲谱。支持标准 .mid / .midi 文件。\n请先下载 MIDI 文件，再点上方按钮导入。");
            return;
        }
        try {
            MidiParser.MidiSong song = MidiParser.parse(new File(path));
            int transpose = songTranspose(prefs, path);
            List<String> missing = InstrumentLayout.missingNotes(song, transpose, prefs);
            boolean rangeCheckEnabled = prefs.getBoolean(SongAbRangeKeys.rangeCheckEnabledKey(path), true);
            long seconds = song.durationMicros / 1_000_000L;
            StringBuilder text = new StringBuilder();
            text.append("曲谱：").append(prefs.getString(KEY_SONG_NAME, song.name)).append('\n');
            text.append("音符：").append(song.notes.size()).append(" 个；时长约 ").append(seconds / 60).append(':');
            if (seconds % 60 < 10) text.append('0');
            text.append(seconds % 60).append('\n');
            if (!rangeCheckEnabled) {
                text.append("音域检测：已关闭（超出九键映射的音符会跳过，其余音符照常演奏）");
            } else if (missing.isEmpty()) {
                text.append("音域检查：通过（全部音符都有九键映射）");
            }
            else {
                text.append("音域检查：有 ").append(missing.size()).append(" 种不支持的音高\n");
                int shown = Math.min(16, missing.size());
                text.append("缺少：");
                for (int i = 0; i < shown; i++) {
                    if (i > 0) text.append("、");
                    text.append(missing.get(i));
                }
                if (missing.size() > shown) text.append("…");
                text.append("\n请调整移调后重新检查。");
            }
            songInfo.setText(text.toString());
        } catch (Exception ex) {
            songInfo.setText("曲谱读取失败：" + ex.getMessage());
        }
    }

    private void openMidiPicker() { // BATCH_MIDI_IMPORT_V1
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        // Let Android's document picker select many downloaded MIDI files in one pass.
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        startActivityForResult(intent, REQUEST_MIDI);
    }

    private static final class ImportedMidiResult {
        final File file;
        final String displayName;
        final int noteCount;
        ImportedMidiResult(File file, String displayName, int noteCount) {
            this.file = file;
            this.displayName = displayName;
            this.noteCount = noteCount;
        }
    }

    private ImportedMidiResult copyAndValidateMidi(Uri uri, File songsDir) throws Exception {
        String displayName = getDisplayName(uri);
        if (displayName == null || displayName.trim().isEmpty()) displayName = "imported.mid";
        String safeName = displayName.replaceAll("[^a-zA-Z0-9._\\u4e00-\\u9fa5-]", "_");
        if (safeName.trim().isEmpty()) safeName = "imported.mid";
        String lowerSafeName = safeName.toLowerCase(java.util.Locale.ROOT);
        if (!lowerSafeName.endsWith(".mid") && !lowerSafeName.endsWith(".midi")) safeName += ".mid";

        File out = new File(songsDir, System.currentTimeMillis() + "_" + safeName);
        while (out.exists()) out = new File(songsDir, System.currentTimeMillis() + "_" + safeName);
        try {
            try (InputStream in = getContentResolver().openInputStream(uri);
                 FileOutputStream stream = new FileOutputStream(out, false)) {
                if (in == null) throw new IllegalStateException("无法打开文件：" + displayName);
                byte[] buffer = new byte[32 * 1024];
                int count;
                long total = 0;
                while ((count = in.read(buffer)) != -1) {
                    total += count;
                    if (total > 32L * 1024L * 1024L) {
                        throw new IllegalArgumentException("文件超过 32 MB：" + displayName);
                    }
                    stream.write(buffer, 0, count);
                }
            }
            MidiParser.MidiSong song = MidiParser.parse(out);
            if (song == null) throw new IllegalArgumentException("无法识别 MIDI：" + displayName);
            prefs.edit()
                    .putString("song_label_" + out.getName(), displayName)
                    .putInt(songTransposePreferenceKey(out.getAbsolutePath()), 0)
                    .apply();
            return new ImportedMidiResult(out, displayName, song.notes == null ? 0 : song.notes.size());
        } catch (Exception ex) {
            if (out.exists()) out.delete();
            throw ex;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_MIDI || resultCode != RESULT_OK || data == null) return;

        java.util.ArrayList<Uri> selectedUris = new java.util.ArrayList<>();
        android.content.ClipData clipData = data.getClipData();
        if (clipData != null && clipData.getItemCount() > 0) {
            for (int i = 0; i < clipData.getItemCount(); i++) {
                Uri uri = clipData.getItemAt(i).getUri();
                if (uri != null && !selectedUris.contains(uri)) selectedUris.add(uri);
            }
        } else if (data.getData() != null) {
            selectedUris.add(data.getData());
        }
        if (selectedUris.isEmpty()) return;

        File songsDir = new File(getFilesDir(), "imported_songs");
        if (!songsDir.exists() && !songsDir.mkdirs()) {
            Toast.makeText(this, "无法创建曲库目录", Toast.LENGTH_LONG).show();
            return;
        }

        String existingPath = prefs.getString(KEY_SONG_PATH, "");
        boolean activeSongExists = existingPath != null && !existingPath.isEmpty()
                && new File(existingPath).isFile();
        boolean keepCurrentSelection = selectedUris.size() > 1 && activeSongExists;
        int succeeded = 0;
        int failed = 0;
        String firstError = null;
        ImportedMidiResult firstImported = null;
        ImportedMidiResult singleImported = null;

        for (Uri uri : selectedUris) {
            try {
                ImportedMidiResult imported = copyAndValidateMidi(uri, songsDir);
                succeeded++;
                if (firstImported == null) firstImported = imported;
                singleImported = imported;
            } catch (Exception ex) {
                failed++;
                if (firstError == null) firstError = ex.getMessage();
            }
        }

        if (succeeded > 0) {
            // A single import retains the previous behavior of selecting that song.
            // Batch import keeps the currently selected song; if there isn't one yet,
            // the first successful file becomes the initial selection.
            ImportedMidiResult activate = null;
            if (selectedUris.size() == 1) {
                activate = singleImported;
            } else if (!activeSongExists) {
                activate = firstImported;
            }
            if (activate != null) {
                prefs.edit()
                        .putString(KEY_SONG_PATH, activate.file.getAbsolutePath())
                        .putString(KEY_SONG_NAME, activate.displayName)
                        .putInt(songTransposePreferenceKey(activate.file.getAbsolutePath()), 0)
                        .putInt(KEY_TRANSPOSE, 0)
                        .apply();
            }
            refreshSongInfo();
        }

        if (selectedUris.size() == 1 && succeeded == 1) {
            Toast.makeText(this,
                    "曲谱读取成功：" + (singleImported == null ? 0 : singleImported.noteCount) + " 个音符",
                    Toast.LENGTH_SHORT).show();
        } else if (succeeded > 0) {
            String summary = "批量导入完成：成功 " + succeeded + " 首";
            if (failed > 0) summary += "，失败 " + failed + " 首";
            summary += "。可在曲目列表中搜索歌曲。";
            Toast.makeText(this, summary, Toast.LENGTH_LONG).show();
        } else if (firstError != null) {
            Toast.makeText(this, "导入失败：" + firstError, Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(this, "没有成功导入曲目。", Toast.LENGTH_LONG).show();
        }
        if (succeeded == 0 || failed > 0) refreshSongInfo();
    }

    private String getDisplayName(Uri uri) {
        try (Cursor cursor = getContentResolver().query(uri, null, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int column = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (column >= 0) return cursor.getString(column);
            }
        } catch (Exception ignored) { }
        return null;
    }

    private boolean isAccessibilityEnabled() {
        AccessibilityManager manager = (AccessibilityManager) getSystemService(Context.ACCESSIBILITY_SERVICE);
        if (manager == null) return false;
        String ours = new ComponentName(this, MusicAccessibilityService.class).flattenToString();
        List<AccessibilityServiceInfo> list = manager.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK);
        for (AccessibilityServiceInfo info : list) {
            if (info.getId() != null && info.getId().contains(ours)) return true;
        }
        return false;
    }

    private void openAccessibilitySettings() {
        try { startActivity(new Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS)); }
        catch (Exception ex) { Toast.makeText(this, "无法打开系统无障碍设置", Toast.LENGTH_LONG).show(); }
    }

    private TextView text(String value, int sp, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(sp);
        view.setTextColor(0xff252b27);
        if (bold) view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        view.setLineSpacing(dp(2), 1.0f);
        return view;
    }

    private View card(View child) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(12), dp(11), dp(12), dp(11));
        box.setBackgroundColor(0xffffffff);
        box.addView(child);
        return box;
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        return b;
    }

    private LinearLayout.LayoutParams margin(int left, int top, int right, int bottom) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        p.setMargins(left, top, right, bottom);
        return p;
    }

    private int dp(float value) { return (int) (value * getResources().getDisplayMetrics().density + 0.5f); }
}
