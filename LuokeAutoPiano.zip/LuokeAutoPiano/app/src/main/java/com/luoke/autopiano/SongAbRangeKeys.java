package com.luoke.autopiano;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/** Stable, collision-resistant preference keys for each imported MIDI path. */
final class SongAbRangeKeys {
    private SongAbRangeKeys() { }

    static String startKey(String songPath) {
        return "practice_start_ms_song_" + pathDigest(songPath);
    }

    static String endKey(String songPath) {
        return "practice_end_ms_song_" + pathDigest(songPath);
    }

    static String rangeCheckEnabledKey(String songPath) {
        return "song_range_check_enabled_" + pathDigest(songPath);
    }

    private static String pathDigest(String songPath) {
        String normalized = songPath == null ? "" : songPath;
        try {
            byte[] digest = MessageDigest.getInstance("SHA-256")
                    .digest(normalized.getBytes(StandardCharsets.UTF_8));
            char[] hex = "0123456789abcdef".toCharArray();
            char[] result = new char[digest.length * 2];
            for (int i = 0; i < digest.length; i++) {
                int value = digest[i] & 0xff;
                result[i * 2] = hex[value >>> 4];
                result[i * 2 + 1] = hex[value & 0x0f];
            }
            return new String(result);
        } catch (NoSuchAlgorithmException impossible) {
            throw new IllegalStateException("SHA-256 is required by Android.", impossible);
        }
    }
}
