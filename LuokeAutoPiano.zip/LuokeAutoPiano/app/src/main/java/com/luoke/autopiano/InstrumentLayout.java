package com.luoke.autopiano;

import android.content.SharedPreferences;
import android.graphics.Point;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

/**
 * Maps MIDI pitches to calibrated on-screen touch points.
 *
 * The currently photographed instrument is the nine-note handpan. A generic 88-key
 * layout is also included for a future in-game piano instrument: it is derived from
 * four calibration taps rather than storing 88 separate coordinates.
 */
public final class InstrumentLayout {
    public static final String MODE_NINE = "nine";
    public static final String MODE_PIANO88 = "piano88";
    public static final String KEY_LAYOUT_MODE = "layout_mode";

    public static final int[] PITCHES = {45, 52, 53, 55, 57, 59, 60, 62, 64};
    public static final String[] NOTE_NAMES = {"A2", "E3", "F3", "G3", "A3", "B3", "C4", "D4", "E4"};
    public static final String[] SOLFEGE = {"低音 6", "3", "4", "5", "6", "7", "高音 1", "高音 2", "高音 3"};

    private static final String PREFIX = "note_xy_";
    private static final String WIDE_LOW_X = "wide_low_x";
    private static final String WIDE_HIGH_X = "wide_high_x";
    private static final String WIDE_WHITE_Y = "wide_white_y";
    private static final String WIDE_BLACK_Y = "wide_black_y";
    public static final int PIANO_LOWEST_MIDI = 21;  // A0
    public static final int PIANO_HIGHEST_MIDI = 108; // C8
    private static final int PIANO_WHITE_KEY_COUNT = 52;

    private InstrumentLayout() {}

    public static String selectedMode(SharedPreferences prefs) {
        String previousMode = prefs.getString(KEY_LAYOUT_MODE, MODE_NINE);
        if (!MODE_NINE.equals(previousMode)) {
            prefs.edit().putString(KEY_LAYOUT_MODE, MODE_NINE).apply();
        }
        return MODE_NINE;
    }

    public static int indexOfPitch(int pitch) {
        for (int i = 0; i < PITCHES.length; i++) if (PITCHES[i] == pitch) return i;
        return -1;
    }

    public static boolean isBlackMidiNote(int pitch) {
        int pitchClass = Math.floorMod(pitch, 12);
        return pitchClass == 1 || pitchClass == 3 || pitchClass == 6 || pitchClass == 8 || pitchClass == 10;
    }

    public static boolean supportsPitch(SharedPreferences prefs, int pitch) {
        if (MODE_PIANO88.equals(selectedMode(prefs))) {
            return pitch >= PIANO_LOWEST_MIDI && pitch <= PIANO_HIGHEST_MIDI;
        }
        return indexOfPitch(pitch) >= 0;
    }

    public static Point pointForPitch(SharedPreferences prefs, int pitch) {
        if (MODE_PIANO88.equals(selectedMode(prefs))) return pointForPiano88(prefs, pitch);
        int index = indexOfPitch(pitch);
        if (index < 0 || !prefs.contains(keyX(PITCHES[index])) || !prefs.contains(keyY(PITCHES[index]))) return null;
        return new Point(prefs.getInt(keyX(PITCHES[index]), -1), prefs.getInt(keyY(PITCHES[index]), -1));
    }

    private static Point pointForPiano88(SharedPreferences prefs, int pitch) {
        if (!isPiano88Calibrated(prefs) || pitch < PIANO_LOWEST_MIDI || pitch > PIANO_HIGHEST_MIDI) return null;
        int lowX = prefs.getInt(WIDE_LOW_X, 0);
        int highX = prefs.getInt(WIDE_HIGH_X, 0);
        int whiteY = prefs.getInt(WIDE_WHITE_Y, 0);
        int blackY = prefs.getInt(WIDE_BLACK_Y, 0);
        int whitesBefore = countWhiteKeys(PIANO_LOWEST_MIDI, pitch);
        double whiteKeyStep = (highX - (double) lowX) / (PIANO_WHITE_KEY_COUNT - 1);
        double xIndex = isBlackMidiNote(pitch) ? whitesBefore - 0.5 : whitesBefore;
        int x = (int) Math.round(lowX + xIndex * whiteKeyStep);
        return new Point(x, isBlackMidiNote(pitch) ? blackY : whiteY);
    }

    private static int countWhiteKeys(int fromInclusive, int toExclusive) {
        int count = 0;
        for (int pitch = fromInclusive; pitch < toExclusive; pitch++) {
            if (!isBlackMidiNote(pitch)) count++;
        }
        return count;
    }

    public static void savePoint(SharedPreferences prefs, int index, int x, int y) {
        if (index < 0 || index >= PITCHES.length) return;
        prefs.edit().putInt(keyX(PITCHES[index]), x).putInt(keyY(PITCHES[index]), y).apply();
    }

    public static void savePianoAnchor(SharedPreferences prefs, int step, int x, int y) {
        SharedPreferences.Editor editor = prefs.edit();
        switch (step) {
            case 0: editor.putInt(WIDE_LOW_X, x); break;    // center of A0 white key
            case 1: editor.putInt(WIDE_HIGH_X, x); break;   // center of C8 white key
            case 2: editor.putInt(WIDE_WHITE_Y, y); break;  // any white key center
            case 3: editor.putInt(WIDE_BLACK_Y, y); break;  // any black key center
            default: return;
        }
        editor.apply();
    }

    public static void clearCurrentLayout(SharedPreferences prefs) {
        SharedPreferences.Editor editor = prefs.edit();
        if (MODE_PIANO88.equals(selectedMode(prefs))) {
            editor.remove(WIDE_LOW_X).remove(WIDE_HIGH_X).remove(WIDE_WHITE_Y).remove(WIDE_BLACK_Y);
        } else {
            for (int pitch : PITCHES) {
                editor.remove(keyX(pitch));
                editor.remove(keyY(pitch));
            }
        }
        editor.apply();
    }

    public static void clearPoints(SharedPreferences prefs) {
        SharedPreferences.Editor editor = prefs.edit();
        for (int pitch : PITCHES) {
            editor.remove(keyX(pitch));
            editor.remove(keyY(pitch));
        }
        editor.remove(WIDE_LOW_X).remove(WIDE_HIGH_X).remove(WIDE_WHITE_Y).remove(WIDE_BLACK_Y);
        editor.apply();
    }

    public static int calibratedCount(SharedPreferences prefs) {
        if (MODE_PIANO88.equals(selectedMode(prefs))) return pianoAnchorCount(prefs);
        int count = 0;
        for (int pitch : PITCHES) if (prefs.contains(keyX(pitch)) && prefs.contains(keyY(pitch))) count++;
        return count;
    }

    public static int pianoAnchorCount(SharedPreferences prefs) {
        int count = 0;
        if (prefs.contains(WIDE_LOW_X)) count++;
        if (prefs.contains(WIDE_HIGH_X)) count++;
        if (prefs.contains(WIDE_WHITE_Y)) count++;
        if (prefs.contains(WIDE_BLACK_Y)) count++;
        return count;
    }

    public static boolean isPiano88Calibrated(SharedPreferences prefs) {
        if (pianoAnchorCount(prefs) != 4) return false;
        int lowX = prefs.getInt(WIDE_LOW_X, 0);
        int highX = prefs.getInt(WIDE_HIGH_X, 0);
        return highX > lowX;
    }

    public static int calibrationSteps(SharedPreferences prefs) {
        return MODE_PIANO88.equals(selectedMode(prefs)) ? 4 : PITCHES.length;
    }

    public static List<String> missingNotes(MidiParser.MidiSong song, int transpose, SharedPreferences prefs) {
        Set<Integer> missing = new TreeSet<>();
        for (MidiParser.NoteEvent event : song.notes) {
            int pitch = event.pitch + transpose;
            if (!supportsPitch(prefs, pitch)) missing.add(pitch);
        }
        List<String> result = new ArrayList<>();
        for (int pitch : missing) result.add(MidiParser.noteName(pitch));
        return result;
    }

    public static List<String> missingNotes(MidiParser.MidiSong song, int transpose) {
        Set<Integer> missing = new TreeSet<>();
        for (MidiParser.NoteEvent event : song.notes) {
            int pitch = event.pitch + transpose;
            if (indexOfPitch(pitch) < 0) missing.add(pitch);
        }
        List<String> result = new ArrayList<>();
        for (int pitch : missing) result.add(MidiParser.noteName(pitch));
        return result;
    }

    public static int transformedPitch(int pitch, int transpose) { return pitch + transpose; }

    public static String displayLabel(int index) {
        if (index < 0 || index >= PITCHES.length) return "";
        return SOLFEGE[index] + "（" + NOTE_NAMES[index] + "）";
    }

    public static String pianoCalibrationPrompt(int step) {
        switch (step) {
            case 0: return "第 1/4 步：点最左边白键 A0 的中心";
            case 1: return "第 2/4 步：点最右边白键 C8 的中心";
            case 2: return "第 3/4 步：点任意白键的中心（校准白键高度）";
            case 3: return "第 4/4 步：点任意黑键的中心（校准黑键高度）";
            default: return "88 键校准完成";
        }
    }

    private static String keyX(int pitch) { return PREFIX + pitch + "_x"; }
    private static String keyY(int pitch) { return PREFIX + pitch + "_y"; }
}
