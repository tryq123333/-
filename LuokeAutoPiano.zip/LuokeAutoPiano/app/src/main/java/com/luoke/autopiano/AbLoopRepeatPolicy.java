package com.luoke.autopiano;

/** Decides whether a completed A/B pass should return to A. */
final class AbLoopRepeatPolicy {
    private AbLoopRepeatPolicy() { }
    static boolean shouldRepeat(boolean abLoopEnabled, boolean repeatEnabled) {
        return abLoopEnabled && repeatEnabled;
    }
}
