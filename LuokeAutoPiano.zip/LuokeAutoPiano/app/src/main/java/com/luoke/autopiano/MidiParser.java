package com.luoke.autopiano;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/** Small Standard MIDI File reader that works on Android without javax.sound.midi. */
public final class MidiParser {
    private static final int DEFAULT_MICROS_PER_QUARTER = 500_000;
    private MidiParser() {}

    public static final class NoteEvent {
        public final long startMicros;
        public final int pitch;
        public final int velocity;
        public final int order;
        /** Note gate length from MIDI note-on to note-off; may be zero for incomplete files. */
        public final long durationMicros;

        NoteEvent(long startMicros, int pitch, int velocity, int order, long durationMicros) {
            this.startMicros = startMicros;
            this.pitch = pitch;
            this.velocity = velocity;
            this.order = order;
            this.durationMicros = Math.max(0L, durationMicros);
        }
    }

    public static final class MidiSong {
        public final String name;
        public final int ppq;
        public final List<NoteEvent> notes;
        public final long durationMicros;

        MidiSong(String name, int ppq, List<NoteEvent> notes, long durationMicros) {
            this.name = name;
            this.ppq = ppq;
            this.notes = notes;
            this.durationMicros = durationMicros;
        }
    }

    private static final class Cursor {
        final byte[] data;
        final int end;
        int pos;

        Cursor(byte[] data, int pos, int end) {
            this.data = data;
            this.pos = pos;
            this.end = end;
        }

        int u8() throws IOException {
            if (pos >= end) throw new IOException("MIDI 文件意外结束");
            return data[pos++] & 0xff;
        }

        int u16() throws IOException { return (u8() << 8) | u8(); }

        long u32() throws IOException {
            return ((long) u8() << 24) | ((long) u8() << 16) | ((long) u8() << 8) | u8();
        }

        long vlq() throws IOException {
            long value = 0;
            for (int i = 0; i < 4; i++) {
                int b = u8();
                value = (value << 7) | (b & 0x7f);
                if ((b & 0x80) == 0) return value;
            }
            throw new IOException("MIDI 变长数值格式错误");
        }

        void skip(long count) throws IOException {
            if (count < 0 || count > end - pos) throw new IOException("MIDI 数据块越界");
            pos += (int) count;
        }
    }

    private static final class RawNote {
        final long tick;
        long endTick;
        final int pitch;
        final int velocity;
        final int order;
        RawNote(long tick, int pitch, int velocity, int order) {
            this.tick = tick; this.endTick = -1L; this.pitch = pitch; this.velocity = velocity; this.order = order;
        }
    }

    private static final class Tempo {
        final long tick;
        final int microsPerQuarter;
        final int order;
        Tempo(long tick, int microsPerQuarter, int order) {
            this.tick = tick; this.microsPerQuarter = microsPerQuarter; this.order = order;
        }
    }

    private static final class TempoSegment {
        final long startTick;
        final long startMicros;
        final int microsPerQuarter;
        TempoSegment(long startTick, long startMicros, int microsPerQuarter) {
            this.startTick = startTick; this.startMicros = startMicros; this.microsPerQuarter = microsPerQuarter;
        }
    }

    public static MidiSong parse(File file) throws IOException {
        byte[] bytes = Files.readAllBytes(file.toPath());
        if (bytes.length < 14) throw new IOException("文件太短，不是有效 MIDI");
        Cursor c = new Cursor(bytes, 0, bytes.length);
        expectFourCc(c, "MThd");
        long headerLength = c.u32();
        if (headerLength < 6 || headerLength > bytes.length - c.pos) throw new IOException("MIDI 文件头损坏");
        int format = c.u16();
        int trackCount = c.u16();
        int division = c.u16();
        if (format > 1) throw new IOException("暂不支持 MIDI 格式 2");
        if (trackCount < 1 || trackCount > 256) throw new IOException("MIDI 音轨数量异常");
        if ((division & 0x8000) != 0 || division == 0) throw new IOException("暂不支持 SMPTE 时间码格式的 MIDI");
        int ppq = division;
        c.skip(headerLength - 6);

        List<RawNote> rawNotes = new ArrayList<>();
        List<Tempo> tempos = new ArrayList<>();
        tempos.add(new Tempo(0, DEFAULT_MICROS_PER_QUARTER, -1));
        int globalOrder = 0;
        int parsedTracks = 0;
        long songEndTick = 0;

        while (c.pos + 8 <= c.end && parsedTracks < trackCount) {
            String tag = fourCc(c);
            long size = c.u32();
            if (size > c.end - c.pos) throw new IOException("MIDI 音轨长度超出文件范围");
            int trackEnd = c.pos + (int) size;
            if (!"MTrk".equals(tag)) {
                c.pos = trackEnd;
                continue;
            }
            parsedTracks++;
            Cursor t = new Cursor(bytes, c.pos, trackEnd);
            long tick = 0;
            int runningStatus = 0;
            Map<Integer, Deque<RawNote>> activeNotes = new HashMap<>();
            while (t.pos < t.end) {
                tick += t.vlq();
                songEndTick = Math.max(songEndTick, tick);
                int first = t.u8();
                int status;
                int firstData = -1;
                if (first < 0x80) {
                    if (runningStatus < 0x80 || runningStatus >= 0xf0) throw new IOException("MIDI running status 无效");
                    status = runningStatus;
                    firstData = first;
                } else {
                    status = first;
                    if (status >= 0x80 && status <= 0xef) runningStatus = status;
                }

                if (status == 0xff) {
                    int metaType = t.u8();
                    long length = t.vlq();
                    if (metaType == 0x51 && length == 3) {
                        int micros = (t.u8() << 16) | (t.u8() << 8) | t.u8();
                        if (micros > 0) tempos.add(new Tempo(tick, micros, globalOrder++));
                    } else {
                        t.skip(length);
                    }
                    if (metaType == 0x2f) break;
                    continue;
                }
                if (status == 0xf0 || status == 0xf7) {
                    t.skip(t.vlq());
                    runningStatus = 0;
                    continue;
                }
                if (status < 0x80 || status > 0xef) throw new IOException("MIDI 系统消息格式不支持");
                int command = status & 0xf0;
                int dataLength = (command == 0xc0 || command == 0xd0) ? 1 : 2;
                int d1 = firstData >= 0 ? firstData : t.u8();
                int d2 = dataLength == 2 ? t.u8() : 0;
                int channelPitchKey = ((status & 0x0f) << 8) | (d1 & 0x7f);
                if (command == 0x90 && d2 > 0) {
                    RawNote note = new RawNote(tick, d1 & 0x7f, d2 & 0x7f, globalOrder++);
                    rawNotes.add(note);
                    activeNotes.computeIfAbsent(channelPitchKey, ignored -> new ArrayDeque<>()).addLast(note);
                } else if (command == 0x80 || (command == 0x90 && d2 == 0)) {
                    Deque<RawNote> active = activeNotes.get(channelPitchKey);
                    if (active != null && !active.isEmpty()) {
                        RawNote note = active.removeFirst();
                        note.endTick = Math.max(note.tick, tick);
                    }
                }
            }
            c.pos = trackEnd;
        }
        if (parsedTracks == 0) throw new IOException("MIDI 中没有可读取的音轨");
        if (rawNotes.isEmpty()) throw new IOException("MIDI 中没有找到音符");

        tempos.sort(Comparator.comparingLong((Tempo x) -> x.tick).thenComparingInt(x -> x.order));
        TreeMap<Long, Tempo> collapsed = new TreeMap<>();
        for (Tempo tempo : tempos) collapsed.put(tempo.tick, tempo);
        List<TempoSegment> segments = new ArrayList<>();
        long priorTick = 0;
        long elapsedMicros = 0;
        int currentTempo = DEFAULT_MICROS_PER_QUARTER;
        for (Map.Entry<Long, Tempo> entry : collapsed.entrySet()) {
            long tempoTick = entry.getKey();
            if (tempoTick > priorTick) {
                elapsedMicros += ((tempoTick - priorTick) * (long) currentTempo) / ppq;
                priorTick = tempoTick;
            }
            currentTempo = entry.getValue().microsPerQuarter;
            if (segments.isEmpty() || segments.get(segments.size() - 1).startTick != tempoTick) {
                segments.add(new TempoSegment(tempoTick, elapsedMicros, currentTempo));
            } else {
                segments.set(segments.size() - 1, new TempoSegment(tempoTick, elapsedMicros, currentTempo));
            }
        }
        if (segments.isEmpty()) segments.add(new TempoSegment(0, 0, DEFAULT_MICROS_PER_QUARTER));

        rawNotes.sort(Comparator.comparingLong((RawNote n) -> n.tick).thenComparingInt(n -> n.order));
        List<NoteEvent> result = new ArrayList<>(rawNotes.size());
        long duration = tickToMicros(songEndTick, segments, ppq);
        for (RawNote raw : rawNotes) {
            long at = tickToMicros(raw.tick, segments, ppq);
            // In malformed/truncated MIDIs, unmatched note-ons should not create unbounded holds.
            long endTick = raw.endTick >= raw.tick ? raw.endTick : Math.max(raw.tick, songEndTick);
            if (endTick <= raw.tick) endTick = raw.tick + Math.max(1L, ppq / 4L);
            long end = tickToMicros(endTick, segments, ppq);
            if (end < at) end = at;
            result.add(new NoteEvent(at, raw.pitch, raw.velocity, raw.order, end - at));
            duration = Math.max(duration, end);
            duration = Math.max(duration, at);
        }
        result.sort(Comparator.comparingLong((NoteEvent n) -> n.startMicros).thenComparingInt(n -> n.order));
        return new MidiSong(file.getName(), ppq, result, duration);
    }

    private static long tickToMicros(long tick, List<TempoSegment> segments, int ppq) {
        int index = 0;
        while (index + 1 < segments.size() && segments.get(index + 1).startTick <= tick) index++;
        TempoSegment segment = segments.get(index);
        return segment.startMicros + ((Math.max(0L, tick - segment.startTick) * (long) segment.microsPerQuarter) / ppq);
    }

    private static String fourCc(Cursor c) throws IOException {
        StringBuilder b = new StringBuilder(4);
        for (int i = 0; i < 4; i++) b.append((char) c.u8());
        return b.toString();
    }

    private static void expectFourCc(Cursor c, String expected) throws IOException {
        String actual = fourCc(c);
        if (!expected.equals(actual)) throw new IOException("不是标准 MIDI 文件（缺少 MThd）");
    }

    public static String noteName(int midiPitch) {
        if (midiPitch < 0 || midiPitch > 127) return "MIDI " + midiPitch;
        String[] names = {"C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"};
        return names[midiPitch % 12] + (midiPitch / 12 - 1);
    }
}
