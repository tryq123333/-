package com.luoke.autopiano;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;

/** A small wrapping layout for floating controls; children flow onto new rows when narrowed. */
public final class AdaptiveFlowLayout extends ViewGroup {
    private int itemSpacing;
    private int lineSpacing;
    private int[] childLeft = new int[0];
    private int[] childTop = new int[0];

    public AdaptiveFlowLayout(Context context) {
        super(context);
        init(context);
    }

    public AdaptiveFlowLayout(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    private void init(Context context) {
        float density = context.getResources().getDisplayMetrics().density;
        itemSpacing = Math.round(3 * density);
        lineSpacing = Math.round(4 * density);
        setClipToPadding(false);
    }

    @Override protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int count = getChildCount();
        if (childLeft.length < count) {
            childLeft = new int[count];
            childTop = new int[count];
        }
        int widthMode = MeasureSpec.getMode(widthMeasureSpec);
        int widthSize = MeasureSpec.getSize(widthMeasureSpec);
        int available = widthMode == MeasureSpec.UNSPECIFIED
                ? Integer.MAX_VALUE / 4
                : Math.max(0, widthSize - getPaddingLeft() - getPaddingRight());

        int x = getPaddingLeft();
        int y = getPaddingTop();
        int rowHeight = 0;
        int maxRight = x;
        boolean hasInRow = false;

        for (int i = 0; i < count; i++) {
            View child = getChildAt(i);
            if (child.getVisibility() == GONE) {
                childLeft[i] = childTop[i] = 0;
                continue;
            }
            measureChildWithMargins(child, widthMeasureSpec, 0, heightMeasureSpec, 0);
            MarginLayoutParams lp = (MarginLayoutParams) child.getLayoutParams();
            int childWidth = child.getMeasuredWidth() + lp.leftMargin + lp.rightMargin;
            int childHeight = child.getMeasuredHeight() + lp.topMargin + lp.bottomMargin;
            int nextWidth = (hasInRow ? itemSpacing : 0) + childWidth;
            int innerRight = getPaddingLeft() + available;
            if (hasInRow && x + nextWidth > innerRight) {
                x = getPaddingLeft();
                y += rowHeight + lineSpacing;
                rowHeight = 0;
                hasInRow = false;
            }
            if (hasInRow) x += itemSpacing;
            childLeft[i] = x + lp.leftMargin;
            childTop[i] = y + lp.topMargin;
            x += childWidth;
            rowHeight = Math.max(rowHeight, childHeight);
            maxRight = Math.max(maxRight, x);
            hasInRow = true;
        }
        int desiredWidth = maxRight + getPaddingRight();
        int desiredHeight = y + rowHeight + getPaddingBottom();
        setMeasuredDimension(resolveSize(desiredWidth, widthMeasureSpec),
                resolveSize(desiredHeight, heightMeasureSpec));
    }

    @Override protected void onLayout(boolean changed, int left, int top, int right, int bottom) {
        for (int i = 0; i < getChildCount(); i++) {
            View child = getChildAt(i);
            if (child.getVisibility() == GONE) continue;
            int x = childLeft[i];
            int y = childTop[i];
            child.layout(x, y, x + child.getMeasuredWidth(), y + child.getMeasuredHeight());
        }
    }

    @Override protected LayoutParams generateDefaultLayoutParams() {
        return new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
    }

    @Override public LayoutParams generateLayoutParams(AttributeSet attrs) {
        return new LayoutParams(getContext(), attrs);
    }

    @Override protected LayoutParams generateLayoutParams(ViewGroup.LayoutParams p) {
        if (p instanceof MarginLayoutParams) return new LayoutParams((MarginLayoutParams) p);
        return new LayoutParams(p);
    }

    @Override protected boolean checkLayoutParams(ViewGroup.LayoutParams p) {
        return p instanceof LayoutParams;
    }

    public static class LayoutParams extends MarginLayoutParams {
        public LayoutParams(Context context, AttributeSet attrs) { super(context, attrs); }
        public LayoutParams(int width, int height) { super(width, height); }
        public LayoutParams(ViewGroup.LayoutParams source) { super(source); }
        public LayoutParams(MarginLayoutParams source) { super(source); }
    }
}
