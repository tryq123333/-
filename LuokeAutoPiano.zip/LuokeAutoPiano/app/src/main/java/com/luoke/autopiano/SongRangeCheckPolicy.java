package com.luoke.autopiano;

/** Keeps out-of-range notes from blocking playback only when the user enables checking. */
final class SongRangeCheckPolicy {
    private SongRangeCheckPolicy() { }

    static boolean shouldBlockPlayback(boolean rangeCheckEnabled, boolean hasUnsupportedPitches) {
        return rangeCheckEnabled && hasUnsupportedPitches;
    }
}
