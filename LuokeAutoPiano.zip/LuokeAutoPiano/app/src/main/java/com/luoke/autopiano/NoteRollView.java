package com.luoke.autopiano;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;

import java.util.List;

/** Compact, resizable and seekable MIDI roll overlay. */
public final class NoteRollView extends View {
    public interface InteractionListener {
        void onSeek(long positionMicros);
        /** mode is MODE_MOVE or MODE_RESIZE; phase is PHASE_START, PHASE_UPDATE or PHASE_END. */
        void onWindowGesture(int mode, int edges, int dx, int dy, int phase);
        void onClose();
    }

    public static final int MODE_MOVE = 1;
    public static final int MODE_RESIZE = 2;
    public static final int PHASE_START = 0;
    public static final int PHASE_UPDATE = 1;
    public static final int PHASE_END = 2;
    public static final int EDGE_LEFT = 1;
    public static final int EDGE_TOP = 2;
    public static final int EDGE_RIGHT = 4;
    public static final int EDGE_BOTTOM = 8;

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final int touchSlop;
    private MidiParser.MidiSong song;
    private String title = "洛克自动琴";
    private int transpose;
    private long positionMicros;
    private long durationMicros;
    private long rangeStartMicros;
    private long rangeEndMicros;
    private int speedPercent = 100;
    private boolean playing;
    private boolean scrubbing;
    private InteractionListener interactionListener;

    private static final int TOUCH_NONE = 0;
    private static final int TOUCH_SCRUB = 1;
    private static final int TOUCH_MOVE_WINDOW = 2;
    private static final int TOUCH_RESIZE = 3;
    private static final int TOUCH_CLOSE = 4;
    private int touchMode = TOUCH_NONE;
    private int touchEdges;
    private float downX, downY;
    private float lastDx;
    private boolean gestureMoved;
    private long positionAtDown;
    private long positionDuringScrub;
    private final int[] colors = {
            0xff72d6ec, 0xff87dfa0, 0xfff28ab3, 0xffffd278,
            0xffa3adff, 0xff7bd8c2, 0xffc0adff, 0xffffad86,
            0xff9cd7fa, 0xffc0e77e, 0xfff1a9d5, 0xffa7d8c8
    };

    public NoteRollView(Context context) {
        super(context);
        touchSlop = ViewConfiguration.get(context).getScaledTouchSlop();
        setLayerType(View.LAYER_TYPE_HARDWARE, null);
        setClickable(true);
    }

    public void setInteractionListener(InteractionListener listener) {
        interactionListener = listener;
    }

    public void setData(MidiParser.MidiSong song, String title, int transpose,
                        long positionMicros, long durationMicros,
                        long rangeStartMicros, long rangeEndMicros,
                        int speedPercent, boolean playing) {
        this.song = song;
        this.title = title == null || title.trim().isEmpty() ? "洛克自动琴" : title;
        this.transpose = transpose;
        this.durationMicros = Math.max(0L, durationMicros);
        this.rangeStartMicros = Math.max(0L, rangeStartMicros);
        this.rangeEndMicros = Math.max(this.rangeStartMicros, rangeEndMicros);
        if (!scrubbing) this.positionMicros = clamp(positionMicros, this.rangeStartMicros, this.rangeEndMicros);
        this.speedPercent = Math.max(50, Math.min(200, speedPercent));
        this.playing = playing;
        invalidate();
    }

    public void setCursor(long positionMicros, boolean playing) {
        if (!scrubbing) this.positionMicros = clamp(positionMicros, rangeStartMicros, rangeEndMicros);
        this.playing = playing;
        invalidate();
    }

    private static long clamp(long value, long min, long max) {
        return Math.max(min, Math.min(max, value));
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        final float density = getResources().getDisplayMetrics().density;
        final float w = getWidth();
        final float h = getHeight();
        if (w <= 0 || h <= 0) return;

        // Glass-like navy panel with a quiet outline, inspired by the sample's floating player.
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(0xe91a2633);
        canvas.drawRoundRect(new RectF(0, 0, w, h), 12 * density, 12 * density, paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(1 * density);
        paint.setColor(0x7794b4c7);
        canvas.drawRoundRect(new RectF(.5f * density, .5f * density, w - .5f * density, h - .5f * density),
                12 * density, 12 * density, paint);
        paint.setStyle(Paint.Style.FILL);

        final float headerHeight = Math.min(49 * density, h * .40f);
        paint.setColor(0xfff7f9fc);
        paint.setTextSize(11 * density);
        paint.setFakeBoldText(true);
        String shownTitle = title;
        float titleMaxWidth = Math.max(45 * density, w * .29f - 12 * density);
        while (paint.measureText(shownTitle) > titleMaxWidth && shownTitle.length() > 4) {
            shownTitle = shownTitle.substring(0, shownTitle.length() - 2) + "…";
        }
        canvas.drawText(shownTitle, 8 * density, 16 * density, paint);
        paint.setFakeBoldText(false);
        paint.setTextSize(9 * density);
        paint.setColor(0xffcbd8e1);
        canvas.drawText(formatTime(positionMicros) + " / " + formatTime(durationMicros), 8 * density, 30 * density, paint);
        canvas.drawText("练习 " + formatTime(rangeStartMicros) + "–" + formatTime(rangeEndMicros)
                + "  " + (speedPercent / 100f) + "x", 8 * density, 43 * density, paint);

        final float closeSize = 10 * density;
        paint.setColor(0x99e1ebf2);
        paint.setStrokeWidth(1.7f * density);
        float closeX = w - 18 * density;
        float closeY = 13 * density;
        canvas.drawLine(closeX - closeSize / 2, closeY - closeSize / 2,
                closeX + closeSize / 2, closeY + closeSize / 2, paint);
        canvas.drawLine(closeX - closeSize / 2, closeY + closeSize / 2,
                closeX + closeSize / 2, closeY - closeSize / 2, paint);
        paint.setStrokeWidth(1 * density);
        paint.setStyle(Paint.Style.FILL);

        final float left = Math.min(w - 20 * density, Math.max(82 * density, w * .30f));
        final float right = w - 7 * density;
        final float top = Math.min(h - 28 * density, Math.max(47 * density, headerHeight + 2 * density));
        final float bottom = h - 15 * density;
        final float timelineHeight = bottom - top;
        if (right <= left || timelineHeight <= 0) {
            drawResizeHandle(canvas, w, h, density);
            if (playing) postInvalidateDelayed(80L);
            return;
        }

        // The sheet shows fewer pitch rows in a small window and more as it is enlarged.
        int rowsByWidth = 2 + (int) ((w / density) / 100f);
        int rowsByHeight = (int) (timelineHeight / (17 * density));
        final int lanes = Math.max(3, Math.min(7, Math.min(rowsByWidth, Math.max(3, rowsByHeight))));
        final float laneHeight = timelineHeight / lanes;
        final long windowMicros = visibleWindowMicros(w, left, right, density);
        final float scale = (right - left) / (float) windowMicros;

        for (int lane = 0; lane < lanes; lane++) {
            float y = top + lane * laneHeight;
            paint.setColor(lane % 2 == 0 ? 0x21ffffff : 0x0fffffff);
            canvas.drawRoundRect(new RectF(left, y + .7f * density, right, y + laneHeight - .7f * density),
                    4 * density, 4 * density, paint);
        }

        if (song != null && song.notes != null) {
            long visibleEnd = positionMicros + windowMicros;
            long visibleStart = Math.max(0L, positionMicros - 500_000L);
            List<MidiParser.NoteEvent> notes = song.notes;
            int low = 0, high = notes.size();
            while (low < high) {
                int mid = (low + high) >>> 1;
                if (notes.get(mid).startMicros < visibleStart) low = mid + 1;
                else high = mid;
            }
            for (int i = low; i < notes.size(); i++) {
                MidiParser.NoteEvent note = notes.get(i);
                int pitch = note.pitch + transpose;
                long noteStart = note.startMicros;
                if (noteStart > visibleEnd) break;
                long noteDuration = note.durationMicros > 0 ? note.durationMicros : 260_000L;
                long noteEnd = noteStart + noteDuration;
                if (noteEnd < positionMicros) continue;
                if (noteStart < rangeStartMicros || noteStart >= rangeEndMicros) continue;
                long clippedStart = Math.max(noteStart, positionMicros);
                long clippedEnd = Math.min(Math.max(noteEnd, clippedStart + 180_000L), visibleEnd);
                float x1 = left + (clippedStart - positionMicros) * scale;
                float x2 = left + (clippedEnd - positionMicros) * scale;
                x1 = Math.max(left, x1);
                x2 = Math.min(right, Math.max(x1 + 12 * density, x2));
                int lane = pitchLane(pitch, lanes);
                float y = top + lane * laneHeight + 1.5f * density;
                float bh = Math.max(5 * density, laneHeight - 3 * density);
                RectF bar = new RectF(x1, y, x2, Math.min(bottom, y + bh));
                paint.setColor(colors[Math.floorMod(pitch, colors.length)]);
                canvas.drawRoundRect(bar, 5 * density, 5 * density, paint);
                if (bar.width() > 20 * density && laneHeight > 15 * density) {
                    paint.setColor(0xff142029);
                    paint.setTextSize(Math.min(8 * density, laneHeight * .38f));
                    paint.setFakeBoldText(true);
                    canvas.drawText(MidiParser.noteName(pitch), x1 + 4 * density,
                            bar.centerY() + 3 * density, paint);
                    paint.setFakeBoldText(false);
                }
            }
        }

        // Light progress track and fixed playhead.
        paint.setColor(0x335c7b90);
        canvas.drawRoundRect(new RectF(left, bottom + 4 * density, right, bottom + 6 * density),
                2 * density, 2 * density, paint);
        float progress = durationMicros <= 0 ? 0 : Math.max(0, Math.min(1,
                (float) positionMicros / (float) durationMicros));
        paint.setColor(0xff65dfb0);
        canvas.drawRoundRect(new RectF(left, bottom + 4 * density, left + (right - left) * progress,
                bottom + 6 * density), 2 * density, 2 * density, paint);
        paint.setColor(0xfff7fbff);
        paint.setStrokeWidth(1.5f * density);
        canvas.drawLine(left, top, left, bottom + 8 * density, paint);
        paint.setStrokeWidth(1 * density);

        if (scrubbing) {
            paint.setColor(0xee65dfb0);
            paint.setStyle(Paint.Style.STROKE);
            canvas.drawRoundRect(new RectF(1.5f * density, 1.5f * density, w - 1.5f * density, h - 1.5f * density),
                    11 * density, 11 * density, paint);
            paint.setStyle(Paint.Style.FILL);
        }
        drawResizeHandle(canvas, w, h, density);
        if (playing) postInvalidateDelayed(80L);
    }

    private void drawResizeHandle(Canvas canvas, float w, float h, float density) {
        paint.setColor(0x88d4e6f2);
        paint.setStrokeWidth(1.5f * density);
        for (int i = 0; i < 3; i++) {
            float inset = (4 + i * 4) * density;
            canvas.drawLine(w - inset - 7 * density, h - 3 * density,
                    w - 3 * density, h - inset - 7 * density, paint);
        }
        paint.setStrokeWidth(1 * density);
    }

    private static long visibleWindowMicros(float width, float left, float right, float density) {
        float usableDp = Math.max(80f, (right - left) / density);
        // Narrow windows focus more tightly; enlarged windows show more upcoming music.
        return (long) (Math.max(4.0f, Math.min(16.0f, usableDp / 36.0f)) * 1_000_000L);
    }

    private static int pitchLane(int pitch, int laneCount) {
        return Math.min(laneCount - 1, Math.floorMod(pitch, 12) * laneCount / 12);
    }

    @Override public boolean onTouchEvent(MotionEvent event) {
        final float density = getResources().getDisplayMetrics().density;
        final float x = event.getX(), y = event.getY();
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN: {
                downX = x; downY = y;
                lastDx = 0;
                gestureMoved = false;
                positionAtDown = positionMicros;
                positionDuringScrub = positionMicros;
                touchEdges = detectEdges(x, y, getWidth(), getHeight(), 13 * density);
                if (y < 27 * density && x > getWidth() - 30 * density) {
                    touchMode = TOUCH_CLOSE;
                } else if (touchEdges != 0) {
                    touchMode = TOUCH_RESIZE;
                    notifyWindowGesture(MODE_RESIZE, touchEdges, 0, 0, PHASE_START);
                } else if (y < 47 * density && x < Math.max(82 * density, getWidth() * .30f)) {
                    touchMode = TOUCH_MOVE_WINDOW;
                    notifyWindowGesture(MODE_MOVE, 0, 0, 0, PHASE_START);
                } else {
                    touchMode = TOUCH_SCRUB;
                    scrubbing = false;
                }
                return true;
            }
            case MotionEvent.ACTION_MOVE: {
                float dx = x - downX;
                float dy = y - downY;
                if (Math.abs(dx) + Math.abs(dy) > touchSlop) gestureMoved = true;
                if (touchMode == TOUCH_MOVE_WINDOW) {
                    notifyWindowGesture(MODE_MOVE, 0, Math.round(dx), Math.round(dy), PHASE_UPDATE);
                } else if (touchMode == TOUCH_RESIZE) {
                    notifyWindowGesture(MODE_RESIZE, touchEdges, Math.round(dx), Math.round(dy), PHASE_UPDATE);
                } else if (touchMode == TOUCH_SCRUB && Math.abs(dx) > touchSlop && Math.abs(dx) > Math.abs(dy) * .85f) {
                    scrubbing = true;
                    float left = Math.min(getWidth() - 20 * density, Math.max(82 * density, getWidth() * .30f));
                    float trackWidth = Math.max(1f, getWidth() - 7 * density - left);
                    long window = visibleWindowMicros(getWidth(), left, getWidth() - 7 * density, density);
                    long delta = Math.round((-dx / trackWidth) * window);
                    positionDuringScrub = clamp(positionAtDown + delta, rangeStartMicros, rangeEndMicros);
                    positionMicros = positionDuringScrub;
                    lastDx = dx;
                    invalidate();
                }
                return true;
            }
            case MotionEvent.ACTION_UP: {
                if (touchMode == TOUCH_CLOSE && !gestureMoved) {
                    if (interactionListener != null) interactionListener.onClose();
                } else if (touchMode == TOUCH_SCRUB && scrubbing) {
                    positionMicros = positionDuringScrub;
                    if (interactionListener != null) interactionListener.onSeek(positionMicros);
                    scrubbing = false;
                    invalidate();
                } else if (touchMode == TOUCH_MOVE_WINDOW) {
                    notifyWindowGesture(MODE_MOVE, 0, Math.round(x - downX), Math.round(y - downY), PHASE_END);
                } else if (touchMode == TOUCH_RESIZE) {
                    notifyWindowGesture(MODE_RESIZE, touchEdges, Math.round(x - downX), Math.round(y - downY), PHASE_END);
                }
                touchMode = TOUCH_NONE;
                performClick();
                return true;
            }
            case MotionEvent.ACTION_CANCEL:
                if (touchMode == TOUCH_MOVE_WINDOW)
                    notifyWindowGesture(MODE_MOVE, 0, Math.round(x - downX), Math.round(y - downY), PHASE_END);
                else if (touchMode == TOUCH_RESIZE)
                    notifyWindowGesture(MODE_RESIZE, touchEdges, Math.round(x - downX), Math.round(y - downY), PHASE_END);
                scrubbing = false;
                touchMode = TOUCH_NONE;
                invalidate();
                return true;
        }
        return true;
    }

    @Override public boolean performClick() {
        super.performClick();
        return true;
    }

    private void notifyWindowGesture(int mode, int edges, int dx, int dy, int phase) {
        if (interactionListener != null) interactionListener.onWindowGesture(mode, edges, dx, dy, phase);
    }

    private static int detectEdges(float x, float y, float w, float h, float edge) {
        int result = 0;
        if (x <= edge) result |= EDGE_LEFT;
        if (x >= w - edge) result |= EDGE_RIGHT;
        if (y <= edge) result |= EDGE_TOP;
        if (y >= h - edge) result |= EDGE_BOTTOM;
        return result;
    }

    public static String formatTime(long micros) {
        long seconds = Math.max(0L, micros / 1_000_000L);
        long minutes = seconds / 60L;
        return minutes + ":" + (seconds % 60L < 10 ? "0" : "") + (seconds % 60L);
    }
}
