package com.luoke.autopiano;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

import java.util.List;

/** Compact translucent MIDI note-roll overlay inspired by mobile practice visualizers. */
public final class NoteRollView extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private MidiParser.MidiSong song;
    private String title = "洛克自动琴";
    private int transpose;
    private long positionMicros;
    private long durationMicros;
    private long rangeStartMicros;
    private long rangeEndMicros;
    private int speedPercent = 100;
    private boolean playing;

    private final int[] colors = {
            0xff59c8dc, 0xff72d78a, 0xffef789e, 0xffffcb68,
            0xff8e9fff, 0xff70d1bc, 0xffb5a2f4, 0xfff39c73,
            0xff87c8f1, 0xffabd86a, 0xffe59acb, 0xff93c1b0
    };

    public NoteRollView(Context context) {
        super(context);
        setLayerType(View.LAYER_TYPE_HARDWARE, null);
    }

    public void setData(MidiParser.MidiSong song, String title, int transpose,
                        long positionMicros, long durationMicros,
                        long rangeStartMicros, long rangeEndMicros,
                        int speedPercent, boolean playing) {
        this.song = song;
        this.title = title == null || title.trim().isEmpty() ? "洛克自动琴" : title;
        this.transpose = transpose;
        this.positionMicros = Math.max(0L, positionMicros);
        this.durationMicros = Math.max(0L, durationMicros);
        this.rangeStartMicros = Math.max(0L, rangeStartMicros);
        this.rangeEndMicros = Math.max(this.rangeStartMicros, rangeEndMicros);
        this.speedPercent = speedPercent;
        this.playing = playing;
        invalidate();
    }

    public void setCursor(long positionMicros, boolean playing) {
        this.positionMicros = Math.max(0L, positionMicros);
        this.playing = playing;
        invalidate();
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        final float density = getResources().getDisplayMetrics().density;
        final float w = getWidth();
        final float h = getHeight();
        if (w <= 0 || h <= 0) return;

        paint.setStyle(Paint.Style.FILL);
        paint.setColor(0xdd101820);
        canvas.drawRoundRect(new RectF(0, 0, w, h), 10 * density, 10 * density, paint);

        paint.setColor(0xfff4f6f8);
        paint.setTextSize(11 * density);
        paint.setFakeBoldText(true);
        String shownTitle = title;
        while (paint.measureText(shownTitle) > Math.max(36 * density, w * 0.28f) && shownTitle.length() > 4) {
            shownTitle = shownTitle.substring(0, shownTitle.length() - 2) + "…";
        }
        canvas.drawText(shownTitle, 8 * density, 16 * density, paint);
        paint.setFakeBoldText(false);
        paint.setTextSize(9 * density);
        paint.setColor(0xffcbd5dc);
        canvas.drawText(formatTime(positionMicros) + " / " + formatTime(durationMicros), 8 * density, 30 * density, paint);
        canvas.drawText("练习 " + formatTime(rangeStartMicros) + "–" + formatTime(rangeEndMicros)
                + "  " + (speedPercent / 100f) + "x", 8 * density, 43 * density, paint);

        final float left = Math.min(w - 20 * density, Math.max(88 * density, w * 0.30f));
        final float right = w - 7 * density;
        final float top = 5 * density;
        final float bottom = h - 5 * density;
        final float timelineHeight = bottom - top;
        if (right <= left || timelineHeight <= 0) return;
        final int lanes = 7;
        final float laneHeight = timelineHeight / lanes;
        final float windowMicros = 8_000_000f;
        final float scale = (right - left) / windowMicros;

        for (int lane = 0; lane < lanes; lane++) {
            float y = top + lane * laneHeight;
            paint.setColor(lane % 2 == 0 ? 0x1cffffff : 0x0dffffff);
            canvas.drawRoundRect(new RectF(left, y + 1 * density, right, y + laneHeight - 1 * density),
                    3 * density, 3 * density, paint);
        }

        if (song != null && song.notes != null) {
            long visibleEnd = positionMicros + (long) windowMicros;
            List<MidiParser.NoteEvent> notes = song.notes;
            long visibleStart = Math.max(0L, positionMicros - 500_000L);
            int low = 0, high = notes.size();
            while (low < high) {
                int mid = (low + high) >>> 1;
                if (notes.get(mid).startMicros < visibleStart) low = mid + 1;
                else high = mid;
            }
            for (int i = low; i < notes.size(); i++) {
                MidiParser.NoteEvent note = notes.get(i);
                int pitch = note.pitch + transpose;
                long noteStart = note.startMicros;
                if (noteStart > visibleEnd) break;
                long duration = note.durationMicros > 0 ? note.durationMicros : 260_000L;
                long noteEnd = noteStart + duration;
                if (noteEnd < positionMicros) continue;
                // Keep the roll within the selected practice window, like a segment rehearsal preview.
                if (noteStart < rangeStartMicros || noteStart >= rangeEndMicros) continue;
                long clippedStart = Math.max(noteStart, positionMicros);
                long clippedEnd = Math.min(Math.max(noteEnd, clippedStart + 220_000L), visibleEnd);
                float x1 = left + (clippedStart - positionMicros) * scale;
                float x2 = left + (clippedEnd - positionMicros) * scale;
                x1 = Math.max(left, x1);
                x2 = Math.min(right, Math.max(x1 + 15 * density, x2));
                int lane = pitchClassLane(pitch);
                float y = top + lane * laneHeight + 2 * density;
                float bh = Math.max(7 * density, laneHeight - 4 * density);
                RectF bar = new RectF(x1, y, x2, Math.min(bottom, y + bh));
                paint.setColor(colors[Math.floorMod(pitch, colors.length)]);
                canvas.drawRoundRect(bar, 5 * density, 5 * density, paint);
                if (bar.width() > 20 * density) {
                    paint.setColor(0xff142029);
                    paint.setTextSize(8 * density);
                    paint.setFakeBoldText(true);
                    canvas.drawText(MidiParser.noteName(pitch), x1 + 4 * density,
                            bar.centerY() + 3 * density, paint);
                    paint.setFakeBoldText(false);
                }
            }
        }

        // The playhead is fixed; notes move left as playback time advances.
        paint.setColor(0xfff5f7fa);
        paint.setStrokeWidth(1.5f * density);
        canvas.drawLine(left, top, left, bottom, paint);
        if (playing) postInvalidateDelayed(80L);
    }

    private static int pitchClassLane(int pitch) {
        switch (Math.floorMod(pitch, 12)) {
            case 0: case 1: return 0;  // C
            case 2: case 3: return 1;  // D
            case 4: return 2;         // E
            case 5: case 6: return 3; // F
            case 7: case 8: return 4; // G
            case 9: case 10: return 5;// A
            default: return 6;        // B
        }
    }

    public static String formatTime(long micros) {
        long seconds = Math.max(0L, micros / 1_000_000L);
        long minutes = seconds / 60L;
        return minutes + ":" + (seconds % 60L < 10 ? "0" : "") + (seconds % 60L);
    }
}
