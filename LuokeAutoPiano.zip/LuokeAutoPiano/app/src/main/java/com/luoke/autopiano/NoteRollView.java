package com.luoke.autopiano;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.LinearGradient;
import android.graphics.Shader;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;

import java.util.List;

/** Compact, resizable and seekable MIDI roll overlay. */
public final class NoteRollView extends View {
    public interface InteractionListener {
        void onSeek(long positionMicros);
        void onPracticeRangeChange(long startMicros, long endMicros);
        /** mode is MODE_MOVE or MODE_RESIZE; phase is PHASE_START, PHASE_UPDATE or PHASE_END. */
        void onWindowGesture(int mode, int edges, int dx, int dy, int phase);
        void onClose();
        void onTogglePlayPause();
        void onEditSegment();
    }

    public static final int MODE_MOVE = 1;
    public static final int MODE_RESIZE = 2;
    public static final int PHASE_START = 0;
    public static final int PHASE_UPDATE = 1;
    public static final int PHASE_END = 2;
    public static final int EDGE_LEFT = 1;
    public static final int EDGE_TOP = 2;
    public static final int EDGE_RIGHT = 4;
    public static final int EDGE_BOTTOM = 8;

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final int touchSlop;
    private MidiParser.MidiSong song;
    private String title = "洛克自动琴";
    private int transpose;
    private long positionMicros;
    private long durationMicros;
    private long rangeStartMicros;
    private long rangeEndMicros;
    private int speedPercent = 100;
    private boolean playing;
    private boolean scrubbing;
    private boolean rangeEditing;
    private InteractionListener interactionListener;

    private static final int TOUCH_NONE = 0;
    private static final int TOUCH_SCRUB = 1;
    private static final int TOUCH_MOVE_WINDOW = 2;
    private static final int TOUCH_RESIZE = 3;
    private static final int TOUCH_CLOSE = 4;
    private static final int TOUCH_PLAY_PAUSE = 5;
    private static final int TOUCH_SEGMENT = 6;
    private static final int TOUCH_SEEK_ABSOLUTE = 7;
    private static final int TOUCH_RANGE_EDIT = 8;
    private int touchMode = TOUCH_NONE;
    private int touchEdges;
    private float downX, downY;
    private float downRawX, downRawY;
    private float lastDx;
    private int rangeDragEndpoint;
    private long rangeStartAtDown, rangeEndAtDown;
    private boolean gestureMoved;
    private long positionAtDown;
    private long positionDuringScrub;
    private final int[] colors = {
            0xff72d6ec, 0xff87dfa0, 0xfff28ab3, 0xffffd278,
            0xffa3adff, 0xff7bd8c2, 0xffc0adff, 0xffffad86,
            0xff9cd7fa, 0xffc0e77e, 0xfff1a9d5, 0xffa7d8c8
    };

    public NoteRollView(Context context) {
        super(context);
        touchSlop = ViewConfiguration.get(context).getScaledTouchSlop();
        setLayerType(View.LAYER_TYPE_HARDWARE, null);
        setClickable(true);
    }

    public void setInteractionListener(InteractionListener listener) {
        interactionListener = listener;
    }

    public void setRangeEditing(boolean enabled) {
        rangeEditing = enabled;
        scrubbing = false;
        touchMode = TOUCH_NONE;
        invalidate();
    }

    public boolean isRangeEditing() { return rangeEditing; }

    public void setData(MidiParser.MidiSong song, String title, int transpose,
                        long positionMicros, long durationMicros,
                        long rangeStartMicros, long rangeEndMicros,
                        int speedPercent, boolean playing) {
        this.song = song;
        this.title = title == null || title.trim().isEmpty() ? "洛克自动琴" : title;
        this.transpose = transpose;
        this.durationMicros = Math.max(0L, durationMicros);
        this.rangeStartMicros = Math.max(0L, rangeStartMicros);
        this.rangeEndMicros = Math.max(this.rangeStartMicros, rangeEndMicros);
        if (!scrubbing) this.positionMicros = clamp(positionMicros, this.rangeStartMicros, this.rangeEndMicros);
        this.speedPercent = Math.max(50, Math.min(200, speedPercent));
        this.playing = playing;
        invalidate();
    }

    public void setCursor(long positionMicros, boolean playing) {
        if (!scrubbing) this.positionMicros = clamp(positionMicros, rangeStartMicros, rangeEndMicros);
        this.playing = playing;
        invalidate();
    }

    private static long clamp(long value, long min, long max) {
        return Math.max(min, Math.min(max, value));
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        final float density = getResources().getDisplayMetrics().density;
        final float w = getWidth();
        final float h = getHeight();
        if (w <= 0 || h <= 0) return;

        // Glass-like navy panel with a quiet outline, inspired by the sample's floating player.
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(0xe91a2633);
        canvas.drawRoundRect(new RectF(0, 0, w, h), 12 * density, 12 * density, paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(1 * density);
        paint.setColor(0x7794b4c7);
        canvas.drawRoundRect(new RectF(.5f * density, .5f * density, w - .5f * density, h - .5f * density),
                12 * density, 12 * density, paint);
        paint.setStyle(Paint.Style.FILL);

        // Use the whole usable window for notes. The metadata is painted as a small mask
        // afterward, so upcoming notes can also occupy the formerly empty top-right space.
        final float left = 8 * density;
        final float right = w - 8 * density;
        final float top = 8 * density;
        final float bottom = h - 26 * density;
        final float timelineHeight = bottom - top;
        if (right <= left || timelineHeight <= 0) {
            drawResizeHandle(canvas, w, h, density);
            if (playing) postInvalidateDelayed(80L);
            return;
        }

        // The sheet shows fewer pitch rows in a small window and more as it is enlarged.
        int rowsByWidth = 3 + Math.max(0, (int) ((w / density - 155f) / 34f));
        int rowsByHeight = (int) (timelineHeight / (15 * density));
        final int lanes = Math.max(3, Math.min(9, Math.min(rowsByWidth, Math.max(3, rowsByHeight))));
        final float laneHeight = timelineHeight / lanes;
        // NOTE_ROLL_HEADER_ANCHOR_V1: playhead stays just to the right of the title/time fade.
        final float playheadX = getPlayheadX(w, left, right, density);
        final long windowMicros = visibleWindowMicros(w, left, right, density);
        final float horizontalSpan = Math.max(1f, right - left);
        final long pastMicros = (long) (windowMicros * ((playheadX - left) / horizontalSpan));
        final long futureMicros = (long) (windowMicros * ((right - playheadX) / horizontalSpan));
        final long visibleStart = Math.max(0L, positionMicros - pastMicros);
        final long visibleEnd = Math.min(durationMicros, positionMicros + futureMicros);
        final float scale = horizontalSpan / (float) Math.max(1L, windowMicros);

        for (int lane = 0; lane < lanes; lane++) {
            float y = top + lane * laneHeight;
            paint.setColor(lane % 2 == 0 ? 0x21ffffff : 0x0fffffff);
            canvas.drawRoundRect(new RectF(left, y + .7f * density, right, y + laneHeight - .7f * density),
                    4 * density, 4 * density, paint);
        }

        if (song != null && song.notes != null) {
            List<MidiParser.NoteEvent> notes = song.notes;
            // Include a short look-behind for sustained notes that began just before the window.
            long searchFrom = Math.max(0L, visibleStart - Math.min(8_000_000L, windowMicros / 2L));
            int low = 0, high = notes.size();
            while (low < high) {
                int mid = (low + high) >>> 1;
                if (notes.get(mid).startMicros < searchFrom) low = mid + 1;
                else high = mid;
            }
            for (int i = low; i < notes.size(); i++) {
                MidiParser.NoteEvent note = notes.get(i);
                int pitch = note.pitch + transpose;
                long noteStart = note.startMicros;
                if (noteStart > visibleEnd) break;
                long noteDuration = note.durationMicros > 0 ? note.durationMicros : 260_000L;
                long noteEnd = Math.min(rangeEndMicros, noteStart + noteDuration);
                if (noteEnd < visibleStart) continue;
                if (noteStart < rangeStartMicros || noteStart >= rangeEndMicros) continue;
                float rawX1 = playheadX + (noteStart - positionMicros) * scale;
                float rawX2 = playheadX + (noteEnd - positionMicros) * scale;
                if (rawX2 < left || rawX1 > right) continue;
                float x1 = Math.max(left, rawX1);
                float x2 = Math.min(right, Math.max(x1 + 12 * density, rawX2));
                int lane = pitchLane(pitch, lanes);
                float y = top + lane * laneHeight + 1.5f * density;
                float bh = Math.max(5 * density, laneHeight - 3 * density);
                RectF bar = new RectF(x1, y, x2, Math.min(bottom, y + bh));
                // A note keeps its normal opacity while approaching the playhead. Once its
                // trailing edge passes the line, it fades toward the left edge of the panel.
                float fade = rawX2 >= playheadX ? 1f
                        : Math.max(0f, Math.min(1f, (rawX2 - left) / Math.max(1f, playheadX - left)));
                int noteAlpha = Math.max(0, Math.min(255, Math.round(255f * fade)));
                paint.setColor(colors[Math.floorMod(pitch, colors.length)]);
                paint.setAlpha(noteAlpha);
                canvas.drawRoundRect(bar, 5 * density, 5 * density, paint);
                if (bar.width() > 20 * density && laneHeight > 15 * density && noteAlpha > 12) {
                    paint.setColor(0xff142029);
                    paint.setAlpha(noteAlpha);
                    paint.setTextSize(Math.min(8 * density, laneHeight * .38f));
                    paint.setFakeBoldText(true);
                    canvas.drawText(MidiParser.noteName(pitch), x1 + 4 * density,
                            bar.centerY() + 3 * density, paint);
                    paint.setFakeBoldText(false);
                }
                paint.setAlpha(255);
            }
        }

        // Full-song progress line with the selected practice range highlighted. The strip
        // itself is an absolute seek target; dragging the note field above it is a gentle pan.
        float progressY = h - 21 * density;
        float progressRight = w - 8 * density;
        float barHeight = 3 * density;
        paint.setColor(0x665c7b90);
        canvas.drawRoundRect(new RectF(left, progressY, progressRight, progressY + barHeight),
                2 * density, 2 * density, paint);
        if (durationMicros > 0) {
            float rangeStartX = left + (progressRight - left) * Math.max(0f, Math.min(1f,
                    rangeStartMicros / (float) durationMicros));
            float rangeEndX = left + (progressRight - left) * Math.max(0f, Math.min(1f,
                    rangeEndMicros / (float) durationMicros));
            paint.setColor(0xaa65dfb0);
            canvas.drawRoundRect(new RectF(rangeStartX, progressY - density, Math.max(rangeStartX + density, rangeEndX),
                    progressY + barHeight + density), 2 * density, 2 * density, paint);
            float progress = Math.max(0f, Math.min(1f, positionMicros / (float) durationMicros));
            float cursorX = left + (progressRight - left) * progress;
            paint.setColor(0xfff7fbff);
            paint.setStrokeWidth(2 * density);
            canvas.drawLine(cursorX, progressY - 3 * density, cursorX, progressY + barHeight + 3 * density, paint);
            paint.setStrokeWidth(1 * density);
            float startHandleX = left + (progressRight - left) * rangeStartMicros / (float) Math.max(1L, durationMicros);
            float endHandleX = left + (progressRight - left) * rangeEndMicros / (float) Math.max(1L, durationMicros);
            paint.setColor(rangeEditing ? 0xffffd278 : 0xaa65dfb0);
            canvas.drawCircle(startHandleX, progressY + barHeight / 2f, (rangeEditing ? 5.5f : 2.6f) * density, paint);
            paint.setColor(rangeEditing ? 0xffff91b8 : 0xaa65dfb0);
            canvas.drawCircle(endHandleX, progressY + barHeight / 2f, (rangeEditing ? 5.5f : 2.6f) * density, paint);
            if (rangeEditing) {
                paint.setTextSize(7.5f * density);
                paint.setFakeBoldText(true);
                paint.setColor(0xffffd278);
                canvas.drawText("起", Math.max(left, Math.min(progressRight - 8 * density, startHandleX - 3 * density)), progressY - 3 * density, paint);
                paint.setColor(0xffff91b8);
                canvas.drawText("止", Math.max(left, Math.min(progressRight - 8 * density, endHandleX - 3 * density)), progressY - 3 * density, paint);
                paint.setFakeBoldText(false);
            }
        }

        // This playhead stays at the leading edge while the notes scroll past it.
        paint.setColor(0xfff7fbff);
        paint.setStrokeWidth(1.5f * density);
        canvas.drawLine(playheadX, top, playheadX, bottom + 1 * density, paint);
        paint.setStrokeWidth(1 * density);

        if (scrubbing) {
            paint.setColor(0xee65dfb0);
            paint.setStyle(Paint.Style.STROKE);
            canvas.drawRoundRect(new RectF(1.5f * density, 1.5f * density, w - 1.5f * density, h - 1.5f * density),
                    11 * density, 11 * density, paint);
            paint.setStyle(Paint.Style.FILL);
        }
        drawHeaderOverlay(canvas, w, h, density);
        drawResizeHandle(canvas, w, h, density);
        if (playing) postInvalidateDelayed(80L);
    }

    private void drawHeaderOverlay(Canvas canvas, float w, float h, float density) {
        // Title/time use the same navy as the sheet. A soft alpha veil and a text fade
        // replace the separate rounded card that used to sit on top of the notes.
        float fadeEnd = Math.max(30 * density, Math.min(w - 72 * density, w * .50f));
        fadeEnd = Math.min(w - 72 * density, fadeEnd);
        if (fadeEnd < 24 * density) fadeEnd = Math.max(24 * density, w * .48f);
        float fadeStart = Math.max(10 * density, fadeEnd * .54f);
        float headerBottom = Math.min(h - 18 * density, 47 * density);

        paint.setStyle(Paint.Style.FILL);
        paint.setShader(new LinearGradient(0, 0, fadeEnd, 0,
                new int[]{0xe91a2633, 0xe91a2633, 0x001a2633},
                new float[]{0f, .52f, 1f}, Shader.TileMode.CLAMP));
        canvas.drawRect(0, 0, fadeEnd, headerBottom, paint);
        paint.setShader(null);

        int layer = canvas.saveLayer(0, 0, fadeEnd, headerBottom, null);
        float textMax = Math.max(16 * density, fadeEnd - 12 * density);
        paint.setColor(0xfff7f9fc);
        paint.setTextSize(10.5f * density);
        paint.setFakeBoldText(true);
        String shownTitle = ellipsize(title, textMax, paint);
        canvas.drawText(shownTitle, 8 * density, 16 * density, paint);
        paint.setFakeBoldText(false);
        paint.setTextSize(8.5f * density);
        paint.setColor(0xffcbd8e1);
        String timeLine = ellipsize(formatTime(positionMicros) + " / " + formatTime(durationMicros), textMax, paint);
        canvas.drawText(timeLine, 8 * density, 29 * density, paint);
        String rangeLine = "练习 " + formatTime(rangeStartMicros) + "–" + formatTime(rangeEndMicros)
                + "  " + (speedPercent / 100f) + "x";
        rangeLine = ellipsize(rangeLine, textMax, paint);
        canvas.drawText(rangeLine, 8 * density, 42 * density, paint);

        Paint fadeMask = new Paint(Paint.ANTI_ALIAS_FLAG);
        fadeMask.setShader(new LinearGradient(fadeStart, 0, fadeEnd, 0,
                new int[]{Color.WHITE, Color.WHITE, 0x00ffffff},
                new float[]{0f, .48f, 1f}, Shader.TileMode.CLAMP));
        fadeMask.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_IN));
        canvas.drawRect(0, 0, fadeEnd, headerBottom, fadeMask);
        fadeMask.setXfermode(null);
        fadeMask.setShader(null);
        canvas.restoreToCount(layer);

        float buttonTop = 5 * density;
        float buttonBottom = Math.min(25 * density, h - 4 * density);
        drawHeaderChip(canvas, new RectF(w - 89 * density, buttonTop, w - 64 * density, buttonBottom),
                playing ? "Ⅱ" : "▶", playing ? 0xff4c8d80 : 0xff455667, density);
        drawHeaderChip(canvas, new RectF(w - 61 * density, buttonTop, w - 35 * density, buttonBottom),
                rangeEditing ? "选" : "段", rangeEditing ? 0xff4c8d80 : 0xff455667, density);
        // A dedicated close chip stays visually and interactively separate from the segment chip.
        drawHeaderChip(canvas, new RectF(w - 32 * density, buttonTop, w - 6 * density, buttonBottom),
                "×", 0xff455667, density);
    }

    private String ellipsize(String text, float maxWidth, Paint p) {
        String result = text == null ? "" : text;
        if (p.measureText(result) <= maxWidth) return result;
        while (result.length() > 1 && p.measureText(result + "…") > maxWidth) {
            result = result.substring(0, result.length() - 1);
        }
        return result.isEmpty() ? "" : result + "…";
    }

    private void drawHeaderChip(Canvas canvas, RectF rect, String label, int color, float density) {
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(0xd9354654);
        canvas.drawRoundRect(rect, 5 * density, 5 * density, paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(1 * density);
        paint.setColor(0x889bb1c1);
        canvas.drawRoundRect(rect, 5 * density, 5 * density, paint);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(color);
        paint.setTextSize(9 * density);
        paint.setFakeBoldText(true);
        float tw = paint.measureText(label);
        canvas.drawText(label, rect.centerX() - tw / 2, rect.centerY() + 3.2f * density, paint);
        paint.setFakeBoldText(false);
    }

    private void drawResizeHandle(Canvas canvas, float w, float h, float density) {
        paint.setColor(0x88d4e6f2);
        paint.setStrokeWidth(1.5f * density);
        for (int i = 0; i < 3; i++) {
            float inset = (4 + i * 4) * density;
            canvas.drawLine(w - inset - 7 * density, h - 3 * density,
                    w - 3 * density, h - inset - 7 * density, paint);
        }
        paint.setStrokeWidth(1 * density);
    }

    private static float getPlayheadX(float width, float left, float right, float density) {
        float desired = width * .54f;
        float minimum = left + 34 * density;
        return Math.max(minimum, Math.min(right - 28 * density, desired));
    }

    private static long visibleWindowMicros(float width, float left, float right, float density) {
        float usableDp = Math.max(80f, (right - left) / density);
        // Narrow windows focus more tightly; enlarged windows show more upcoming music.
        return (long) (Math.max(4.0f, Math.min(16.0f, usableDp / 36.0f)) * 1_000_000L);
    }

    private static int pitchLane(int pitch, int laneCount) {
        return Math.min(laneCount - 1, Math.floorMod(pitch, 12) * laneCount / 12);
    }

    @Override public boolean onTouchEvent(MotionEvent event) {
        final float density = getResources().getDisplayMetrics().density;
        final float x = event.getX(), y = event.getY();
        final float w = getWidth(), h = getHeight();
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN: {
                downX = x; downY = y;
                downRawX = event.getRawX(); downRawY = event.getRawY();
                lastDx = x;
                gestureMoved = false;
                positionAtDown = positionMicros;
                positionDuringScrub = positionMicros;
                rangeStartAtDown = rangeStartMicros;
                rangeEndAtDown = rangeEndMicros;
                touchEdges = detectEdges(x, y, w, h, 10 * density);
                if (y < 34 * density && x > w - 34 * density) {
                    touchMode = TOUCH_CLOSE;
                } else if (y < 34 * density && x > w - 63 * density) {
                    touchMode = TOUCH_SEGMENT;
                } else if (y < 34 * density && x > w - 91 * density) {
                    touchMode = TOUCH_PLAY_PAUSE;
                } else if (touchEdges != 0) {
                    touchMode = TOUCH_RESIZE;
                    notifyWindowGesture(MODE_RESIZE, touchEdges, 0, 0, PHASE_START);
                } else if (rangeEditing && y >= 47 * density) {
                    touchMode = TOUCH_RANGE_EDIT;
                    rangeDragEndpoint = endpointForX(x, density);
                } else if (y >= h - 24 * density && y <= h - 12 * density) {
                    // The narrow strip is the precise progress target; the notes above it remain a gentle scrub surface.
                    touchMode = TOUCH_SEEK_ABSOLUTE;
                    scrubbing = true;
                    positionDuringScrub = absoluteSeekAt(x, density);
                    positionMicros = positionDuringScrub;
                    invalidate();
                } else if (y < 47 * density && x < Math.max(38 * density, w * .48f)) {
                    touchMode = TOUCH_MOVE_WINDOW;
                    notifyWindowGesture(MODE_MOVE, 0, 0, 0, PHASE_START);
                } else {
                    touchMode = TOUCH_SCRUB;
                    scrubbing = false;
                }
                return true;
            }
            case MotionEvent.ACTION_MOVE: {
                float dx = x - downX;
                float dy = y - downY;
                float rawDx = event.getRawX() - downRawX;
                float rawDy = event.getRawY() - downRawY;
                if (Math.abs(rawDx) + Math.abs(rawDy) > touchSlop) gestureMoved = true;
                if (touchMode == TOUCH_MOVE_WINDOW) {
                    notifyWindowGesture(MODE_MOVE, 0, Math.round(rawDx), Math.round(rawDy), PHASE_UPDATE);
                } else if (touchMode == TOUCH_RESIZE) {
                    notifyWindowGesture(MODE_RESIZE, touchEdges, Math.round(rawDx), Math.round(rawDy), PHASE_UPDATE);
                } else if (touchMode == TOUCH_RANGE_EDIT) {
                    if (Math.abs(rawDx) > touchSlop) {
                        long target = songPositionAtX(x, density);
                        updateRangeEndpoint(target);
                        scrubbing = true;
                        invalidate();
                    }
                } else if (touchMode == TOUCH_SEEK_ABSOLUTE) {
                    positionDuringScrub = absoluteSeekAt(x, density);
                    positionMicros = positionDuringScrub;
                    invalidate();
                } else if (touchMode == TOUCH_SCRUB && Math.abs(dx) > touchSlop
                        && Math.abs(dx) > Math.abs(dy) * .85f) {
                    scrubbing = true;
                    long window = visibleWindowMicros(w, 8 * density, w - 8 * density, density);
                    // A single swipe pans only a small fraction of the visible window, preventing accidental jumps to song end.
                    long delta = Math.round((-dx / Math.max(1f, w)) * Math.min(1_000_000L, window * .16f));
                    long safeEnd = safeScrubEnd();
                    positionDuringScrub = clamp(positionAtDown + delta, rangeStartMicros, safeEnd);
                    positionMicros = positionDuringScrub;
                    lastDx = x;
                    invalidate();
                }
                return true;
            }
            case MotionEvent.ACTION_UP: {
                float dx = event.getRawX() - downRawX;
                float dy = event.getRawY() - downRawY;
                if (touchMode == TOUCH_CLOSE && !gestureMoved) {
                    if (interactionListener != null) interactionListener.onClose();
                } else if (touchMode == TOUCH_PLAY_PAUSE && !gestureMoved) {
                    if (interactionListener != null) interactionListener.onTogglePlayPause();
                } else if (touchMode == TOUCH_SEGMENT && !gestureMoved) {
                    if (interactionListener != null) interactionListener.onEditSegment();
                } else if (touchMode == TOUCH_RANGE_EDIT) {
                    if (gestureMoved && interactionListener != null) {
                        interactionListener.onPracticeRangeChange(rangeStartMicros, rangeEndMicros);
                    } else {
                        rangeStartMicros = rangeStartAtDown;
                        rangeEndMicros = rangeEndAtDown;
                    }
                    scrubbing = false;
                    invalidate();
                } else if ((touchMode == TOUCH_SCRUB && scrubbing) || touchMode == TOUCH_SEEK_ABSOLUTE) {
                    positionMicros = positionDuringScrub;
                    if (interactionListener != null) interactionListener.onSeek(positionMicros);
                    scrubbing = false;
                    invalidate();
                } else if (touchMode == TOUCH_MOVE_WINDOW) {
                    notifyWindowGesture(MODE_MOVE, 0, Math.round(dx), Math.round(dy), PHASE_END);
                } else if (touchMode == TOUCH_RESIZE) {
                    notifyWindowGesture(MODE_RESIZE, touchEdges, Math.round(dx), Math.round(dy), PHASE_END);
                }
                touchMode = TOUCH_NONE;
                performClick();
                return true;
            }
            case MotionEvent.ACTION_CANCEL:
                if (touchMode == TOUCH_MOVE_WINDOW)
                    notifyWindowGesture(MODE_MOVE, 0, Math.round(event.getRawX() - downRawX), Math.round(event.getRawY() - downRawY), PHASE_END);
                else if (touchMode == TOUCH_RESIZE)
                    notifyWindowGesture(MODE_RESIZE, touchEdges, Math.round(event.getRawX() - downRawX), Math.round(event.getRawY() - downRawY), PHASE_END);
                else if (touchMode == TOUCH_RANGE_EDIT) {
                    rangeStartMicros = rangeStartAtDown;
                    rangeEndMicros = rangeEndAtDown;
                }
                scrubbing = false;
                touchMode = TOUCH_NONE;
                invalidate();
                return true;
        }
        return true;
    }

    private int endpointForX(float x, float density) {
        float left = 8 * density;
        float right = getWidth() - 8 * density;
        float fraction = Math.max(0f, Math.min(1f, (x - left) / Math.max(1f, right - left)));
        float startFraction = rangeStartMicros / (float) Math.max(1L, durationMicros);
        float endFraction = rangeEndMicros / (float) Math.max(1L, durationMicros);
        return Math.abs(fraction - startFraction) <= Math.abs(fraction - endFraction) ? 1 : 2;
    }

    private void updateRangeEndpoint(long target) {
        long duration = Math.max(1L, durationMicros);
        long minGap = Math.min(duration, Math.min(500_000L, Math.max(30_000L, duration / 2000L)));
        target = clamp(target, 0L, duration);
        if (rangeDragEndpoint == 1) {
            rangeStartMicros = Math.max(0L, Math.min(target, rangeEndMicros - minGap));
        } else {
            rangeEndMicros = Math.min(duration, Math.max(target, rangeStartMicros + minGap));
        }
        rangeStartMicros = Math.max(0L, Math.min(rangeStartMicros, duration - minGap));
        rangeEndMicros = Math.max(rangeStartMicros + minGap, Math.min(duration, rangeEndMicros));
    }

    private long absoluteSeekAt(float x, float density) {
        float left = 8 * density;
        float right = getWidth() - 8 * density;
        float fraction = Math.max(0f, Math.min(1f, (x - left) / Math.max(1f, right - left)));
        long start = Math.max(0L, rangeStartMicros);
        long end = Math.max(start, rangeEndMicros);
        return start + Math.round((end - start) * fraction);
    }

    private long songPositionAtX(float x, float density) {
        float left = 8 * density;
        float right = getWidth() - 8 * density;
        float fraction = Math.max(0f, Math.min(1f, (x - left) / Math.max(1f, right - left)));
        return Math.round(Math.max(0L, durationMicros) * fraction);
    }

    private long safeScrubEnd() {
        long span = Math.max(0L, rangeEndMicros - rangeStartMicros);
        long margin = Math.min(500_000L, Math.max(30_000L, span / 200L));
        return Math.max(rangeStartMicros, rangeEndMicros - margin);
    }

    @Override public boolean performClick() {
        super.performClick();
        return true;
    }

    private void notifyWindowGesture(int mode, int edges, int dx, int dy, int phase) {
        if (interactionListener != null) interactionListener.onWindowGesture(mode, edges, dx, dy, phase);
    }

    private static int detectEdges(float x, float y, float w, float h, float edge) {
        int result = 0;
        if (x <= edge) result |= EDGE_LEFT;
        if (x >= w - edge) result |= EDGE_RIGHT;
        if (y <= edge) result |= EDGE_TOP;
        if (y >= h - edge) result |= EDGE_BOTTOM;
        return result;
    }

    public static String formatTime(long micros) {
        long seconds = Math.max(0L, micros / 1_000_000L);
        long minutes = seconds / 60L;
        return minutes + ":" + (seconds % 60L < 10 ? "0" : "") + (seconds % 60L);
    }
}
