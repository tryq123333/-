package com.luoke.autopiano;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.BitmapFactory;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.LinearGradient;
import android.graphics.Shader;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;

import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Compact resizable and seekable MIDI roll with icon-anchored controls. ICON_ANCHORED_HEADER_V3 AB_LOOP_FADE_BRAND_RESET_V3 NOTE_HEADER_INFO_V2 AB_LOOP_SETTINGS_V1 NOTE_ROLL_PLAY_REWIND_SEEK_GUARD_V1 SONG_SPECIFIC_ROLL_UI_V2 ROLL_SINGLE_PERFORMANCE_REAL_ICONS_FADE_V3 ROLL_SEEK_ICON_STABILITY_V4 ROLL_FINAL_CONTROLS_SEEK_LAUNCHER_V6 ROLL_REWIND_NEXT_TO_AB_V7 ROLL_SPEED_CONTROL_AND_SONG_REMOVAL_V1 ROLL_REFERENCE_ICON_ANIMATION_V5 ROLL_BOTTOM_TIME_AND_SUBTLE_FRAME_V1 ROLL_PRACTICE_GATE_AND_KEY_GUIDE_V10 PRACTICE_VISUAL_MAPPING_WAIT_QUEUE_V12 PRACTICE_OCTAVE_DOT_KEYMAP_V13 PRACTICE_ROLL_PLAYHEAD_RING_BUTTON_SWAP_V14 */
public final class NoteRollView extends View {
    public interface InteractionListener {
        void onSeek(long positionMicros);
        void onPracticeRangeChange(long startMicros, long endMicros);
        /** mode is MODE_MOVE or MODE_RESIZE; phase is PHASE_START, PHASE_UPDATE or PHASE_END. */
        void onWindowGesture(int mode, int edges, int dx, int dy, int phase);
        void onClose();
        void onTogglePlayPause();
        void onRewind();
        void onBeginSeekGesture();
        void onEndSeekGesture();
        void onEditSegment();
        void onToggleAbLoop();
        void onSpeedChange(int speedPercent);
        void onTogglePracticeMode();
    }

    public static final int MODE_MOVE = 1;
    public static final int MODE_RESIZE = 2;
    public static final int PHASE_START = 0;
    public static final int PHASE_UPDATE = 1;
    public static final int PHASE_END = 2;
    public static final int EDGE_LEFT = 1;
    public static final int EDGE_TOP = 2;
    public static final int EDGE_RIGHT = 4;
    public static final int EDGE_BOTTOM = 8;

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Bitmap gameKeyAtlas;
    private final int touchSlop;
    private MidiParser.MidiSong song;
    private String title = "奏乐";
    private int transpose;
    private long positionMicros;
    private long durationMicros;
    private long rangeStartMicros;
    private long rangeEndMicros;
    private int speedPercent = 100;
    private int speedAtDown = 100;
    private boolean playing;
    private boolean scrubbing;
    private boolean rangeEditing;
    private boolean abLoopEnabled;
    private boolean practiceModeEnabled;
    private boolean practiceWaiting;
    private Set<Integer> practiceGroupPitches = Collections.emptySet();
    private Set<Integer> practiceWaitingPitches = Collections.emptySet();
    private long segmentDownTimeMs;
    private InteractionListener interactionListener;

    private static final int TOUCH_NONE = 0;
    private static final int TOUCH_SCRUB = 1;
    private static final int TOUCH_MOVE_WINDOW = 2;
    private static final int TOUCH_RESIZE = 3;
    private static final int TOUCH_CLOSE = 4;
    private static final int TOUCH_PLAY_PAUSE = 5;
    private static final int TOUCH_SEGMENT = 6;
    private static final int TOUCH_SEEK_ABSOLUTE = 7;
    private static final int TOUCH_RANGE_EDIT = 8;
    private static final int TOUCH_REWIND = 9;
    private static final int TOUCH_SPEED = 10;
    private static final int TOUCH_PRACTICE = 11;
    private boolean absoluteSeekMoved;
    private boolean windowGestureStarted;
    private boolean seekGestureStarted;
    private boolean useGameKeyIcons = true;
    private int touchMode = TOUCH_NONE;
    private int touchEdges;
    private float downX, downY;
    private float downRawX, downRawY;
    private float lastDx;
    private int rangeDragEndpoint;
    private long rangeStartAtDown, rangeEndAtDown;
    private boolean gestureMoved;
    private long positionAtDown;
    private long positionDuringScrub;
    private final int[] colors = {
            0xff72d6ec, 0xff87dfa0, 0xfff28ab3, 0xffffd278,
            0xffa3adff, 0xff7bd8c2, 0xffc0adff, 0xffffad86,
            0xff9cd7fa, 0xffc0e77e, 0xfff1a9d5, 0xffa7d8c8
    };

    public NoteRollView(Context context) {
        super(context);
        touchSlop = ViewConfiguration.get(context).getScaledTouchSlop();
        gameKeyAtlas = BitmapFactory.decodeResource(getResources(), R.drawable.note_key_atlas);
        setLayerType(View.LAYER_TYPE_HARDWARE, null);
        setClickable(true);
    }

    public void setInteractionListener(InteractionListener listener) {
        interactionListener = listener;
    }

    public void setRangeEditing(boolean enabled) {
        rangeEditing = enabled;
        scrubbing = false;
        touchMode = TOUCH_NONE;
        invalidate();
    }

    public boolean isRangeEditing() { return rangeEditing; }

    public void setAbLoopEnabled(boolean enabled) {
        abLoopEnabled = enabled;
        invalidate();
    }

    public void setPracticeModeEnabled(boolean enabled) {
        practiceModeEnabled = enabled;
        invalidate();
    }

    public boolean isPracticeModeEnabled() { return practiceModeEnabled; }

    public void setPracticeWaitState(Set<Integer> groupPitches, Set<Integer> waitingPitches, boolean waiting) {
        practiceWaiting = waiting;
        practiceGroupPitches = groupPitches == null || groupPitches.isEmpty()
                ? Collections.emptySet() : new HashSet<>(groupPitches);
        practiceWaitingPitches = waitingPitches == null || waitingPitches.isEmpty()
                ? Collections.emptySet() : new HashSet<>(waitingPitches);
        invalidate();
    }

    public void setData(MidiParser.MidiSong song, String title, int transpose,
                        long positionMicros, long durationMicros,
                        long rangeStartMicros, long rangeEndMicros,
                        int speedPercent, boolean playing) {
        this.song = song;
        this.title = title == null || title.trim().isEmpty() ? "奏乐" : title;
        this.transpose = transpose;
        this.durationMicros = Math.max(0L, durationMicros);
        this.rangeStartMicros = Math.max(0L, rangeStartMicros);
        this.rangeEndMicros = Math.max(this.rangeStartMicros, rangeEndMicros);
        if (!scrubbing) this.positionMicros = clamp(positionMicros, seekRangeStart(), seekRangeEnd());
        this.speedPercent = Math.max(50, Math.min(200, speedPercent));
        this.playing = playing;
        useGameKeyIcons = !InstrumentLayout.MODE_PIANO88.equals(
                getContext().getSharedPreferences(MainActivity.PREFS, Context.MODE_PRIVATE)
                        .getString(InstrumentLayout.KEY_LAYOUT_MODE, InstrumentLayout.MODE_NINE));
        invalidate();
    }

    public void setCursor(long positionMicros, boolean playing) {
        if (!scrubbing) this.positionMicros = clamp(positionMicros, seekRangeStart(), seekRangeEnd());
        this.playing = playing;
        invalidate();
    }

    private static long clamp(long value, long min, long max) {
        return Math.max(min, Math.min(max, value));
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        final float density = getResources().getDisplayMetrics().density;
        final float w = getWidth();
        final float h = getHeight();
        if (w <= 0 || h <= 0) return;

        // FLOATING_NOTE_LABELS_V2: transparent sheet; note blocks float directly over the game.

        // UPPER_RIGHT_NOTE_SPACE_V2: use the transparent upper-right area for moving note blocks.
        // Keep the title/control side clear while notes flow through the right-hand space.
        final float left = 8 * density;
        final float right = w - 8 * density;
        final float top = 3 * density;
        final float bottom = h - 26 * density;
        final float timelineHeight = bottom - top;
        if (right <= left || timelineHeight <= 0) {
            drawResizeHandle(canvas, w, h, density);
            drawSubtleWindowBorder(canvas, w, h, density);
            if (playing) postInvalidateDelayed(80L);
            return;
        }

        // The sheet shows fewer pitch rows in a small window and more as it is enlarged.
        int rowsByWidth = 3 + Math.max(0, (int) ((w / density - 155f) / 34f));
        int rowsByHeight = (int) (timelineHeight / (15 * density));
        final int lanes = Math.max(3, Math.min(9, Math.min(rowsByWidth, Math.max(3, rowsByHeight))));
        final float laneHeight = timelineHeight / lanes;
        // NOTE_ROLL_HEADER_ANCHOR_V1: playhead stays just to the right of the title/time fade.
        final float playheadX = getPlayheadX(w, left, right, density);
        final long windowMicros = visibleWindowMicros(w, left, right, density);
        final float horizontalSpan = Math.max(1f, right - left);
        final long pastMicros = (long) (windowMicros * ((playheadX - left) / horizontalSpan));
        final long futureMicros = (long) (windowMicros * ((right - playheadX) / horizontalSpan));
        final long visibleStart = Math.max(0L, positionMicros - pastMicros);
        final long visibleEnd = Math.min(durationMicros, positionMicros + futureMicros);
        final float scale = horizontalSpan / (float) Math.max(1L, windowMicros);

        // No per-lane background strips; a single transparent surface keeps the visual clean.

        // Do not let note badges clutter the close/play/title/time/segment controls on the left.
        if (song != null && song.notes != null) {
            List<MidiParser.NoteEvent> notes = song.notes;
            // Include a short look-behind for sustained notes that began just before the window.
            long searchFrom = Math.max(0L, visibleStart - Math.min(8_000_000L, windowMicros / 2L));
            int low = 0, high = notes.size();
            while (low < high) {
                int mid = (low + high) >>> 1;
                if (notes.get(mid).startMicros < searchFrom) low = mid + 1;
                else high = mid;
            }
            for (int i = low; i < notes.size(); i++) {
                MidiParser.NoteEvent note = notes.get(i);
                int pitch = note.pitch + transpose;
                long noteStart = note.startMicros;
                if (noteStart > visibleEnd) break;
                long noteDuration = note.durationMicros > 0 ? note.durationMicros : 260_000L;
                long noteEnd = Math.min(rangeEndMicros, noteStart + noteDuration);
                if (noteEnd < visibleStart) continue;
                if (noteStart < rangeStartMicros || noteStart >= rangeEndMicros) continue;
                float rawX1 = playheadX + (noteStart - positionMicros) * scale;
                float rawX2 = playheadX + (noteEnd - positionMicros) * scale;
                if (rawX2 < left || !NoteRollGestureMath.pastEntranceBuffer(rawX1, right, density)) continue;
                float x1 = Math.max(left, rawX1);
                int lane = pitchLane(pitch, lanes);
                float y = top + lane * laneHeight + 1.5f * density;
                float bh = Math.max(5 * density, laneHeight - 3 * density);
                String noteLabel = MidiParser.noteName(pitch);
                int keyIconIndex = InstrumentLayout.indexOfPitch(pitch);
                int keyIconCell = InstrumentLayout.gameKeyAtlasCellForPitch(pitch);
                boolean practiceGroupNote = practiceWaiting && practiceGroupPitches.contains(pitch)
                        && Math.abs(noteStart - positionMicros) <= 10_000L;
                boolean practiceNeedsTap = practiceWaitingPitches.contains(pitch);
                // Give the same playhead medallion in normal playback; practice mode simply holds it there.
                boolean normalPlayheadNote = practiceModeEnabled && playing && Math.abs(noteStart - positionMicros) <= 70_000L; // PRACTICE_NORMAL_PLAYHEAD_RING_ONLY_IN_PRACTICE_V15
                boolean playheadFocusNote = practiceGroupNote || normalPlayheadNote;
                paint.setTextSize(Math.max(6.8f * density, Math.min(8.2f * density, laneHeight * .48f)));
                paint.setFakeBoldText(true);
                float labelTextWidth = paint.measureText(noteLabel);
                float badgeWidth = useGameKeyIcons && keyIconIndex >= 0
                        ? 20 * density : labelTextWidth + 9 * density;
                float minBlockWidth = Math.max(25 * density, badgeWidth + 4 * density);
                if (practiceModeEnabled && useGameKeyIcons && keyIconIndex >= 0) {
                    minBlockWidth = Math.max(minBlockWidth, 36 * density);
                }
                float x2 = Math.min(right, Math.max(x1 + minBlockWidth, rawX2));
                RectF bar = new RectF(x1, y, x2, Math.min(bottom, y + bh));
                // NOTE_ENTRY_FADE_IN_V1: fade in from the right edge while playing; keep
                // the existing opposite fade-out as notes pass the playhead to the left.
                float fadeOut = rawX2 >= playheadX ? 1f
                        : Math.max(0f, Math.min(1f, (rawX2 - left) / Math.max(1f, playheadX - left)));
                float fadeIn = 1f;
                if (playing) {
                    fadeIn = NoteRollGestureMath.enteringNoteFadeIn(rawX1, right, density);
                }
                int noteAlpha = Math.max(0, Math.min(255,
                        Math.round(255f * fadeOut * fadeIn)));
                if (practiceGroupNote && !practiceNeedsTap) noteAlpha = Math.round(noteAlpha * 0.42f);
                if (noteAlpha > 0) {
                    paint.setStyle(Paint.Style.FILL);
                    paint.setColor(colors[Math.floorMod(pitch, colors.length)]);
                    paint.setAlpha(noteAlpha);
                    canvas.drawRoundRect(bar, 6 * density, 6 * density, paint);

                    // Nine-note handpan uses the same pictograms as the in-game keys.
                    // The 88-key piano mode keeps conventional pitch labels.
                    float availableBadgeWidth = Math.min(badgeWidth, Math.max(10 * density, right - left));
                    float badgeHeight = Math.max(9 * density, Math.min(bar.height() - 2 * density, 18 * density));
                    float badgeLeft = Math.max(left, Math.min(bar.left + 2 * density, right - availableBadgeWidth));
                    RectF badge = new RectF(badgeLeft, bar.centerY() - badgeHeight / 2f,
                            badgeLeft + availableBadgeWidth, bar.centerY() + badgeHeight / 2f);
                    if (useGameKeyIcons && keyIconIndex >= 0) {
                        float iconInset = 2.5f * density;
                        float iconSize = playheadFocusNote ? 20 * density : Math.min(18 * density,
                                Math.max(0f, Math.min(bar.height() - 4 * density, badgeHeight - density)));
                        // Stage the entrance: show a clearly visible colored note block first,
                        // then fade its full in-game key medallion in over a few dp of travel.
                        float reveal = (right - bar.left - iconSize - 2 * iconInset)
                                / Math.max(1f, 5 * density);
                        boolean blockReady = playheadFocusNote
                                || (iconSize >= 8 * density
                                && bar.width() >= iconSize + 2 * iconInset + density
                                && bar.left <= right - iconSize - 2 * iconInset);
                        if (blockReady && reveal > 0f) {
                            float iconCx = playheadFocusNote ? playheadX : bar.left + iconInset + iconSize / 2f;
                            if (!playheadFocusNote) iconCx = Math.min(bar.right - iconInset - iconSize / 2f, iconCx);
                            int revealAlpha = playheadFocusNote ? noteAlpha
                                    : Math.round(noteAlpha * Math.min(1f, reveal));
                            if (revealAlpha > 0) {
                                if (playheadFocusNote) {
                                    // Low-opacity ring in ordinary playback; stronger fill while a practice tap is pending.
                                    paint.setStyle(Paint.Style.FILL);
                                    paint.setColor(practiceNeedsTap ? 0x9f48e69e : 0x6048e69e);
                                    canvas.drawCircle(playheadX, badge.centerY(), iconSize * 0.68f, paint);
                                    paint.setStyle(Paint.Style.STROKE);
                                    paint.setStrokeWidth((practiceNeedsTap ? 1.8f : 1.2f) * density);
                                    paint.setColor(practiceNeedsTap ? 0xc9a4ffce : 0x6848e69e);
                                    canvas.drawCircle(playheadX, badge.centerY(), iconSize * 0.82f, paint);
                                    paint.setStyle(Paint.Style.FILL);
                                    paint.setStrokeWidth(1f * density);
                                }
                                drawOriginalGameKeyIcon(canvas, iconCx, badge.centerY(),
                                        iconSize, keyIconCell, revealAlpha);
                                if (practiceModeEnabled) {
                                    paint.setStyle(Paint.Style.FILL);
                                    paint.setAlpha(Math.min(245, noteAlpha));
                                    paint.setColor(practiceGroupNote && practiceNeedsTap ? 0xfff0fff5
                                            : 0xffc5f2d8);
                                    paint.setTextSize(Math.max(6.2f * density, Math.min(7.4f * density, laneHeight * 0.42f)));
                                    paint.setFakeBoldText(true);
                                    float noteNameX = iconCx + iconSize / 2f + 1.5f * density;
                                    float noteNameY = badge.centerY() - (paint.ascent() + paint.descent()) / 2f;
                                    if (noteNameX + paint.measureText(noteLabel) <= bar.right - density) {
                                        canvas.drawText(noteLabel, noteNameX, noteNameY, paint);
                                    }
                                    paint.setFakeBoldText(false);
                                    paint.setAlpha(255);
                                }
                            }
                        }
                    } else {
                        paint.setColor(0xfff4f6f4);
                        paint.setAlpha(Math.min(245, noteAlpha));
                        canvas.drawRoundRect(badge, badgeHeight / 2f, badgeHeight / 2f, paint);
                        paint.setColor(0xff1d3039);
                        paint.setAlpha(noteAlpha);
                        paint.setTextSize(Math.max(6.5f * density, Math.min(8.2f * density, badgeHeight * .60f)));
                        paint.setFakeBoldText(true);
                        float actualTextWidth = paint.measureText(noteLabel);
                        float textX = badge.centerX() - actualTextWidth / 2f;
                        float textY = badge.centerY() - (paint.ascent() + paint.descent()) / 2f;
                        canvas.drawText(noteLabel, textX, textY, paint);
                    }
                }
                paint.setFakeBoldText(false);
                paint.setAlpha(255);
            }
        }


        // Full-song progress line with the selected practice range highlighted. The strip
        // itself is an absolute seek target; dragging the note field above it is a gentle pan.
        float progressY = h - 15 * density;
        float progressRight = w - 8 * density;
        float barHeight = 3 * density;
        paint.setColor(0x1c5c7b90);
        canvas.drawRoundRect(new RectF(left, progressY, progressRight, progressY + barHeight),
                2 * density, 2 * density, paint);
        if (durationMicros > 0) {
            float rangeStartX = left + (progressRight - left) * Math.max(0f, Math.min(1f,
                    rangeStartMicros / (float) durationMicros));
            float rangeEndX = left + (progressRight - left) * Math.max(0f, Math.min(1f,
                    rangeEndMicros / (float) durationMicros));
            paint.setColor(0x2b65dfb0);
            canvas.drawRoundRect(new RectF(rangeStartX, progressY - density, Math.max(rangeStartX + density, rangeEndX),
                    progressY + barHeight + density), 2 * density, 2 * density, paint);
            float progress = Math.max(0f, Math.min(1f, positionMicros / (float) durationMicros));
            float cursorX = left + (progressRight - left) * progress;
            paint.setColor(0x75f7fbff);
            paint.setStrokeWidth(2 * density);
            canvas.drawLine(cursorX, progressY - 3 * density, cursorX, progressY + barHeight + 3 * density, paint);
            paint.setStrokeWidth(1 * density);
            float startHandleX = left + (progressRight - left) * rangeStartMicros / (float) Math.max(1L, durationMicros);
            float endHandleX = left + (progressRight - left) * rangeEndMicros / (float) Math.max(1L, durationMicros);
            paint.setColor(rangeEditing ? 0xffffd278 : 0x2b65dfb0);
            canvas.drawCircle(startHandleX, progressY + barHeight / 2f, (rangeEditing ? 5.5f : 2.6f) * density, paint);
            paint.setColor(rangeEditing ? 0xffff91b8 : 0x2b65dfb0);
            canvas.drawCircle(endHandleX, progressY + barHeight / 2f, (rangeEditing ? 5.5f : 2.6f) * density, paint);
            if (rangeEditing) {
                paint.setTextSize(7.5f * density);
                paint.setFakeBoldText(true);
                paint.setColor(0xffffd278);
                canvas.drawText("起", Math.max(left, Math.min(progressRight - 8 * density, startHandleX - 3 * density)), progressY - 3 * density, paint);
                paint.setColor(0xffff91b8);
                canvas.drawText("止", Math.max(left, Math.min(progressRight - 8 * density, endHandleX - 3 * density)), progressY - 3 * density, paint);
                paint.setFakeBoldText(false);
            }
            paint.setStyle(Paint.Style.FILL);
            paint.setFakeBoldText(false);
            paint.setTextSize(5.8f * density);
            paint.setColor(0x70c8d4db);
            String progressTimeLabel = formatTime(positionMicros) + " / " + formatTime(durationMicros);
            float progressTimeWidth = paint.measureText(progressTimeLabel);
            float minTimeX = left;
            float maxTimeX = Math.max(minTimeX, progressRight - progressTimeWidth - 7 * density);
            float progressTimeX = Math.max(minTimeX, Math.min(maxTimeX, cursorX - progressTimeWidth / 2f));
            canvas.drawText(progressTimeLabel, progressTimeX, h - 4.2f * density, paint);
        }

        // Low-contrast playhead line restored without a background strip.
        paint.setStyle(Paint.Style.STROKE);
        paint.setColor(practiceWaiting ? 0xd5a4ffce : 0x26ffffff);
        paint.setStrokeWidth((practiceWaiting ? 1.8f : 0.85f) * density);
        canvas.drawLine(playheadX, top, playheadX, bottom, paint);
        paint.setStrokeWidth(1f * density);
        paint.setStyle(Paint.Style.FILL);

        if (scrubbing) {
            paint.setColor(0xee65dfb0);
            paint.setStyle(Paint.Style.STROKE);
            canvas.drawRoundRect(new RectF(1.5f * density, 1.5f * density, w - 1.5f * density, h - 1.5f * density),
                    11 * density, 11 * density, paint);
            paint.setStyle(Paint.Style.FILL);
        }
        drawHeaderOverlay(canvas, w, h, density);
        drawResizeHandle(canvas, w, h, density);
        drawSubtleWindowBorder(canvas, w, h, density);
        if (playing) postInvalidateDelayed(80L);
    }

    private void drawHeaderOverlay(Canvas canvas, float w, float h, float density) {
        // The close/play controls occupy a short first row. Title/time and the moving notes
        // share the next row on the same transparent surface.
        float left = 8 * density;
        float right = w - 8 * density;
        float playheadX = getPlayheadX(w, left, right, density);
        float titleMaxWidth = Math.max(16 * density, playheadX - left - 7 * density);
        float buttonTop = 3 * density;
        float buttonBottom = Math.min(24 * density, h - 4 * density);
        // Only close and the unified 演奏 control remain in the note-roll header.
        drawHeaderChip(canvas, new RectF(5 * density, buttonTop, 28 * density, buttonBottom),
                "×", 0xff455667, density);
        drawHeaderChip(canvas, new RectF(30 * density, buttonTop, 95 * density, buttonBottom),
                "演奏", playing ? 0xff4c8d80 : 0xff455667, density);

        paint.setStyle(Paint.Style.FILL);
        paint.setFakeBoldText(true);
        paint.setTextSize(8.8f * density);
        paint.setColor(0x99f2f5f4);
        CharSequence visibleTitle = android.text.TextUtils.ellipsize(
                title, new android.text.TextPaint(paint), titleMaxWidth,
                android.text.TextUtils.TruncateAt.END);
        canvas.drawText(visibleTitle.toString(), left, 37 * density, paint);
        paint.setFakeBoldText(false);
        paint.setTextSize(6.9f * density);
        paint.setColor(0x88ebf0f0);
        String time = formatTime(positionMicros) + " / " + formatTime(durationMicros);
        CharSequence visibleTime = android.text.TextUtils.ellipsize(
                time, new android.text.TextPaint(paint), titleMaxWidth,
                android.text.TextUtils.TruncateAt.END);
        canvas.drawText(visibleTime.toString(), left, 47 * density, paint);

        // Segment control remains underneath the metadata, not over the close button.
        drawHeaderChip(canvas, new RectF(left, 96 * density, left + 61 * density, 114 * density),
                rangeEditing ? "完成" : "A/B循环",
                rangeEditing ? 0xff4c8d80 : (abLoopEnabled ? 0xff477960 : 0xff455667), density);
        drawHeaderChip(canvas, new RectF(70 * density, 52 * density, 95 * density, 69 * density),
                "⏮︎", 0xff455667, density);
        drawSpeedControl(canvas, w, density);
        drawPracticeControl(canvas, w, density);
    }

    private void drawSpeedControl(Canvas canvas, float width, float density) {
        float left = 8 * density;
        float right = Math.min(95 * density, width - 8 * density);
        if (right - left < 24 * density) return;
        paint.setStyle(Paint.Style.FILL);
        paint.setFakeBoldText(true);
        paint.setTextSize(7.5f * density);
        paint.setColor(0x78dce5eb);
        canvas.drawText("速度 " + speedPercent + "%", left, 79 * density, paint);
        paint.setFakeBoldText(false);

        float trackLeft = left;
        float trackRight = right;
        float trackY = 88 * density;
        float fraction = (speedPercent - 50) / 150f;
        float thumbX = trackLeft + (trackRight - trackLeft) * fraction;
        paint.setStrokeWidth(2.5f * density);
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setColor(0x4c7c8d99);
        canvas.drawLine(trackLeft, trackY, trackRight, trackY, paint);
        paint.setColor(0x758dbdaf);
        canvas.drawLine(trackLeft, trackY, thumbX, trackY, paint);
        paint.setStrokeCap(Paint.Cap.BUTT);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(0xbfdce7e4);
        canvas.drawCircle(thumbX, trackY, 3 * density, paint);
        paint.setColor(0x887da59a);
        canvas.drawCircle(thumbX, trackY, 1.6f * density, paint);
    }

    private void drawPracticeControl(Canvas canvas, float width, float density) {
        float left = 8 * density;
        float top = 52 * density;
        float right = Math.min(69 * density, width - 8 * density);
        float bottom = 69 * density;
        if (right - left < 28 * density || bottom > getHeight() - 16 * density) return;
        RectF chip = new RectF(left, top, right, bottom);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(practiceModeEnabled ? 0x994a8a72 : 0x263e5662);
        canvas.drawRoundRect(chip, 5 * density, 5 * density, paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(0.8f * density);
        paint.setColor(practiceModeEnabled ? 0xb4a7ebc5 : 0x3fbdcbd0);
        canvas.drawRoundRect(chip, 5 * density, 5 * density, paint);
        paint.setStyle(Paint.Style.FILL);
        paint.setTextSize(7.5f * density);
        paint.setFakeBoldText(practiceModeEnabled);
        paint.setColor(practiceModeEnabled ? 0xffe4f8ee : 0x8ebac6cc);
        String label = practiceModeEnabled ? "练习  ●" : "练习";
        float textX = chip.centerX() - paint.measureText(label) / 2f;
        float textY = chip.centerY() - (paint.ascent() + paint.descent()) / 2f;
        canvas.drawText(label, textX, textY, paint);
        paint.setFakeBoldText(false);
    }

    private int speedFromX(float x, float density, float width) {
        float left = 8 * density;
        float right = Math.min(95 * density, width - 8 * density);
        float fraction = Math.max(0f, Math.min(1f, (x - left) / Math.max(1f, right - left)));
        int raw = Math.round(50 + fraction * 150);
        return Math.max(50, Math.min(200, Math.round(raw / 5f) * 5));
    }

    private void drawHeaderChip(Canvas canvas, RectF rect, String label, int color, float density) {
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(0x50354654);
        canvas.drawRoundRect(rect, 5 * density, 5 * density, paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(1 * density);
        paint.setColor(0x459bb1c1);
        canvas.drawRoundRect(rect, 5 * density, 5 * density, paint);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(color);
        paint.setTextSize(9 * density);
        paint.setFakeBoldText(true);
        float tw = paint.measureText(label);
        canvas.drawText(label, rect.centerX() - tw / 2, rect.centerY() + 3.2f * density, paint);
        paint.setFakeBoldText(false);
    }

    private void drawOriginalGameKeyIcon(Canvas canvas, float cx, float cy,
                                         float size, int index, int alpha) {
        if (gameKeyAtlas == null || index < 0 || index >= 9 || size <= 0f) return;
        int cellX = (index % 3) * 32;
        int cellY = (index / 3) * 32;
        // Exclude the outer colored game pad; retain the inner key medallion and symbol only.
        Rect src = new Rect(cellX + 1, cellY + 1, cellX + 31, cellY + 31);
        RectF dst = new RectF(cx - size / 2f, cy - size / 2f,
                cx + size / 2f, cy + size / 2f);
        Path circularCrop = new Path();
        circularCrop.addOval(dst, Path.Direction.CW);
        int save = canvas.save();
        canvas.clipPath(circularCrop);
        paint.setStyle(Paint.Style.FILL);
        paint.setAlpha(Math.max(0, Math.min(255, alpha)));
        paint.setFilterBitmap(true);
        paint.setDither(true);
        canvas.drawBitmap(gameKeyAtlas, src, dst, paint);
        canvas.restoreToCount(save);
        paint.setAlpha(255);
        paint.setDither(false);
    }

    private void drawGameKeyIcon(Canvas canvas, float cx, float cy, float radius,
                                 int index, int alpha) {
        if (radius <= 0f) return;
        canvas.save();
        canvas.translate(cx - radius, cy - radius);
        float scale = radius * 2f / 100f;
        canvas.scale(scale, scale);
        paint.setStyle(Paint.Style.FILL);
        paint.setAlpha(alpha);
        paint.setColor(0xfff7efd9);
        canvas.drawCircle(50, 50, 48, paint);
        paint.setColor(0xffd9d0ba);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(2.2f);
        canvas.drawCircle(50, 50, 47, paint);
        paint.setStyle(Paint.Style.FILL);

        Path shape = new Path();
        switch (index) {
            case 0: // A2: low center note, dark blue crescent and lower dot.
                paint.setColor(0xff182b3c);
                shape.moveTo(28, 25); shape.lineTo(51, 25); shape.lineTo(51, 68);
                shape.lineTo(28, 58); shape.close(); canvas.drawPath(shape, paint);
                paint.setColor(0xff4b7e9b);
                shape.reset(); shape.moveTo(52, 27); shape.lineTo(72, 39);
                shape.lineTo(72, 56); shape.lineTo(52, 68); shape.close(); canvas.drawPath(shape, paint);
                paint.setColor(0xff17202a); canvas.drawCircle(51, 82, 5.2f, paint);
                break;
            case 1: // E3: green tapered stem.
                paint.setColor(0xff2b855b);
                shape.moveTo(34, 24); shape.lineTo(55, 24); shape.lineTo(55, 73);
                shape.lineTo(34, 88); shape.close(); canvas.drawPath(shape, paint);
                paint.setColor(0xff17202a); canvas.drawCircle(50, 16, 5, paint);
                break;
            case 2: // F3: purple upper bowl over a black foot.
                paint.setColor(0xff9b45c8);
                canvas.drawArc(new RectF(27, 24, 70, 66), 180, 180, true, paint);
                shape.reset(); shape.moveTo(28, 57); shape.lineTo(72, 57);
                shape.lineTo(60, 78); shape.lineTo(28, 78); shape.close();
                paint.setColor(0xff15191e); canvas.drawPath(shape, paint);
                paint.setColor(0xff17202a); canvas.drawCircle(50, 15, 5, paint);
                break;
            case 3: // G3: black upper flag and green lower bowl.
                paint.setColor(0xff15191e);
                shape.moveTo(31, 24); shape.lineTo(71, 24); shape.lineTo(62, 47);
                shape.lineTo(31, 47); shape.close(); canvas.drawPath(shape, paint);
                paint.setColor(0xff78a64a);
                canvas.drawArc(new RectF(29, 39, 70, 79), 0, 180, true, paint);
                paint.setColor(0xff17202a); canvas.drawCircle(50, 15, 5, paint);
                break;
            case 4: // A3: green bowl below a flat black cap.
                paint.setColor(0xff15191e);
                shape.moveTo(27, 24); shape.lineTo(72, 24); shape.lineTo(64, 40);
                shape.lineTo(27, 40); shape.close(); canvas.drawPath(shape, paint);
                paint.setColor(0xff78a64a);
                canvas.drawArc(new RectF(28, 37, 70, 79), 0, 180, true, paint);
                break;
            case 5: // B3: magenta half-disc and upright black bar.
                paint.setColor(0xffc13d85);
                canvas.drawArc(new RectF(24, 28, 65, 70), 90, 180, true, paint);
                paint.setColor(0xff15191e);
                canvas.drawRect(49, 27, 63, 70, paint);
                canvas.drawRect(49, 27, 74, 42, paint);
                break;
            case 6: // C4: orange lower wedge below black bar.
                paint.setColor(0xff15191e);
                canvas.drawRect(28, 25, 72, 40, paint);
                paint.setColor(0xffe98f27);
                shape.moveTo(49, 40); shape.lineTo(71, 40); shape.lineTo(60, 75);
                shape.lineTo(49, 84); shape.close(); canvas.drawPath(shape, paint);
                break;
            case 7: // D4: blue split key.
                paint.setColor(0xff15283d);
                shape.moveTo(29, 26); shape.lineTo(51, 26); shape.lineTo(51, 69);
                shape.lineTo(29, 69); shape.close(); canvas.drawPath(shape, paint);
                paint.setColor(0xff4f86b5);
                canvas.drawArc(new RectF(48, 39, 73, 68), 270, 180, true, paint);
                break;
            case 8: // E4: orange tapered foot below a black cap.
                paint.setColor(0xff15191e);
                shape.moveTo(24, 25); shape.lineTo(75, 25); shape.lineTo(69, 41);
                shape.lineTo(24, 41); shape.close(); canvas.drawPath(shape, paint);
                paint.setColor(0xffe98f27);
                shape.reset(); shape.moveTo(48, 41); shape.lineTo(69, 41);
                shape.lineTo(59, 76); shape.lineTo(48, 82); shape.close();
                canvas.drawPath(shape, paint);
                break;
            default:
                paint.setColor(0xff182b3c);
                canvas.drawCircle(50, 50, 17, paint);
        }
        paint.setAlpha(255);
        paint.setStyle(Paint.Style.FILL);
        canvas.restore();
    }

    private void beginSeekGesture() {
        if (seekGestureStarted) return;
        seekGestureStarted = true;
        if (interactionListener != null) interactionListener.onBeginSeekGesture();
    }

    private void endSeekGesture() {
        if (!seekGestureStarted) return;
        seekGestureStarted = false;
        if (interactionListener != null) interactionListener.onEndSeekGesture();
    }

    private void drawSubtleWindowBorder(Canvas canvas, float w, float h, float density) {
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(0.8f * density);
        paint.setColor(0x339bb1c1);
        canvas.drawRoundRect(new RectF(0.8f * density, 0.8f * density,
                        w - 0.8f * density, h - 0.8f * density),
                9 * density, 9 * density, paint);
        paint.setStrokeWidth(1f * density);
        paint.setStyle(Paint.Style.FILL);
        paint.setAlpha(255);
    }

    private void drawResizeHandle(Canvas canvas, float w, float h, float density) {
        paint.setColor(0x88d4e6f2);
        paint.setStrokeWidth(1.5f * density);
        for (int i = 0; i < 3; i++) {
            float inset = (4 + i * 4) * density;
            canvas.drawLine(w - inset - 7 * density, h - 3 * density,
                    w - 3 * density, h - inset - 7 * density, paint);
        }
        paint.setStrokeWidth(1 * density);
    }

    private static float getPlayheadX(float width, float left, float right, float density) {
        // Keep the fade/playhead line just to the right of the ⏮︎ chip.
        float afterRewind = 100 * density;
        return Math.max(left + 92 * density, Math.min(right - 24 * density, afterRewind));
    }

    private static long visibleWindowMicros(float width, float left, float right, float density) {
        float usableDp = Math.max(80f, (right - left) / density);
        // Narrow windows focus more tightly; enlarged windows show more upcoming music.
        return (long) (Math.max(4.0f, Math.min(16.0f, usableDp / 36.0f)) * 1_000_000L);
    }

    private static int pitchLane(int pitch, int laneCount) {
        int instrumentIndex = InstrumentLayout.indexOfPitch(pitch);
        if (instrumentIndex >= 0) {
            int highToLowIndex = InstrumentLayout.PITCHES.length - 1 - instrumentIndex;
            return Math.min(laneCount - 1, highToLowIndex * laneCount / InstrumentLayout.PITCHES.length);
        }
        return Math.min(laneCount - 1, Math.floorMod(pitch, 12) * laneCount / 12);
    }

    @Override public boolean onTouchEvent(MotionEvent event) {
        final float density = getResources().getDisplayMetrics().density;
        final float x = event.getX(), y = event.getY();
        final float w = getWidth(), h = getHeight();
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN: {
                downX = x; downY = y;
                downRawX = event.getRawX(); downRawY = event.getRawY();
                lastDx = x;
                gestureMoved = false;
                positionAtDown = positionMicros;
                positionDuringScrub = positionMicros;
                rangeStartAtDown = rangeStartMicros;
                rangeEndAtDown = rangeEndMicros;
                touchEdges = detectEdges(x, y, w, h, 10 * density);
                windowGestureStarted = false;
                absoluteSeekMoved = false;
                if (y >= 3 * density && y < 27 * density
                        && x >= 4 * density && x <= 29 * density) {
                    touchMode = TOUCH_CLOSE;
                } else if (y >= 3 * density && y < 27 * density
                        && x > 29 * density && x <= 95 * density) {
                    touchMode = TOUCH_PLAY_PAUSE;
                } else if (y >= 50 * density && y < 72 * density
                        && x >= 5 * density && x <= 69 * density) {
                    touchMode = TOUCH_PRACTICE;
                } else if (y >= 50 * density && y < 72 * density
                        && x > 69 * density && x <= 97 * density) {
                    touchMode = TOUCH_REWIND;
                } else if (y >= 71 * density && y < 96 * density
                        && x >= 5 * density && x <= Math.min(98 * density, w - 5 * density)) {
                    touchMode = TOUCH_SPEED;
                    speedAtDown = speedPercent;
                    speedPercent = speedFromX(x, density, w);
                    invalidate();
                } else if (y >= 96 * density && y < 115 * density
                        && x >= 5 * density && x <= Math.min(69 * density, w - 8 * density)) {
                    touchMode = TOUCH_SEGMENT;
                    segmentDownTimeMs = event.getEventTime();
                } else if (touchEdges != 0) {
                    touchMode = TOUCH_RESIZE;
                    notifyWindowGesture(MODE_RESIZE, touchEdges, 0, 0, PHASE_START);
                } else if (rangeEditing && y >= 47 * density) {
                    touchMode = TOUCH_RANGE_EDIT;
                    rangeDragEndpoint = endpointForX(x, density);
                } else if (y >= h - 24 * density && y <= h - 12 * density) {
                    // Freeze the playback scheduler at touch-down; position selection still happens
                    // on up or after a deliberate horizontal drag crosses touch slop.
                    beginSeekGesture();
                    touchMode = TOUCH_SEEK_ABSOLUTE;
                    absoluteSeekMoved = false;
                    positionDuringScrub = positionMicros;
                } else if (y < 47 * density && x < Math.max(38 * density, w * .48f)) {
                    touchMode = TOUCH_MOVE_WINDOW;
                    notifyWindowGesture(MODE_MOVE, 0, 0, 0, PHASE_START);
                } else {
                    touchMode = TOUCH_SCRUB;
                    scrubbing = false;
                }
                return true;
            }
            case MotionEvent.ACTION_MOVE: {
                float dx = x - downX;
                float dy = y - downY;
                float rawDx = event.getRawX() - downRawX;
                float rawDy = event.getRawY() - downRawY;
                if (Math.hypot(rawDx, rawDy) > touchSlop) gestureMoved = true;
                if (touchMode == TOUCH_SPEED) {
                    speedPercent = speedFromX(x, density, w);
                    invalidate();
                } else if (touchMode == TOUCH_MOVE_WINDOW) {
                    if (gestureMoved) {
                        windowGestureStarted = true;
                        notifyWindowGesture(MODE_MOVE, 0, Math.round(rawDx), Math.round(rawDy), PHASE_UPDATE);
                    }
                } else if (touchMode == TOUCH_RESIZE) {
                    if (gestureMoved) {
                        windowGestureStarted = true;
                        notifyWindowGesture(MODE_RESIZE, touchEdges, Math.round(rawDx), Math.round(rawDy), PHASE_UPDATE);
                    }
                } else if (touchMode == TOUCH_RANGE_EDIT) {
                    if (Math.abs(rawDx) > touchSlop) {
                        long target = songPositionAtX(x, density);
                        updateRangeEndpoint(target);
                        scrubbing = true;
                        invalidate();
                    }
                } else if (touchMode == TOUCH_SEEK_ABSOLUTE) {
                    if (NoteRollGestureMath.shouldUpdateAbsoluteSeek(dx, dy, touchSlop)) {
                        beginSeekGesture();
                        absoluteSeekMoved = true;
                        scrubbing = true;
                        positionDuringScrub = absoluteSeekAt(x, density);
                        positionMicros = positionDuringScrub;
                        invalidate();
                    }
                } else if (touchMode == TOUCH_SCRUB && Math.abs(dx) > touchSlop
                        && Math.abs(dx) > Math.abs(dy) * .85f) {
                    beginSeekGesture();
                    scrubbing = true;
                    long window = visibleWindowMicros(w, 8 * density, w - 8 * density, density);
                    // Note-field swipes are intentionally gentle; the thin bottom rail
                    // remains the precise full-song seek target.
                    long delta = NoteRollGestureMath.gentlePanDelta(dx, w, window);
                    long safeEnd = safeScrubEnd();
                    positionDuringScrub = clamp(positionAtDown + delta, seekRangeStart(), safeEnd);
                    positionMicros = positionDuringScrub;
                    lastDx = x;
                    invalidate();
                }
                return true;
            }
            case MotionEvent.ACTION_UP: {
                float dx = event.getRawX() - downRawX;
                float dy = event.getRawY() - downRawY;
                if (touchMode == TOUCH_SPEED) {
                    if (interactionListener != null && speedPercent != speedAtDown) {
                        interactionListener.onSpeedChange(speedPercent);
                    }
                } else if (touchMode == TOUCH_PRACTICE && !gestureMoved) {
                    if (interactionListener != null) interactionListener.onTogglePracticeMode();
                } else if (touchMode == TOUCH_CLOSE && !gestureMoved) {
                    if (interactionListener != null) interactionListener.onClose();
                } else if (touchMode == TOUCH_PLAY_PAUSE && !gestureMoved) {
                    if (interactionListener != null) interactionListener.onTogglePlayPause();
                } else if (touchMode == TOUCH_REWIND && !gestureMoved) {
                    if (interactionListener != null) interactionListener.onRewind();
                } else if (touchMode == TOUCH_SEGMENT && !gestureMoved) {
                    if (interactionListener != null) {
                        long heldMs = event.getEventTime() - segmentDownTimeMs;
                        if (rangeEditing || heldMs >= 450L) interactionListener.onEditSegment();
                        else interactionListener.onToggleAbLoop();
                    }
                } else if (touchMode == TOUCH_RANGE_EDIT) {
                    if (gestureMoved && interactionListener != null) {
                        interactionListener.onPracticeRangeChange(rangeStartMicros, rangeEndMicros);
                    } else {
                        rangeStartMicros = rangeStartAtDown;
                        rangeEndMicros = rangeEndAtDown;
                    }
                    scrubbing = false;
                    invalidate();
                } else if (touchMode == TOUCH_SEEK_ABSOLUTE) {
                    boolean isTap = !gestureMoved;
                    if (absoluteSeekMoved || isTap) {
                        if (isTap) positionDuringScrub = absoluteSeekAt(x, density);
                        positionMicros = positionDuringScrub;
                        if (interactionListener != null) interactionListener.onSeek(positionMicros);
                    }
                    scrubbing = false;
                    endSeekGesture();
                    invalidate();
                } else if (touchMode == TOUCH_SCRUB && scrubbing) {
                    positionMicros = positionDuringScrub;
                    if (interactionListener != null) interactionListener.onSeek(positionMicros);
                    scrubbing = false;
                    endSeekGesture();
                    invalidate();
                } else if (touchMode == TOUCH_MOVE_WINDOW) {
                    if (windowGestureStarted)
                        notifyWindowGesture(MODE_MOVE, 0, Math.round(dx), Math.round(dy), PHASE_END);
                } else if (touchMode == TOUCH_RESIZE) {
                    if (windowGestureStarted)
                        notifyWindowGesture(MODE_RESIZE, touchEdges, Math.round(dx), Math.round(dy), PHASE_END);
                }
                touchMode = TOUCH_NONE;
                performClick();
                return true;
            }
            case MotionEvent.ACTION_CANCEL:
                if (touchMode == TOUCH_MOVE_WINDOW && windowGestureStarted)
                    notifyWindowGesture(MODE_MOVE, 0, Math.round(event.getRawX() - downRawX), Math.round(event.getRawY() - downRawY), PHASE_END);
                else if (touchMode == TOUCH_RESIZE && windowGestureStarted)
                    notifyWindowGesture(MODE_RESIZE, touchEdges, Math.round(event.getRawX() - downRawX), Math.round(event.getRawY() - downRawY), PHASE_END);
                else if (touchMode == TOUCH_RANGE_EDIT) {
                    rangeStartMicros = rangeStartAtDown;
                    rangeEndMicros = rangeEndAtDown;
                } else if (touchMode == TOUCH_SPEED) {
                    speedPercent = speedAtDown;
                }
                scrubbing = false;
                endSeekGesture();
                touchMode = TOUCH_NONE;
                invalidate();
                return true;
        }
        return true;
    }

    private int endpointForX(float x, float density) {
        float left = 8 * density;
        float right = getWidth() - 8 * density;
        float fraction = Math.max(0f, Math.min(1f, (x - left) / Math.max(1f, right - left)));
        float startFraction = rangeStartMicros / (float) Math.max(1L, durationMicros);
        float endFraction = rangeEndMicros / (float) Math.max(1L, durationMicros);
        return Math.abs(fraction - startFraction) <= Math.abs(fraction - endFraction) ? 1 : 2;
    }

    private void updateRangeEndpoint(long target) {
        long duration = Math.max(1L, durationMicros);
        long minGap = Math.min(duration, Math.min(500_000L, Math.max(30_000L, duration / 2000L)));
        target = clamp(target, 0L, duration);
        if (rangeDragEndpoint == 1) {
            rangeStartMicros = Math.max(0L, Math.min(target, rangeEndMicros - minGap));
        } else {
            rangeEndMicros = Math.min(duration, Math.max(target, rangeStartMicros + minGap));
        }
        rangeStartMicros = Math.max(0L, Math.min(rangeStartMicros, duration - minGap));
        rangeEndMicros = Math.max(rangeStartMicros + minGap, Math.min(duration, rangeEndMicros));
    }

    private long absoluteSeekAt(float x, float density) {
        float left = 8 * density;
        float right = getWidth() - 8 * density;
        float fraction = Math.max(0f, Math.min(1f, (x - left) / Math.max(1f, right - left)));
        long start = seekRangeStart();
        long end = seekRangeEnd();
        return start + Math.round((end - start) * fraction);
    }

    private long songPositionAtX(float x, float density) {
        float left = 8 * density;
        float right = getWidth() - 8 * density;
        float fraction = Math.max(0f, Math.min(1f, (x - left) / Math.max(1f, right - left)));
        return Math.round(Math.max(0L, durationMicros) * fraction);
    }

    private long seekRangeStart() {
        return abLoopEnabled ? clamp(rangeStartMicros, 0L, durationMicros) : 0L;
    }

    private long seekRangeEnd() {
        long start = seekRangeStart();
        return abLoopEnabled
                ? clamp(rangeEndMicros, start, durationMicros)
                : Math.max(0L, durationMicros);
    }

    private long safeScrubEnd() {
        long start = seekRangeStart();
        long end = seekRangeEnd();
        long span = Math.max(0L, end - start);
        long margin = Math.min(500_000L, Math.max(30_000L, span / 200L));
        return Math.max(start, end - margin);
    }

    @Override public boolean performClick() {
        super.performClick();
        return true;
    }

    private void notifyWindowGesture(int mode, int edges, int dx, int dy, int phase) {
        if (interactionListener != null) interactionListener.onWindowGesture(mode, edges, dx, dy, phase);
    }

    private static int detectEdges(float x, float y, float w, float h, float edge) {
        int result = 0;
        if (x <= edge) result |= EDGE_LEFT;
        if (x >= w - edge) result |= EDGE_RIGHT;
        if (y <= edge) result |= EDGE_TOP;
        if (y >= h - edge) result |= EDGE_BOTTOM;
        return result;
    }

    public static String formatTime(long micros) {
        long seconds = Math.max(0L, micros / 1_000_000L);
        long minutes = seconds / 60L;
        return minutes + ":" + (seconds % 60L < 10 ? "0" : "") + (seconds % 60L);
    }
}
